<?php
// Load simple .env
$env = [];
if (file_exists(__DIR__ . '/../.env')) {
    $lines = file(__DIR__ . '/../.env', FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
    foreach ($lines as $line) {
        if (strpos(trim($line),'#') === 0) continue;
        [$k,$v] = array_pad(explode('=', $line, 2), 2, '');
        $env[trim($k)] = trim($v);
    }
} else {
    $env = parse_ini_file(__DIR__ . '/../.env.example') ?: [];
}

$db = [
    'host' => $env['DB_HOST'] ?? '127.0.0.1',
    'name' => $env['DB_NAME'] ?? 'sshnet',
    'user' => $env['DB_USER'] ?? 'sshnet_user',
    'pass' => $env['DB_PASS'] ?? 'ChangeMe123!',
];

$dsn = "mysql:host={$db['host']};dbname={$db['name']};charset=utf8mb4";
try {
    $pdo = new PDO($dsn, $db['user'], $db['pass'], [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]);
} catch (Exception $e) {
    http_response_code(500);
    echo "Database connection error: " . htmlspecialchars($e->getMessage());
    exit;
}

function view($path, $vars = []) {
    extract($vars, EXTR_SKIP);
    include __DIR__ . "/../resources/views/" . $path;
}

session_start();
