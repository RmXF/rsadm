<?php
require_once __DIR__ . '/config.php';

function attempt_login($username, $password) {
    global $pdo;
    $stmt = $pdo->prepare('SELECT id, username, password_hash, role FROM users WHERE username = ? LIMIT 1');
    $stmt->execute([$username]);
    $u = $stmt->fetch(PDO::FETCH_ASSOC);
    if ($u && password_verify($password, $u['password_hash'])) {
        session_regenerate_id(true);
        $_SESSION['user'] = ['id'=>$u['id'],'username'=>$u['username'],'role'=>$u['role']];
        return true;
    }
    return false;
}

function require_auth() {
    if (!isset($_SESSION['user'])) {
        header('Location: /login.php');
        exit;
    }
}

function current_user() {
    return $_SESSION['user'] ?? null;
}
