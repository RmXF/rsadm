#!/usr/bin/env bash
set -euo pipefail
# Automated installer for SSHNET PHP panel (Debian/Ubuntu)
# Run as root or with sudo.

ZIP_LOCAL="./sshnet_php_full.zip"
WWW_DIR="/var/www/sshnet"
SITE_NAME="sshnet"
SITE_CONF="/etc/nginx/sites-available/${SITE_NAME}"
DB_NAME="sshnet"
DB_USER="sshnet_user"
DB_PASS="ChangeMe123!"

echo "[+] Installing packages..."
apt-get update -y
apt-get install -y nginx php php-fpm php-mysql unzip wget rsync mariadb-server

# Use bundled zip if present
if [ -f "$ZIP_LOCAL" ]; then
  echo "[+] Using local zip $ZIP_LOCAL"
else
  echo "[!] Please place 'sshnet_php_full.zip' next to this installer or set ZIP_URL inside the script."
  exit 1
fi

echo "[+] Deploying to $WWW_DIR..."
rm -rf "$WWW_DIR"
mkdir -p "$WWW_DIR"
unzip -o "$ZIP_LOCAL" -d "$WWW_DIR"
# move public content up if exists
if [ -d "$WWW_DIR/public" ]; then
  rsync -a "$WWW_DIR/public/" "$WWW_DIR/"
  rm -rf "$WWW_DIR/public"
fi

# Create .env if not exists
if [ ! -f "$WWW_DIR/.env" ]; then
  cat > "$WWW_DIR/.env" <<EOF
DB_HOST=127.0.0.1
DB_NAME=${DB_NAME}
DB_USER=${DB_USER}
DB_PASS=${DB_PASS}
APP_URL=http://$(hostname -I | awk '{print $1}')
EOF
fi

# Nginx config
cat > "$SITE_CONF" <<'NGINX'
server {
    listen 80;
    server_name _;
    root /var/www/sshnet;
    index index.php index.html;
    location / {
        try_files $uri $uri/ /index.php?$query_string;
    }
    location ~ \.php$ {
        include snippets/fastcgi-php.conf;
        fastcgi_pass unix:/run/php/php-fpm.sock;
    }
    location ~ /\.ht {
        deny all;
    }
}
NGINX

ln -sf "$SITE_CONF" /etc/nginx/sites-enabled/${SITE_NAME}
rm -f /etc/nginx/sites-enabled/default
nginx -t
systemctl restart nginx

# Database setup
echo "[+] Setting up database..."
mysql -e "CREATE DATABASE IF NOT EXISTS \`${DB_NAME}\` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;"
mysql -e "CREATE USER IF NOT EXISTS '${DB_USER}'@'localhost' IDENTIFIED BY '${DB_PASS}';"
mysql -e "GRANT ALL PRIVILEGES ON \`${DB_NAME}\`.* TO '${DB_USER}'@'localhost';"
mysql -e "FLUSH PRIVILEGES;"

# Import migration
if [ -f "$WWW_DIR/sql/migration.sql" ]; then
  echo "[+] Importing migration..."
  PHP_HASH=$(php -r 'echo password_hash("password123", PASSWORD_DEFAULT);')
  sed "s|{hash}|$PHP_HASH|g" "$WWW_DIR/sql/migration.sql" > /tmp/mig.sql
  mysql "$DB_NAME" < /tmp/mig.sql
fi

chown -R www-data:www-data "$WWW_DIR"
chmod -R 755 "$WWW_DIR"

echo
echo "========================================="
echo "SSHNET deployed: http://$(hostname -I | awk '{print $1}')/"
echo "DB: ${DB_NAME}"
echo "DB USER: ${DB_USER}"
echo "DB PASS: ${DB_PASS}"
echo "Admin login: admin / password123"
echo "========================================="
