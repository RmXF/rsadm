<?php
require_once __DIR__ . '/../app/config.php';
require_once __DIR__ . '/../app/auth.php';
require_auth();
$hwid_file = __DIR__ . '/../storage/hwid.txt';
if (!file_exists($hwid_file)) {
    $hwid = 'HWID-' . bin2hex(random_bytes(8));
    file_put_contents($hwid_file, $hwid);
} else {
    $hwid = file_get_contents($hwid_file);
}
include __DIR__ . '/../resources/views/hwid.php';
