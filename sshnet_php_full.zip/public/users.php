<?php
require_once __DIR__ . '/../app/config.php';
require_once __DIR__ . '/../app/auth.php';
require_auth();
$users = $pdo->query('SELECT id, username, role, created_at FROM users ORDER BY id DESC')->fetchAll(PDO::FETCH_ASSOC);
include __DIR__ . '/../resources/views/users.php';
