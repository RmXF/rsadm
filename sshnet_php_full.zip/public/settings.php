<?php
require_once __DIR__ . '/../app/config.php';
require_once __DIR__ . '/../app/auth.php';
require_auth();
$settings_file = __DIR__ . '/../storage/settings.json';
$settings = [];
if (file_exists($settings_file)) {
    $settings = json_decode(file_get_contents($settings_file), true) ?: [];
}
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $settings['logo'] = $_POST['logo'] ?? '';
    $settings['lang'] = $_POST['lang'] ?? 'es';
    file_put_contents($settings_file, json_encode($settings, JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE));
    header('Location: /settings.php');
    exit;
}
include __DIR__ . '/../resources/views/settings.php';
