<?php
require_once __DIR__ . '/../app/config.php';
require_once __DIR__ . '/../app/auth.php';
require_auth();
$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';
    $role = $_POST['role'] ?? 'user';
    if ($username === '' || $password === '') { $error = 'Usuario y contraseña requeridos'; }
    else {
        $hash = password_hash($password, PASSWORD_DEFAULT);
        $stmt = $pdo->prepare('INSERT INTO users (username, password_hash, role, created_at) VALUES (?, ?, ?, NOW())');
        $stmt->execute([$username, $hash, $role]);
        header('Location: /users.php');
        exit;
    }
}
include __DIR__ . '/../resources/views/header.php';
?>
<div class="max-w-md bg-white p-6 rounded shadow">
  <?php if($error): ?><div class="mb-3 text-red-600"><?=htmlspecialchars($error)?></div><?php endif; ?>
  <h2 class="text-xl mb-3">Crear usuario</h2>
  <form method="post">
    <input name="username" placeholder="Usuario" class="w-full p-2 border rounded mb-2" required />
    <input name="password" type="password" placeholder="Contraseña" class="w-full p-2 border rounded mb-2" required />
    <select name="role" class="w-full p-2 border rounded mb-2">
      <option value="admin">admin</option>
      <option value="user" selected>user</option>
    </select>
    <button class="px-4 py-2 bg-indigo-600 text-white rounded">Crear</button>
  </form>
</div>
<?php include __DIR__ . '/../resources/views/footer.php'; ?>
