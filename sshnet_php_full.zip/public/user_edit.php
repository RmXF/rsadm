<?php
require_once __DIR__ . '/../app/config.php';
require_once __DIR__ . '/../app/auth.php';
require_auth();
$id = $_GET['id'] ?? null;
if (!$id) { header('Location: /users.php'); exit; }
$stmt = $pdo->prepare('SELECT id, username, role FROM users WHERE id = ? LIMIT 1');
$stmt->execute([$id]);
$user = $stmt->fetch(PDO::FETCH_ASSOC);
if (!$user) { header('Location: /users.php'); exit; }
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = $_POST['username'] ?? $user['username'];
    $role = $_POST['role'] ?? $user['role'];
    $pwd = $_POST['password'] ?? '';
    if ($pwd) {
        $hash = password_hash($pwd, PASSWORD_DEFAULT);
        $pdo->prepare('UPDATE users SET username=?, role=?, password_hash=? WHERE id=?')->execute([$username,$role,$hash,$id]);
    } else {
        $pdo->prepare('UPDATE users SET username=?, role=? WHERE id=?')->execute([$username,$role,$id]);
    }
    header('Location: /users.php');
    exit;
}
include __DIR__ . '/../resources/views/header.php';
?>
<div class="max-w-md bg-white p-6 rounded shadow">
  <h2 class="text-xl mb-3">Editar usuario</h2>
  <form method="post">
    <input name="username" value="<?=htmlspecialchars($user['username'])?>" class="w-full p-2 border rounded mb-2" required />
    <input name="password" placeholder="Dejar en blanco para no cambiar" class="w-full p-2 border rounded mb-2" />
    <select name="role" class="w-full p-2 border rounded mb-2">
      <option value="admin" <?= $user['role']=='admin'?'selected':'' ?>>admin</option>
      <option value="user" <?= $user['role']=='user'?'selected':'' ?>>user</option>
    </select>
    <button class="px-4 py-2 bg-indigo-600 text-white rounded">Guardar</button>
  </form>
</div>
<?php include __DIR__ . '/../resources/views/footer.php'; ?>
