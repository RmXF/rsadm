<?php
require_once __DIR__ . '/../app/auth.php';
$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $u = $_POST['username'] ?? '';
    $p = $_POST['password'] ?? '';
    if (attempt_login($u, $p)) {
        header('Location: /dashboard.php');
        exit;
    } else {
        $error = 'Credenciales inválidas';
    }
}
include __DIR__ . '/../resources/views/login.php';
