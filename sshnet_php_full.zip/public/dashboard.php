<?php
require_once __DIR__ . '/../app/config.php';
require_once __DIR__ . '/../app/auth.php';
require_auth();
$stmt = $pdo->query('SELECT COUNT(*) as c FROM users');
$stats = ['users' => $stmt->fetchColumn()];
include __DIR__ . '/../resources/views/dashboard.php';
