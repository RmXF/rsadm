<?php
require_once __DIR__ . '/../app/config.php';
require_once __DIR__ . '/../app/auth.php';
require_auth();
$id = $_GET['id'] ?? null;
if ($id) {
    $pdo->prepare('DELETE FROM users WHERE id = ?')->execute([$id]);
}
header('Location: /users.php');
exit;
