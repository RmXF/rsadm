SSHNET - Native PHP Panel (Full)
This package contains a native PHP admin panel (no frameworks) with:
- Login/logout (secure password hashing)
- Dashboard, Users CRUD, Settings, HWID
- Simple storage and settings
- SQL migration in /sql/migration.sql
- .env.example for configuration

How to deploy quickly:
1) Upload to VPS and run the included installer script, or copy files to your webroot.
2) Ensure PHP-FPM + Nginx configured and webroot points to project root (public files are already at root in this package).
