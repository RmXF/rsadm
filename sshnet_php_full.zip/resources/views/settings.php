<?php include __DIR__ . '/header.php'; ?>
<h1 class="text-xl font-semibold">Configuración del panel</h1>
<div class="mt-4 bg-white p-4 rounded shadow">
  <form method="post" action="/settings.php">
    <label class="block">Logo URL</label>
    <input name="logo" value="<?=htmlspecialchars($settings['logo'] ?? '')?>" class="w-full p-2 border rounded mt-1" />
    <label class="block mt-3">Idioma</label>
    <select name="lang" class="w-full p-2 border rounded mt-1">
      <option value="es" <?= ( ($settings['lang'] ?? 'es')=='es' ? 'selected' : '') ?>>Español</option>
      <option value="en" <?= ( ($settings['lang'] ?? '')=='en' ? 'selected' : '') ?>>English</option>
    </select>
    <div class="mt-4">
      <button class="px-4 py-2 bg-indigo-600 text-white rounded">Guardar</button>
    </div>
  </form>
</div>
<?php include __DIR__ . '/footer.php'; ?>