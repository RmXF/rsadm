<?php include __DIR__ . '/header.php'; ?>
<h1 class="text-xl font-semibold">HWID</h1>
<div class="mt-4 bg-white p-4 rounded shadow">
  <div class="break-words p-3 bg-gray-50 rounded"><?=htmlspecialchars($hwid)?></div>
  <div class="mt-3"><button onclick="navigator.clipboard.writeText('<?=addslashes($hwid)?>')" class="px-3 py-2 bg-indigo-600 text-white rounded">Copiar</button></div>
</div>
<?php include __DIR__ . '/footer.php'; ?>