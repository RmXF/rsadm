<!doctype html>
<html>
<head>
  <meta charset="utf-8">
  <title>SSHNET - Panel</title>
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-100">
<div class="min-h-screen flex">
<aside class="w-72 bg-white p-4 border-r">
  <h2 class="text-xl font-bold mb-6">SSHNET</h2>
  <nav class="space-y-2 text-sm">
    <a href="/dashboard.php" class="block p-2 rounded hover:bg-gray-100">Dashboard</a>
    <a href="/users.php" class="block p-2 rounded hover:bg-gray-100">Usuarios</a>
    <a href="/settings.php" class="block p-2 rounded hover:bg-gray-100">Configuración</a>
    <a href="/hwid.php" class="block p-2 rounded hover:bg-gray-100">HWID</a>
    <a href="/logout.php" class="block p-2 rounded hover:bg-gray-100">Cerrar sesión</a>
  </nav>
</aside>
<main class="flex-1 p-8">
