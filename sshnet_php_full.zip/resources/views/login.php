<?php include __DIR__ . '/header.php'; ?>
<div class="max-w-md mx-auto bg-white p-6 rounded shadow">
  <h1 class="text-2xl font-semibold mb-4">Iniciar sesión</h1>
  <?php if(!empty($error)): ?>
    <div class="mb-3 text-red-600"><?=htmlspecialchars($error)?></div>
  <?php endif; ?>
  <form method="post" action="/login.php" class="space-y-4">
    <input name="username" placeholder="Usuario" required class="w-full p-3 border rounded" />
    <input name="password" type="password" placeholder="Contraseña" required class="w-full p-3 border rounded" />
    <button class="w-full py-3 rounded bg-indigo-600 text-white">Entrar</button>
  </form>
  <p class="text-sm text-gray-500 mt-4">Usuario demo: <strong>admin</strong> / contraseña <strong>password123</strong></p>
</div>
<?php include __DIR__ . '/footer.php'; ?>