<?php include __DIR__ . '/header.php'; ?>
<div class="flex items-center justify-between">
  <h1 class="text-xl font-semibold">Usuarios</h1>
  <a href="/user_create.php" class="px-4 py-2 bg-indigo-600 text-white rounded">Crear usuario</a>
</div>
<div class="mt-4 bg-white rounded shadow overflow-x-auto">
  <table class="min-w-full">
    <thead class="bg-gray-100">
      <tr>
        <th class="p-3 text-left">ID</th>
        <th class="p-3 text-left">Usuario</th>
        <th class="p-3 text-left">Rol</th>
        <th class="p-3 text-left">Creado</th>
        <th class="p-3 text-left">Acciones</th>
      </tr>
    </thead>
    <tbody>
      <?php foreach($users as $u): ?>
      <tr class="border-b">
        <td class="p-3"><?=htmlspecialchars($u['id'])?></td>
        <td class="p-3"><?=htmlspecialchars($u['username'])?></td>
        <td class="p-3"><?=htmlspecialchars($u['role'])?></td>
        <td class="p-3"><?=htmlspecialchars($u['created_at'])?></td>
        <td class="p-3">
          <a href="/user_edit.php?id=<?=urlencode($u['id'])?>" class="text-sm underline">Editar</a>
          <a href="/user_delete.php?id=<?=urlencode($u['id'])?>" class="text-sm text-red-600 ml-3">Borrar</a>
        </td>
      </tr>
      <?php endforeach; ?>
    </tbody>
  </table>
</div>
<?php include __DIR__ . '/footer.php'; ?>