<?php include __DIR__ . '/header.php'; ?>
<h1 class="text-2xl font-semibold">Dashboard</h1>
<div class="grid grid-cols-3 gap-4 mt-6">
  <div class="p-4 bg-white rounded shadow">Usuarios: <strong><?= $stats['users'] ?></strong></div>
  <div class="p-4 bg-white rounded shadow">Conexiones activas: <strong>--</strong></div>
  <div class="p-4 bg-white rounded shadow">Tráfico (24h): <strong>--</strong></div>
</div>
<?php include __DIR__ . '/footer.php'; ?>