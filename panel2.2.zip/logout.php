<?php
/**
 * ====================================================
 * CEO MANAGER PRO v1.0
 * Logout
 * Author: @ReyRs_VIPro
 * ====================================================
 */

session_start();
session_unset();
session_destroy();
header('Location: login.php');
exit();
?>