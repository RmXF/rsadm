/**
 * ====================================================
 * CEO MANAGER PRO v2.0
 * JavaScript Principal - VERSIÓN MEJORADA
 * Author: @ReyRs_VIPro
 * ====================================================
 */

class CEOManager {
    constructor() {
        this.users = [];
        this.currentUser = null;
        this.sshConnected = false;
        this.credentials = null;
        this.currentSection = 'dashboard';
        this.apiBaseUrl = 'php/endpoints/ssh_connect.php';
        this.systemApiUrl = 'php/endpoints/system.php';
        this.usersApiUrl = 'php/endpoints/users.php';
        this.searchTimeout = null;
        this.statsInterval = null;
        this.onlineUsers = [];
        this.testUserCreated = false;
        this.testUserExpiry = null;

        // Inicializar
        this.init();
    }

    init() {
        this.loadTheme();
        this.initEventListeners();
        this.checkStoredCredentials();
        this.startAutoRefresh();
        this.loadUsers(); // Cargar usuarios al inicio si hay conexión
        this.checkTestUserStatus();
        console.log('✅ CEO MANAGER PRO v2.0 iniciado - @ReyRs_VIPro');
    }

    loadTheme() {
        const savedTheme = localStorage.getItem('ceo_theme') || 'light';
        document.documentElement.setAttribute('data-theme', savedTheme);
        const icon = document.querySelector('#themeToggle i');
        if (icon) {
            icon.className = savedTheme === 'dark' ? 'fas fa-sun' : 'fas fa-moon';
        }
    }

    initEventListeners() {
        // Toggle menú
        const menuToggle = document.getElementById('menuToggle');
        if (menuToggle) {
            menuToggle.addEventListener('click', () => this.toggleSidebar());
        }

        // Toggle tema
        const themeToggle = document.getElementById('themeToggle');
        if (themeToggle) {
            themeToggle.addEventListener('click', () => this.toggleTheme());
        }

        // Búsqueda
        const searchInput = document.getElementById('searchInput');
        if (searchInput) {
            searchInput.addEventListener('input', (e) => {
                clearTimeout(this.searchTimeout);
                this.searchTimeout = setTimeout(() => this.filterUsers(e.target.value), 300);
            });
        }

        // Botón de prueba
        const btnTest = document.getElementById('btnTest');
        if (btnTest) {
            btnTest.addEventListener('click', () => this.createTestUser());
        }

        // Botones principales
        const btnAddUser = document.getElementById('btnAddUser');
        if (btnAddUser) {
            btnAddUser.addEventListener('click', () => this.showUserModal());
        }

        const btnRefresh = document.getElementById('btnRefresh');
        if (btnRefresh) {
            btnRefresh.addEventListener('click', () => this.loadUsers());
        }

        // Navegación
        document.querySelectorAll('.nav-item').forEach(item => {
            item.addEventListener('click', (e) => this.handleNavigation(e));
        });

        // Submenú usuarios
        const usersMenu = document.getElementById('usersMenu');
        if (usersMenu) {
            usersMenu.addEventListener('click', (e) => {
                e.stopPropagation();
                this.toggleSubmenu('usersSubmenu', 'usersArrow');
            });
        }

        // Submenu items
        document.querySelectorAll('.submenu-item').forEach(item => {
            item.addEventListener('click', (e) => {
                e.stopPropagation();
                const section = item.dataset.section;
                if (section) {
                    this.changeSection(section);
                }
            });
        });

        // Modal de usuario
        const closeModal = document.getElementById('closeModal');
        if (closeModal) {
            closeModal.addEventListener('click', () => this.hideUserModal());
        }

        const cancelModal = document.getElementById('cancelModal');
        if (cancelModal) {
            cancelModal.addEventListener('click', () => this.hideUserModal());
        }

        const saveUser = document.getElementById('saveUser');
        if (saveUser) {
            saveUser.addEventListener('click', () => this.saveUser());
        }

        // Modal VPS
        const vpsMenuItem = document.querySelector('[data-section="vps"]');
        if (vpsMenuItem) {
            vpsMenuItem.addEventListener('click', () => this.showVpsModal());
        }

        const closeVpsModal = document.getElementById('closeVpsModal');
        if (closeVpsModal) {
            closeVpsModal.addEventListener('click', () => this.hideVpsModal());
        }

        const cancelVps = document.getElementById('cancelVps');
        if (cancelVps) {
            cancelVps.addEventListener('click', () => this.hideVpsModal());
        }

        const connectVps = document.getElementById('connectVps');
        if (connectVps) {
            connectVps.addEventListener('click', () => this.connectVPS());
        }

        // Modal Logs
        const logsMenuItem = document.querySelector('[data-section="logs"]');
        if (logsMenuItem) {
            logsMenuItem.addEventListener('click', () => this.showLogsModal());
        }

        const closeLogsModal = document.getElementById('closeLogsModal');
        if (closeLogsModal) {
            closeLogsModal.addEventListener('click', () => this.hideLogsModal());
        }

        const closeLogs = document.getElementById('closeLogs');
        if (closeLogs) {
            closeLogs.addEventListener('click', () => this.hideLogsModal());
        }

        const refreshLogs = document.getElementById('refreshLogs');
        if (refreshLogs) {
            refreshLogs.addEventListener('click', () => this.loadLogs());
        }

        // Modal Monitor
        const monitorMenuItem = document.querySelector('[data-section="monitor"]');
        if (monitorMenuItem) {
            monitorMenuItem.addEventListener('click', () => this.showMonitorModal());
        }

        const closeMonitorModal = document.getElementById('closeMonitorModal');
        if (closeMonitorModal) {
            closeMonitorModal.addEventListener('click', () => this.hideMonitorModal());
        }

        const closeMonitor = document.getElementById('closeMonitor');
        if (closeMonitor) {
            closeMonitor.addEventListener('click', () => this.hideMonitorModal());
        }

        // Logout
        const logoutBtn = document.getElementById('logoutBtn');
        if (logoutBtn) {
            logoutBtn.addEventListener('click', () => this.logout());
        }

        // Expiry days
        const expiryDays = document.getElementById('expiryDays');
        if (expiryDays) {
            expiryDays.addEventListener('change', (e) => this.calculateExpiryDate(e.target.value));
        }

        // Validación username
        const username = document.getElementById('username');
        if (username) {
            username.addEventListener('input', (e) => this.validateUsername(e.target));
        }
    }

    checkTestUserStatus() {
        const testExpiry = localStorage.getItem('ceo_test_expiry');
        if (testExpiry) {
            const expiry = new Date(parseInt(testExpiry));
            if (expiry > new Date()) {
                this.testUserCreated = true;
                this.testUserExpiry = expiry;
                // Programar eliminación automática
                const timeLeft = expiry - new Date();
                setTimeout(() => {
                    this.deleteTestUser();
                }, timeLeft);
            } else {
                localStorage.removeItem('ceo_test_expiry');
            }
        }
    }

    async createTestUser() {
        if (!this.sshConnected) {
            this.showNotification('Primero conecta al VPS', 'warning');
            return;
        }

        if (this.testUserCreated) {
            const confirm = window.confirm('Ya existe un usuario de prueba. ¿Deseas eliminarlo y crear uno nuevo?');
            if (confirm) {
                await this.deleteTestUser();
            } else {
                return;
            }
        }

        const testUsername = 'test_' + Math.random().toString(36).substring(2, 8);
        const testPassword = Math.random().toString(36).substring(2, 10);
        
        // Fecha de expiración: 1 hora desde ahora
        const expiry = new Date();
        expiry.setHours(expiry.getHours() + 1);
        const expiryDate = expiry.toISOString().split('T')[0];

        const testBtn = document.getElementById('btnTest');
        const originalText = testBtn.innerHTML;
        testBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Creando...';
        testBtn.disabled = true;

        try {
            const response = await this.makeRequest('add_user', {
                username: testUsername,
                password: testPassword,
                expiry_date: expiryDate,
                limit: 1
            });

            if (response.success) {
                this.testUserCreated = true;
                this.testUserExpiry = expiry;
                localStorage.setItem('ceo_test_expiry', expiry.getTime().toString());

                // Programar eliminación automática
                setTimeout(() => {
                    this.deleteTestUser();
                }, 60 * 60 * 1000); // 1 hora

                this.showNotification(
                    `✅ Usuario de prueba creado\nUsuario: ${testUsername}\nContraseña: ${testPassword}\nExpira: ${expiry.toLocaleTimeString()}`,
                    'success',
                    8000
                );

                await this.loadUsers();
            } else {
                throw new Error(response.message);
            }
        } catch (error) {
            this.showNotification('Error: ' + error.message, 'error');
        } finally {
            testBtn.innerHTML = originalText;
            testBtn.disabled = false;
        }
    }

    async deleteTestUser() {
        // Buscar usuarios de prueba (test_*)
        const testUsers = this.users.filter(u => u.username.startsWith('test_'));
        
        for (const user of testUsers) {
            try {
                await this.makeRequest('delete_user', { username: user.username });
            } catch (e) {
                console.error('Error deleting test user:', e);
            }
        }

        this.testUserCreated = false;
        this.testUserExpiry = null;
        localStorage.removeItem('ceo_test_expiry');
        
        await this.loadUsers();
    }

    toggleSidebar() {
        const sidebar = document.getElementById('sidebar');
        const mainContent = document.getElementById('mainContent');
        if (sidebar && mainContent) {
            sidebar.classList.toggle('collapsed');
            mainContent.classList.toggle('expanded');
        }
    }

    toggleTheme() {
        const current = document.documentElement.getAttribute('data-theme');
        const newTheme = current === 'dark' ? 'light' : 'dark';
        document.documentElement.setAttribute('data-theme', newTheme);
        localStorage.setItem('ceo_theme', newTheme);
        
        const icon = document.querySelector('#themeToggle i');
        if (icon) {
            icon.className = newTheme === 'dark' ? 'fas fa-sun' : 'fas fa-moon';
        }
    }

    toggleSubmenu(submenuId, arrowId) {
        const submenu = document.getElementById(submenuId);
        const arrow = document.getElementById(arrowId);
        
        if (submenu && arrow) {
            submenu.classList.toggle('show');
            arrow.classList.toggle('rotated');
        }
    }

    handleNavigation(e) {
        const item = e.currentTarget;
        if (item.classList.contains('has-submenu')) return;

        document.querySelectorAll('.nav-item').forEach(nav => nav.classList.remove('active'));
        item.classList.add('active');

        const section = item.dataset.section;
        if (section) {
            this.changeSection(section);
        }
    }

    changeSection(section) {
        this.currentSection = section;

        const titles = {
            'dashboard': 'Dashboard',
            'create-user': 'Crear Usuario',
            'list-users': 'Listado de Usuarios',
            'online-users': 'Usuarios en Línea',
            'expired-users': 'Usuarios Caducados',
            'monitor': 'Monitor VPS',
            'settings': 'Configuración',
            'vps': 'Conectar VPS',
            'logs': 'Logs del Sistema'
        };

        const sectionTitle = document.getElementById('sectionTitle');
        if (sectionTitle) {
            sectionTitle.textContent = titles[section] || 'Usuarios';
        }

        // Mostrar/ocultar dashboard
        const dashboardSection = document.getElementById('dashboardSection');
        if (dashboardSection) {
            dashboardSection.style.display = section === 'dashboard' ? 'block' : 'none';
        }

        // Acciones específicas
        switch(section) {
            case 'create-user':
                this.showUserModal();
                break;
            case 'list-users':
                this.loadUsers();
                break;
            case 'online-users':
                this.showOnlineUsers();
                break;
            case 'expired-users':
                this.showExpiredUsers();
                break;
            case 'monitor':
                this.showMonitorModal();
                break;
            case 'logs':
                this.showLogsModal();
                break;
            case 'vps':
                this.showVpsModal();
                break;
        }
    }

    checkStoredCredentials() {
        const saved = localStorage.getItem('ceo_vps_creds');
        if (saved) {
            try {
                const creds = JSON.parse(saved);
                if (creds.ip && creds.user) {
                    this.credentials = creds;
                    this.testConnection();
                }
            } catch (e) {
                console.error('Error loading credentials');
            }
        }
    }

    startAutoRefresh() {
        this.statsInterval = setInterval(() => {
            if (this.sshConnected) {
                this.loadUsers();
            }
        }, 30000);
    }

    async testConnection() {
        const statusEl = document.getElementById('connectionStatus');
        if (!statusEl) return;
        
        if (!this.credentials) {
            statusEl.className = 'connection-status disconnected';
            statusEl.innerHTML = '<div class="status-icon"></div><span>Esperando conexión al VPS...</span>';
            return;
        }

        try {
            statusEl.innerHTML = '<div class="status-icon"></div><span>Conectando...</span>';
            
            const response = await this.makeRequest('test_connection');
            
            if (response.success) {
                this.sshConnected = true;
                statusEl.className = 'connection-status connected';
                statusEl.innerHTML = `<div class="status-icon"></div><span>Conectado a ${this.credentials.ip}</span>`;
                this.loadUsers();
            } else {
                throw new Error(response.message || 'Error de conexión');
            }
        } catch (error) {
            this.sshConnected = false;
            statusEl.className = 'connection-status disconnected';
            statusEl.innerHTML = `<div class="status-icon"></div><span>Error: ${error.message}</span>`;
            this.showNotification('Error de conexión: ' + error.message, 'error');
        }
    }

    async loadUsers() {
        if (!this.sshConnected) {
            return;
        }

        const usersList = document.getElementById('usersList');
        if (usersList) {
            usersList.innerHTML = '<tr><td colspan="6" style="text-align: center; padding: 50px;"><div class="loading"></div><p style="margin-top: 15px;">Cargando usuarios...</p></td></tr>';
        }

        try {
            const response = await this.makeRequest('list_users');
            
            if (response.success) {
                this.users = response.users || [];
                
                // Simular usuarios online (en producción debería ser real)
                this.onlineUsers = this.users
                    .filter(() => Math.random() > 0.7)
                    .map(u => u.username);
                
                this.renderUsers();
                this.updateStats();
                this.updateBadges();
            } else {
                throw new Error(response.message);
            }
        } catch (error) {
            console.error('Error loading users:', error);
            if (usersList) {
                usersList.innerHTML = '<tr><td colspan="6" style="text-align: center; padding: 50px; color: var(--danger);"><i class="fas fa-exclamation-circle" style="font-size: 2rem;"></i><p style="margin-top: 15px;">Error al cargar usuarios</p></td></tr>';
            }
        }
    }

    renderUsers() {
        const tbody = document.getElementById('usersList');
        if (!tbody) return;
        
        if (!this.users || this.users.length === 0) {
            tbody.innerHTML = '<tr><td colspan="6" style="text-align: center; padding: 50px;"><i class="fas fa-users" style="font-size: 3rem; color: var(--gray); opacity: 0.3;"></i><p style="margin-top: 15px;">No hay usuarios SSH configurados</p></td></tr>';
            return;
        }

        let filteredUsers = this.users;

        // Filtrar según sección
        if (this.currentSection === 'online-users') {
            filteredUsers = this.users.filter(u => this.onlineUsers.includes(u.username));
        } else if (this.currentSection === 'expired-users') {
            filteredUsers = this.users.filter(u => this.isUserExpired(u.expiry_date));
        }

        tbody.innerHTML = filteredUsers.map(user => {
            const timeRemaining = this.calculateTimeRemaining(user.expiry_date);
            const isExpired = this.isUserExpired(user.expiry_date);
            const isOnline = this.onlineUsers.includes(user.username);
            
            let statusClass = 'status-active';
            let statusText = 'Activo';
            
            if (isExpired) {
                statusClass = 'status-expired';
                statusText = 'Caducado';
            } else if (isOnline) {
                statusClass = 'status-online';
                statusText = 'En Línea';
            } else if (timeRemaining.includes('1 día') || (timeRemaining.includes('días') && parseInt(timeRemaining) <= 7)) {
                statusClass = 'status-warning';
                statusText = 'Próximo a caducar';
            }
            
            const timeClass = isExpired ? 'time-danger' : 
                             (timeRemaining.includes('1 día') ? 'time-warning' : 
                             (timeRemaining.includes('días') && parseInt(timeRemaining) <= 7 ? 'time-warning' : 'time-normal'));

            return `
                <tr>
                    <td>
                        <div style="display: flex; align-items: center; gap: 10px;">
                            <i class="fas fa-user-circle" style="font-size: 1.5rem; color: var(--primary);"></i>
                            <strong>${this.escapeHtml(user.username)}</strong>
                            ${user.username.startsWith('test_') ? '<span style="background: var(--info); color: white; padding: 2px 8px; border-radius: 12px; font-size: 0.7rem;">TEST</span>' : ''}
                        </div>
                    </td>
                    <td>
                        <span class="user-status ${statusClass}">
                            <i class="fas fa-circle" style="font-size: 0.5rem;"></i>
                            ${statusText}
                        </span>
                    </td>
                    <td>${this.formatDate(user.expiry_date)}</td>
                    <td>
                        <span class="time-remaining ${timeClass}">
                            ${timeRemaining}
                        </span>
                    </td>
                    <td>${this.getLastLogin(user.username)}</td>
                    <td>
                        <div class="user-actions">
                            <button class="btn-icon edit" onclick="ceoManager.editUser('${this.escapeHtml(user.username)}')" title="Editar">
                                <i class="fas fa-edit"></i>
                            </button>
                            <button class="btn-icon extend" onclick="ceoManager.extendUser('${this.escapeHtml(user.username)}')" title="Extender">
                                <i class="fas fa-clock"></i>
                            </button>
                            <button class="btn-icon delete" onclick="ceoManager.deleteUser('${this.escapeHtml(user.username)}')" title="Eliminar">
                                <i class="fas fa-trash"></i>
                            </button>
                        </div>
                    </td>
                </tr>
            `;
        }).join('');
    }

    updateStats() {
        const total = this.users.length;
        const expired = this.users.filter(u => this.isUserExpired(u.expiry_date)).length;
        const online = this.onlineUsers.length;
        const activeToday = this.users.filter(u => {
            const expiry = new Date(u.expiry_date);
            const today = new Date();
            const diffDays = Math.ceil((expiry - today) / (1000 * 60 * 60 * 24));
            return diffDays >= 0 && diffDays <= 1;
        }).length;

        const totalEl = document.getElementById('totalUsers');
        const onlineEl = document.getElementById('onlineUsers');
        const expiredEl = document.getElementById('expiredUsers');
        const activeEl = document.getElementById('activeToday');
        
        if (totalEl) totalEl.textContent = total;
        if (onlineEl) onlineEl.textContent = online;
        if (expiredEl) expiredEl.textContent = expired;
        if (activeEl) activeEl.textContent = activeToday;

        this.updateCharts(total, expired, online);
    }

    updateBadges() {
        const online = this.onlineUsers.length;
        const expired = this.users.filter(u => this.isUserExpired(u.expiry_date)).length;
        
        const onlineBadge = document.getElementById('onlineCount');
        const expiredBadge = document.getElementById('expiredCount');
        
        if (onlineBadge) onlineBadge.textContent = online;
        if (expiredBadge) expiredBadge.textContent = expired;
    }

    updateCharts(total, expired, online) {
        if (window.userChart) window.userChart.destroy();
        if (window.activityChart) window.activityChart.destroy();

        const ctx1 = document.getElementById('userChart')?.getContext('2d');
        if (ctx1) {
            window.userChart = new Chart(ctx1, {
                type: 'doughnut',
                data: {
                    labels: ['Activos', 'Caducados', 'En Línea'],
                    datasets: [{
                        data: [Math.max(0, total - expired), expired, online],
                        backgroundColor: ['#19b53c', '#e5182c', '#17a2b8'],
                        borderWidth: 0
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                        legend: { position: 'bottom' }
                    }
                }
            });
        }

        // Actividad simulada
        const ctx2 = document.getElementById('activityChart')?.getContext('2d');
        if (ctx2) {
            window.activityChart = new Chart(ctx2, {
                type: 'line',
                data: {
                    labels: ['Lun', 'Mar', 'Mié', 'Jue', 'Vie', 'Sáb', 'Dom'],
                    datasets: [{
                        label: 'Conexiones',
                        data: [12, 19, 15, 17, 24, 30, 28],
                        borderColor: '#ffb909',
                        backgroundColor: 'rgba(255,185,9,0.1)',
                        tension: 0.4,
                        fill: true
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                        legend: { display: false }
                    }
                }
            });
        }
    }

    showOnlineUsers() {
        const online = this.users.filter(u => this.onlineUsers.includes(u.username));
        this.renderFilteredUsers(online, 'Usuarios en Línea');
    }

    showExpiredUsers() {
        const expired = this.users.filter(u => this.isUserExpired(u.expiry_date));
        this.renderFilteredUsers(expired, 'Usuarios Caducados');
    }

    renderFilteredUsers(users, title) {
        const sectionTitle = document.getElementById('sectionTitle');
        if (sectionTitle) {
            sectionTitle.textContent = title;
        }
        this.users = users;
        this.renderUsers();
    }

    isUserExpired(expiryDate) {
        const today = new Date();
        const expiry = new Date(expiryDate);
        today.setHours(0, 0, 0, 0);
        expiry.setHours(0, 0, 0, 0);
        return expiry < today;
    }

    calculateTimeRemaining(expiryDate) {
        try {
            const today = new Date();
            const expiry = new Date(expiryDate);
            today.setHours(0, 0, 0, 0);
            expiry.setHours(0, 0, 0, 0);
            
            const diffTime = expiry - today;
            const diffDays = Math.round(diffTime / (1000 * 60 * 60 * 24));
            
            if (diffDays < 0) return 'Caducado';
            if (diffDays === 0) return 'Hoy caduca';
            if (diffDays === 1) return '1 día';
            return `${diffDays} días`;
        } catch {
            return 'Fecha inválida';
        }
    }

    formatDate(dateString) {
        try {
            const date = new Date(dateString);
            return date.toLocaleDateString('es-ES', {
                year: 'numeric',
                month: '2-digit',
                day: '2-digit'
            });
        } catch {
            return dateString;
        }
    }

    getLastLogin(username) {
        // Simulación - en producción debe obtener del sistema
        const hours = Math.floor(Math.random() * 24);
        const minutes = Math.floor(Math.random() * 60);
        return `Hoy ${hours.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')}`;
    }

    showUserModal(username = null) {
        if (!this.sshConnected) {
            this.showNotification('Primero conecta al VPS', 'warning');
            return;
        }

        this.currentUser = username;
        const modal = document.getElementById('userModal');
        const title = document.getElementById('modalTitle');
        const form = document.getElementById('userForm');
        const passwordField = document.getElementById('password');
        
        if (username) {
            if (title) title.textContent = 'Editar Usuario SSH';
            if (passwordField) {
                passwordField.placeholder = 'Dejar vacío para no cambiar';
                passwordField.required = false;
            }
            this.loadUserData(username);
        } else {
            if (title) title.textContent = 'Crear Usuario SSH';
            if (form) form.reset();
            if (passwordField) {
                passwordField.placeholder = 'Contraseña';
                passwordField.required = true;
            }
            this.calculateExpiryDate(30);
        }
        
        if (modal) modal.classList.add('show');
    }

    hideUserModal() {
        const modal = document.getElementById('userModal');
        if (modal) modal.classList.remove('show');
        this.currentUser = null;
    }

    async loadUserData(username) {
        try {
            const response = await this.makeRequest('get_user', { username });
            
            if (response.success) {
                const usernameField = document.getElementById('username');
                const passwordField = document.getElementById('password');
                const expiryDate = document.getElementById('expiryDate');
                const expiryDays = document.getElementById('expiryDays');
                
                if (usernameField) usernameField.value = response.user.username;
                if (passwordField) passwordField.value = '';
                if (expiryDate) expiryDate.value = response.user.expiry_date;
                
                const expiry = new Date(response.user.expiry_date);
                const today = new Date();
                const diffTime = expiry - today;
                const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
                if (expiryDays) expiryDays.value = diffDays > 0 ? diffDays : 1;
            }
        } catch (error) {
            this.showNotification('Error al cargar usuario', 'error');
            this.hideUserModal();
        }
    }

    calculateExpiryDate(days) {
        const today = new Date();
        const expiry = new Date(today);
        expiry.setDate(today.getDate() + parseInt(days));
        const expiryDate = document.getElementById('expiryDate');
        if (expiryDate) {
            expiryDate.value = expiry.toISOString().split('T')[0];
        }
    }

    validateUsername(input) {
        const regex = /^[a-z_][a-z0-9_-]*$/;
        const isValid = regex.test(input.value) || input.value === '';
        input.style.borderColor = isValid ? '' : 'var(--danger)';
    }

    async saveUser() {
        const username = document.getElementById('username')?.value.trim();
        const password = document.getElementById('password')?.value;
        const expiryDate = document.getElementById('expiryDate')?.value;
        const limit = document.getElementById('limit')?.value;
        
        if (!username) {
            this.showNotification('Usuario requerido', 'warning');
            return;
        }

        if (!this.currentUser && !password) {
            this.showNotification('Contraseña requerida', 'warning');
            return;
        }

        const saveBtn = document.getElementById('saveUser');
        const originalText = saveBtn ? saveBtn.innerHTML : 'Guardar';
        if (saveBtn) {
            saveBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Guardando...';
            saveBtn.disabled = true;
        }

        const action = this.currentUser ? 'update_user' : 'add_user';
        const data = {
            username,
            expiry_date: expiryDate,
            limit: limit || 2
        };

        if (password) data.password = password;
        if (this.currentUser && this.currentUser !== username) {
            data.old_username = this.currentUser;
        }

        try {
            const response = await this.makeRequest(action, data);
            
            if (response.success) {
                this.showNotification(response.message, 'success');
                this.hideUserModal();
                await this.loadUsers();
            } else {
                throw new Error(response.message);
            }
        } catch (error) {
            this.showNotification('Error: ' + error.message, 'error');
        } finally {
            if (saveBtn) {
                saveBtn.innerHTML = originalText;
                saveBtn.disabled = false;
            }
        }
    }

    async deleteUser(username) {
        if (!confirm(`¿Eliminar usuario "${username}"?`)) return;

        try {
            const response = await this.makeRequest('delete_user', { username });
            
            if (response.success) {
                this.showNotification('Usuario eliminado', 'success');
                await this.loadUsers();
            } else {
                throw new Error(response.message);
            }
        } catch (error) {
            this.showNotification('Error: ' + error.message, 'error');
        }
    }

    async extendUser(username) {
        const days = prompt('¿Días a extender?', '30');
        if (!days || isNaN(days)) return;

        const user = this.users.find(u => u.username === username);
        if (!user) return;

        const currentExpiry = new Date(user.expiry_date);
        const newExpiry = new Date(currentExpiry);
        newExpiry.setDate(currentExpiry.getDate() + parseInt(days));

        try {
            const response = await this.makeRequest('update_user', {
                username,
                expiry_date: newExpiry.toISOString().split('T')[0]
            });

            if (response.success) {
                this.showNotification(`Usuario extendido ${days} días`, 'success');
                await this.loadUsers();
            } else {
                throw new Error(response.message);
            }
        } catch (error) {
            this.showNotification('Error: ' + error.message, 'error');
        }
    }

    editUser(username) {
        this.showUserModal(username);
    }

    filterUsers(searchTerm) {
        if (!searchTerm.trim()) {
            this.loadUsers();
            return;
        }

        const filtered = this.users.filter(u => 
            u.username.toLowerCase().includes(searchTerm.toLowerCase())
        );
        
        this.renderFilteredUsers(filtered, 'Resultados de Búsqueda');
    }

    showVpsModal() {
        const modal = document.getElementById('vpsModal');
        if (modal) modal.classList.add('show');
    }

    hideVpsModal() {
        const modal = document.getElementById('vpsModal');
        if (modal) modal.classList.remove('show');
    }

    connectVPS() {
        const ip = document.getElementById('vpsIp')?.value.trim();
        const user = document.getElementById('vpsUser')?.value.trim();
        const pass = document.getElementById('vpsPass')?.value.trim();
        const port = document.getElementById('vpsPort')?.value.trim() || '22';

        if (!ip || !user || !pass) {
            this.showNotification('Completa todos los campos', 'warning');
            return;
        }

        this.credentials = { ip, user, pass, port };
        
        // Guardar solo IP y usuario (no password)
        localStorage.setItem('ceo_vps_creds', JSON.stringify({ ip, user, port }));
        
        this.testConnection();
        this.hideVpsModal();
    }

    showLogsModal() {
        const modal = document.getElementById('logsModal');
        if (modal) {
            modal.classList.add('show');
            this.loadLogs();
        }
    }

    hideLogsModal() {
        const modal = document.getElementById('logsModal');
        if (modal) modal.classList.remove('show');
    }

    async loadLogs() {
        const logsContent = document.getElementById('logsContent');
        if (!logsContent) return;
        
        logsContent.innerHTML = '<div class="loading"></div><p>Cargando logs...</p>';
        
        try {
            // Intentar cargar logs del servidor
            const response = await fetch('includes/get_logs.php');
            const data = await response.json();
            
            if (data.success && data.logs && data.logs.length > 0) {
                logsContent.innerHTML = data.logs.map(log => 
                    `<div style="padding: 8px; border-bottom: 1px solid rgba(128,128,128,0.1); font-family: monospace; font-size: 0.9rem;">${this.escapeHtml(log)}</div>`
                ).join('');
            } else {
                // Logs simulados
                const logs = [
                    `[${new Date().toLocaleString()}] ✅ CEO MANAGER PRO v2.0 iniciado - @ReyRs_VIPro`,
                    `[${new Date().toLocaleString()}] 🔌 Conexión SSH establecida con ${this.credentials?.ip || 'VPS'}`,
                    `[${new Date().toLocaleString()}] 👤 Usuarios cargados: ${this.users.length}`,
                    `[${new Date().toLocaleString()}] 📊 Estadísticas actualizadas`,
                    `[${new Date().toLocaleString()}] 🔄 Panel funcionando correctamente`
                ];
                
                logsContent.innerHTML = logs.map(log => 
                    `<div style="padding: 8px; border-bottom: 1px solid rgba(128,128,128,0.1); font-family: monospace; font-size: 0.9rem;">${log}</div>`
                ).join('');
            }
        } catch (error) {
            logsContent.innerHTML = '<p style="color: var(--danger);">Error al cargar logs</p>';
        }
    }

    showMonitorModal() {
        const modal = document.getElementById('monitorModal');
        if (modal) {
            modal.classList.add('show');
            this.loadSystemStats();
        }
    }

    hideMonitorModal() {
        const modal = document.getElementById('monitorModal');
        if (modal) modal.classList.remove('show');
    }

    async loadSystemStats() {
        if (!this.sshConnected) {
            this.showNotification('Sin conexión al VPS', 'warning');
            return;
        }

        try {
            const response = await this.makeRequest('system_info');
            
            if (response.success) {
                const cpuEl = document.getElementById('cpuUsage');
                const ramEl = document.getElementById('ramUsage');
                const diskEl = document.getElementById('diskUsage');
                const uptimeEl = document.getElementById('uptime');
                
                if (cpuEl) cpuEl.textContent = (response.cpu || 0) + '%';
                if (ramEl) ramEl.textContent = (response.ram || 0) + '%';
                if (diskEl) diskEl.textContent = (response.disk || 0) + '%';
                if (uptimeEl) uptimeEl.textContent = response.uptime || '0';
            }
        } catch (error) {
            console.error('Error loading system stats');
            // Valores simulados si falla
            const cpuEl = document.getElementById('cpuUsage');
            const ramEl = document.getElementById('ramUsage');
            const diskEl = document.getElementById('diskUsage');
            const uptimeEl = document.getElementById('uptime');
            
            if (cpuEl) cpuEl.textContent = '45%';
            if (ramEl) ramEl.textContent = '62%';
            if (diskEl) diskEl.textContent = '38%';
            if (uptimeEl) uptimeEl.textContent = '2 días, 5 horas';
        }
    }

    async makeRequest(action, data = {}) {
        if (!this.credentials) {
            throw new Error('Credenciales no configuradas');
        }

        const response = await fetch(this.apiBaseUrl, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                action,
                ...data,
                ...this.credentials
            })
        });

        if (!response.ok) {
            throw new Error('Error en la petición');
        }

        return await response.json();
    }

    showNotification(message, type = 'success', duration = 3000) {
        const notification = document.getElementById('notification');
        const messageSpan = document.getElementById('notificationMessage');
        
        if (!notification || !messageSpan) return;
        
        notification.className = `notification ${type}`;
        messageSpan.innerHTML = message.replace(/\n/g, '<br>');
        
        const icon = notification.querySelector('i');
        if (icon) {
            icon.className = type === 'success' ? 'fas fa-check-circle' :
                            type === 'error' ? 'fas fa-exclamation-circle' :
                            'fas fa-exclamation-triangle';
        }
        
        notification.classList.add('show');
        
        setTimeout(() => {
            notification.classList.remove('show');
        }, duration);
    }

    logout() {
        window.location.href = 'logout.php';
    }

    escapeHtml(text) {
        const div = document.createElement('div');
        div.textContent = text;
        return div.innerHTML;
    }
}

// Inicializar la aplicación
document.addEventListener('DOMContentLoaded', () => {
    window.ceoManager = new CEOManager();
});