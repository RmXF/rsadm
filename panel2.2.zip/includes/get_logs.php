<?php
/**
 * ====================================================
 * CEO MANAGER PRO v2.0
 * Obtener Logs
 * Author: @ReyRs_VIPro
 * ====================================================
 */

session_start();
header('Content-Type: application/json');

if (!isset($_SESSION['ceo_logged_in']) || $_SESSION['ceo_logged_in'] !== true) {
    echo json_encode(['success' => false, 'message' => 'No autorizado']);
    exit();
}

$logFile = __DIR__ . '/../logs/panel.log';
$logs = [];

if (file_exists($logFile)) {
    $content = file($logFile);
    $logs = array_slice($content, -50); // Últimas 50 líneas
    $logs = array_map('trim', $logs);
}

echo json_encode(['success' => true, 'logs' => $logs]);
?>