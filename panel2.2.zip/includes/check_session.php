<?php
/**
 * ====================================================
 * CEO MANAGER PRO v1.0
 * Verificador de Sesión
 * Author: @ReyRs_VIPro
 * ====================================================
 */

session_start();
header('Content-Type: application/json');

if (isset($_SESSION['ceo_logged_in']) && $_SESSION['ceo_logged_in'] === true) {
    echo json_encode([
        'logged_in' => true,
        'user' => $_SESSION['ceo_user'] ?? 'Admin'
    ]);
} else {
    echo json_encode(['logged_in' => false]);
}
?>