<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, GET, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

// Manejar preflight OPTIONS request
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

// Función para enviar respuestas consistentes
function sendResponse($success, $message = '', $data = []) {
    $response = ['success' => $success];
    if ($message) $response['message'] = $message;
    if (!empty($data)) $response = array_merge($response, $data);
    
    echo json_encode($response);
    exit();
}

class SSHExecManager {
    private $credentials;
    
    public function __construct($credentials) {
        $this->credentials = $credentials;
    }
    
    public function executeRemoteCommand($command) {
        try {
            // Escapar credenciales para seguridad
            $ip = escapeshellarg($this->credentials['ip']);
            $user = escapeshellarg($this->credentials['user']);
            $pass = $this->credentials['pass'];
            $port = $this->credentials['port'] ?? 8022; // Puerto por defecto para Termux
            
            // Construir comando SSH con sshpass
            $sshCommand = "sshpass -p " . escapeshellarg($pass) . 
                         " ssh -o StrictHostKeyChecking=no" .
                         " -o ConnectTimeout=10" .
                         " -o BatchMode=no" .
                         " -o UserKnownHostsFile=/dev/null" .
                         " -p " . escapeshellarg($port) . 
                         " " . $user . "@" . $ip . 
                         " " . escapeshellarg($command . " 2>&1");
            
            $output = [];
            $return_var = 0;
            
            // Ejecutar comando
            exec($sshCommand, $output, $return_var);
            
            $result = implode("\n", $output);
            
            if ($return_var !== 0) {
                return [
                    'success' => false, 
                    'message' => 'Error SSH: ' . $result,
                    'command' => $sshCommand
                ];
            }
            
            return ['success' => true, 'output' => $result];
            
        } catch (Exception $e) {
            return ['success' => false, 'message' => $e->getMessage()];
        }
    }
    
    public function testConnection() {
        $result = $this->executeRemoteCommand('echo "connection_test_ok"');
        return $result;
    }
}

// Función auxiliar para obtener fecha de expiración
function getUserExpiry($ssh, $username) {
    $command = "chage -l " . escapeshellarg($username) . " 2>/dev/null | grep 'Account expires' | cut -d: -f2";
    $result = $ssh->executeRemoteCommand($command);
    
    if ($result['success'] && !empty($result['output'])) {
        $expiry = trim($result['output']);
        if (strtolower($expiry) === 'never' || empty($expiry) || trim($expiry) === '') {
            return '2099-12-31';
        }
        
        // Parsear fecha en formato inglés
        $expiry = trim($expiry);
        $parsed_date = strtotime($expiry);
        if ($parsed_date !== false) {
            return date('Y-m-d', $parsed_date);
        }
    }
    
    return '2099-12-31';
}

// Función auxiliar para obtener estado del usuario
function getUserStatus($ssh, $username) {
    $command = "passwd -S " . escapeshellarg($username) . " 2>/dev/null | awk '{print $2}'";
    $result = $ssh->executeRemoteCommand($command);
    
    if ($result['success'] && !empty($result['output'])) {
        $status = trim($result['output']);
        if ($status === 'P') return 'active';
        if ($status === 'L') return 'locked';
        if ($status === 'NP') return 'no-password';
    }
    
    return 'unknown';
}

// Función para verificar si usuario existe
function userExists($ssh, $username) {
    $command = "id " . escapeshellarg($username) . " 2>/dev/null && echo 'EXISTS' || echo 'NOT_EXISTS'";
    $result = $ssh->executeRemoteCommand($command);
    return $result['success'] && strpos($result['output'], 'EXISTS') !== false;
}

// Manejar las solicitudes
try {
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        sendResponse(false, 'Método no permitido');
    }

    // Obtener y validar input JSON
    $input_json = file_get_contents('php://input');
    if (empty($input_json)) {
        sendResponse(false, 'Datos JSON requeridos');
    }

    $input = json_decode($input_json, true);
    if (json_last_error() !== JSON_ERROR_NONE) {
        sendResponse(false, 'JSON inválido: ' . json_last_error_msg());
    }
    
    $action = $input['action'] ?? '';
    
    // Verificar credenciales SSH
    if (!isset($input['ip']) || empty($input['ip'])) {
        sendResponse(false, 'IP del servidor SSH requerida');
    }
    
    if (!isset($input['user']) || empty($input['user'])) {
        sendResponse(false, 'Usuario SSH requerido');
    }
    
    if (!isset($input['pass']) || empty($input['pass'])) {
        sendResponse(false, 'Contraseña SSH requerida');
    }
    
    $ssh = new SSHExecManager($input);
    
    switch ($action) {
        case 'test_connection':
            $result = $ssh->testConnection();
            if ($result['success'] && trim($result['output']) === 'connection_test_ok') {
                sendResponse(true, 'Conexión SSH exitosa');
            } else {
                sendResponse(false, 'Error de conexión: ' . ($result['message'] ?? 'No se pudo verificar la conexión'));
            }
            break;
            
        case 'list_users':
            // Obtener usuarios del sistema
            $command = "cat /etc/passwd 2>/dev/null | grep -E ':/bin/(bash|sh)' | cut -d: -f1";
            $result = $ssh->executeRemoteCommand($command);
            
            if (!$result['success']) {
                sendResponse(false, 'Error al listar usuarios: ' . $result['message']);
            }
            
            $users = array_filter(explode("\n", $result['output']));
            
            // Filtrar usuarios del sistema
            $system_users = [
                'root', 'daemon', 'bin', 'sys', 'sync', 'games', 'man', 'lp', 'mail', 
                'news', 'uucp', 'proxy', 'www-data', 'backup', 'list', 'irc', 'gnats', 
                'nobody', 'systemd-timesync', 'systemd-network', 'systemd-resolve', 
                'messagebus', 'syslog', '_apt', 'systemd', 'apt', 'sshd'
            ];
            
            $ssh_users = array_values(array_diff($users, $system_users));
            
            $user_details = [];
            foreach ($ssh_users as $username) {
                $username = trim($username);
                if (empty($username)) continue;
                
                $user_details[] = [
                    'username' => $username,
                    'expiry_date' => getUserExpiry($ssh, $username),
                    'status' => getUserStatus($ssh, $username)
                ];
            }
            
            sendResponse(true, 'Usuarios obtenidos exitosamente', ['users' => $user_details]);
            break;
            
        case 'get_user':
            $username = $input['username'] ?? '';
            if (empty($username)) {
                sendResponse(false, 'Usuario es requerido');
            }
            
            // Verificar si el usuario existe
            if (!userExists($ssh, $username)) {
                sendResponse(false, 'Usuario no encontrado');
            }
            
            $user_details = [
                'username' => $username,
                'expiry_date' => getUserExpiry($ssh, $username),
                'status' => getUserStatus($ssh, $username)
            ];
            
            sendResponse(true, 'Usuario obtenido exitosamente', ['user' => $user_details]);
            break;
            
        case 'add_user':
            $username = $input['username'] ?? '';
            $password = $input['password'] ?? '';
            $expiry_date = $input['expiry_date'] ?? '';
            
            if (empty($username)) {
                sendResponse(false, 'Usuario es requerido');
            }
            
            if (empty($password)) {
                sendResponse(false, 'Contraseña es requerida');
            }
            
            // Validar formato de usuario (solo letras, números, guiones)
            if (!preg_match('/^[a-z_][a-z0-9_-]*$/i', $username)) {
                sendResponse(false, 'Nombre de usuario inválido. Solo letras, números, guiones y guiones bajos');
            }
            
            // Verificar si el usuario ya existe
            if (userExists($ssh, $username)) {
                sendResponse(false, 'El usuario ya existe');
            }
            
            // Crear usuario
            $command = "useradd -m -s /bin/bash " . escapeshellarg($username);
            $result = $ssh->executeRemoteCommand($command);
            
            if (!$result['success']) {
                sendResponse(false, 'Error creando usuario: ' . $result['message']);
            }
            
            // Establecer contraseña
            $command = "echo " . escapeshellarg("$username:$password") . " | chpasswd";
            $result = $ssh->executeRemoteCommand($command);
            
            if (!$result['success']) {
                // Limpiar: eliminar usuario si falla
                $ssh->executeRemoteCommand("userdel -r " . escapeshellarg($username));
                sendResponse(false, 'Error estableciendo contraseña: ' . $result['message']);
            }
            
            // Establecer fecha de expiración si se proporciona
            if (!empty($expiry_date) && $expiry_date !== '2099-12-31') {
                $command = "chage -E " . escapeshellarg($expiry_date) . " " . escapeshellarg($username);
                $ssh->executeRemoteCommand($command);
            }
            
            sendResponse(true, 'Usuario creado exitosamente');
            break;
            
        case 'delete_user':
            $username = $input['username'] ?? '';
            
            if (empty($username)) {
                sendResponse(false, 'Usuario es requerido');
            }
            
            // Verificar si el usuario existe
            if (!userExists($ssh, $username)) {
                sendResponse(false, 'Usuario no encontrado');
            }
            
            // Eliminar usuario
            $command = "userdel -r " . escapeshellarg($username);
            $result = $ssh->executeRemoteCommand($command);
            
            if ($result['success']) {
                sendResponse(true, 'Usuario eliminado exitosamente');
            } else {
                sendResponse(false, 'Error eliminando usuario: ' . $result['message']);
            }
            break;
            
        case 'update_user':
            $username = $input['username'] ?? '';
            $old_username = $input['old_username'] ?? $username;
            $password = $input['password'] ?? '';
            $expiry_date = $input['expiry_date'] ?? '';
            
            if (empty($username)) {
                sendResponse(false, 'Usuario es requerido');
            }
            
            // Verificar si el usuario existe
            if (!userExists($ssh, $old_username)) {
                sendResponse(false, 'Usuario no encontrado');
            }
            
            // Cambiar nombre de usuario si es diferente
            if ($username !== $old_username) {
                // Verificar si el nuevo nombre ya existe
                if (userExists($ssh, $username)) {
                    sendResponse(false, 'El nuevo nombre de usuario ya existe');
                }
                
                $command = "usermod -l " . escapeshellarg($username) . " " . escapeshellarg($old_username);
                $result = $ssh->executeRemoteCommand($command);
                if (!$result['success']) {
                    sendResponse(false, 'Error cambiando nombre de usuario: ' . $result['message']);
                }
            }
            
            // Cambiar contraseña si se proporciona
            if (!empty($password)) {
                $command = "echo " . escapeshellarg("$username:$password") . " | chpasswd";
                $result = $ssh->executeRemoteCommand($command);
                
                if (!$result['success']) {
                    sendResponse(false, 'Error cambiando contraseña: ' . $result['message']);
                }
            }
            
            // Actualizar fecha de expiración
            if (!empty($expiry_date)) {
                $command = "chage -E " . escapeshellarg($expiry_date) . " " . escapeshellarg($username);
                $ssh->executeRemoteCommand($command);
            }
            
            sendResponse(true, 'Usuario actualizado exitosamente');
            break;
            
        case 'change_password':
            $username = $input['username'] ?? '';
            $password = $input['password'] ?? '';
            
            if (empty($username)) {
                sendResponse(false, 'Usuario es requerido');
            }
            
            if (empty($password)) {
                sendResponse(false, 'Contraseña es requerida');
            }
            
            // Verificar si el usuario existe
            if (!userExists($ssh, $username)) {
                sendResponse(false, 'Usuario no encontrado');
            }
            
            $command = "echo " . escapeshellarg("$username:$password") . " | chpasswd";
            $result = $ssh->executeRemoteCommand($command);
            
            if ($result['success']) {
                sendResponse(true, 'Contraseña cambiada exitosamente');
            } else {
                sendResponse(false, 'Error cambiando contraseña: ' . $result['message']);
            }
            break;
            
        default:
            sendResponse(false, 'Acción no válida: ' . $action);
    }
    
} catch (Exception $e) {
    error_log("General Error: " . $e->getMessage());
    sendResponse(false, 'Error interno del servidor: ' . $e->getMessage());
}
?>