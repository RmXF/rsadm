class SSHManager {
    constructor() {
        this.users = [];
        this.currentUser = null;
        this.sshConnected = false;
        
        this.initializeEventListeners();
        // No llamar testConnection automáticamente, esperar credenciales
    }

    initializeEventListeners() {
        // Botones principales
        document.getElementById('btnAddUser').addEventListener('click', () => this.showModal());
        document.getElementById('btnRefresh').addEventListener('click', () => this.loadUsers());
        
        // Modal de usuario
        document.getElementById('closeModal').addEventListener('click', () => this.hideModal());
        document.getElementById('cancelModal').addEventListener('click', () => this.hideModal());
        document.getElementById('saveUser').addEventListener('click', () => this.saveUser());
        
        // Búsqueda
        document.getElementById('searchInput').addEventListener('input', (e) => this.filterUsers(e.target.value));
        
        // Tema
        document.getElementById('themeToggle').addEventListener('click', () => this.toggleTheme());
        
        // Auto-calcular fecha de expiración
        document.getElementById('expiryDays').addEventListener('change', (e) => this.calculateExpiryDate(e.target.value));
    }

    // Método para establecer credenciales y conectar
    setCredentials(ip, user, pass, port = 22) {
        this.credentials = {
            ip: ip,
            user: user,
            pass: pass,
            port: port
        };
        this.testConnection();
    }

    async testConnection() {
        const statusElement = document.getElementById('connectionStatus');
        
        if (!this.credentials) {
            statusElement.className = 'connection-status status-disconnected';
            statusElement.innerHTML = '<div class="status-icon"></div><span>Esperando credenciales SSH</span>';
            return;
        }

        try {
            const response = await this.makeRequest('test_connection');
            if (response.success) {
                this.sshConnected = true;
                statusElement.className = 'connection-status status-connected';
                statusElement.innerHTML = '<div class="status-icon"></div><span>Conectado al VPS</span>';
                this.loadUsers();
            } else {
                throw new Error(response.message);
            }
        } catch (error) {
            this.sshConnected = false;
            statusElement.className = 'connection-status status-disconnected';
            statusElement.innerHTML = `<div class="status-icon"></div><span>Error de conexión: ${error.message}</span>`;
            this.showNotification('Error de conexión SSH: ' + error.message, true);
        }
    }

    async loadUsers() {
        if (!this.sshConnected) {
            this.showNotification('No hay conexión al VPS', true);
            return;
        }

        try {
            const response = await this.makeRequest('list_users');
            if (response.success) {
                this.users = response.users;
                this.renderUsers();
            } else {
                throw new Error(response.message);
            }
        } catch (error) {
            this.showNotification('Error al cargar usuarios: ' + error.message, true);
        }
    }

    renderUsers() {
        const usersList = document.getElementById('usersList');
        
        if (this.users.length === 0) {
            usersList.innerHTML = '<div class="no-users">No hay usuarios SSH configurados</div>';
            return;
        }
        
        usersList.innerHTML = this.users.map(user => {
            const timeRemaining = this.calculateTimeRemaining(user.expiry_date);
            const statusClass = this.getStatusClass(timeRemaining);
            const userClass = this.getUserClass(timeRemaining);
            
            return `
                <div class="user-item ${userClass}">
                    <div class="user-username">
                        <div class="user-icon"></div>
                        ${this.escapeHtml(user.username)}
                    </div>
                    <div>••••••••</div>
                    <div>${new Date(user.expiry_date).toLocaleDateString()}</div>
                    <div>
                        <span class="time-remaining ${statusClass}">
                            ${timeRemaining}
                        </span>
                    </div>
                    <div>${user.status}</div>
                    <div class="user-actions">
                        <button class="btn-action btn-edit" data-username="${this.escapeHtml(user.username)}">Editar</button>
                        <button class="btn-action btn-extend" data-username="${this.escapeHtml(user.username)}">Extender</button>
                        <button class="btn-action btn-delete" data-username="${this.escapeHtml(user.username)}">Eliminar</button>
                    </div>
                </div>
            `;
        }).join('');

        this.attachEventListenersToButtons();
    }

    calculateTimeRemaining(expiryDate) {
        const now = new Date();
        const expiry = new Date(expiryDate);
        const diffTime = expiry - now;
        const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
        
        if (diffDays < 0) {
            return 'Expirado';
        } else if (diffDays === 0) {
            return 'Hoy expira';
        } else if (diffDays === 1) {
            return '1 día';
        } else {
            return `${diffDays} días`;
        }
    }

    getStatusClass(timeRemaining) {
        if (timeRemaining === 'Expirado') return 'time-danger';
        if (timeRemaining === 'Hoy expira') return 'time-danger';
        if (timeRemaining.includes('1 día')) return 'time-warning';
        if (timeRemaining.includes('días')) {
            const days = parseInt(timeRemaining);
            if (days <= 7) return 'time-warning';
        }
        return 'time-normal';
    }

    getUserClass(timeRemaining) {
        if (timeRemaining === 'Expirado') return 'expired';
        if (timeRemaining === 'Hoy expira' || timeRemaining.includes('1 día')) return 'warning';
        return '';
    }

    showModal(username = null) {
        if (!this.sshConnected) {
            this.showNotification('Primero debes conectar al servidor SSH', true);
            return;
        }

        this.currentUser = username;
        const modal = document.getElementById('userModal');
        const title = document.getElementById('modalTitle');
        const form = document.getElementById('userForm');
        
        if (username) {
            title.textContent = 'Editar Usuario SSH';
            this.loadUserData(username);
        } else {
            title.textContent = 'Agregar Usuario SSH';
            form.reset();
            this.calculateExpiryDate(30); // Valor por defecto
        }
        
        modal.classList.add('show');
    }

    hideModal() {
        document.getElementById('userModal').classList.remove('show');
        this.currentUser = null;
    }

    async loadUserData(username) {
        try {
            const response = await this.makeRequest('get_user', { username: username });
            if (response.success) {
                document.getElementById('username').value = response.user.username;
                document.getElementById('password').value = ''; // No mostrar contraseña actual
                document.getElementById('expiryDate').value = response.user.expiry_date;
                
                // Calcular días restantes para mostrar en expiryDays
                const expiry = new Date(response.user.expiry_date);
                const today = new Date();
                const diffTime = expiry - today;
                const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
                document.getElementById('expiryDays').value = diffDays > 0 ? diffDays : 1;
            } else {
                throw new Error(response.message);
            }
        } catch (error) {
            this.showNotification('Error al cargar datos del usuario: ' + error.message, true);
            this.hideModal();
        }
    }

    calculateExpiryDate(days) {
        const today = new Date();
        const expiryDate = new Date(today);
        expiryDate.setDate(today.getDate() + parseInt(days));
        
        document.getElementById('expiryDate').value = expiryDate.toISOString().split('T')[0];
    }

    async saveUser() {
        const username = document.getElementById('username').value;
        const password = document.getElementById('password').value;
        const expiryDate = document.getElementById('expiryDate').value;
        
        if (!username.trim()) {
            this.showNotification('Usuario es requerido', true);
            return;
        }

        if (!this.currentUser && !password.trim()) {
            this.showNotification('La contraseña es requerida para nuevos usuarios', true);
            return;
        }

        if (!this.validateUsername(username)) {
            this.showNotification('Nombre de usuario inválido. Solo letras minúsculas, números, guiones y guiones bajos', true);
            return;
        }

        const action = this.currentUser ? 'update_user' : 'add_user';
        const data = {
            username: username,
            expiry_date: expiryDate
        };

        // Solo incluir password si se proporcionó (para nuevos usuarios o cuando se cambia)
        if (password.trim()) {
            data.password = password;
        }

        if (this.currentUser && this.currentUser !== username) {
            data.old_username = this.currentUser;
        }

        try {
            const response = await this.makeRequest(action, data);
            if (response.success) {
                this.showNotification(response.message);
                this.hideModal();
                this.loadUsers();
            } else {
                throw new Error(response.message);
            }
        } catch (error) {
            this.showNotification('Error: ' + error.message, true);
        }
    }

    validateUsername(username) {
        const regex = /^[a-z_][a-z0-9_-]*$/;
        return regex.test(username);
    }

    async deleteUser(username) {
        if (!confirm(`¿Estás seguro de que quieres eliminar el usuario "${username}"?`)) {
            return;
        }

        try {
            const response = await this.makeRequest('delete_user', { username: username });
            if (response.success) {
                this.showNotification(response.message);
                this.loadUsers();
            } else {
                throw new Error(response.message);
            }
        } catch (error) {
            this.showNotification('Error: ' + error.message, true);
        }
    }

    async extendUser(username) {
        const newExpiryDate = new Date();
        newExpiryDate.setDate(newExpiryDate.getDate() + 30); // Extender 30 días
        
        try {
            const response = await this.makeRequest('update_user', {
                username: username,
                expiry_date: newExpiryDate.toISOString().split('T')[0]
            });
            
            if (response.success) {
                this.showNotification('Usuario extendido por 30 días');
                this.loadUsers();
            } else {
                throw new Error(response.message);
            }
        } catch (error) {
            this.showNotification('Error: ' + error.message, true);
        }
    }

    editUser(username) {
        this.showModal(username);
    }

    filterUsers(searchTerm) {
        if (!searchTerm.trim()) {
            this.renderUsers();
            return;
        }

        const filteredUsers = this.users.filter(user => 
            user.username.toLowerCase().includes(searchTerm.toLowerCase())
        );
        
        this.renderFilteredUsers(filteredUsers);
    }

    renderFilteredUsers(filteredUsers) {
        const usersList = document.getElementById('usersList');
        
        if (filteredUsers.length === 0) {
            usersList.innerHTML = '<div class="no-users">No se encontraron usuarios</div>';
            return;
        }
        
        usersList.innerHTML = filteredUsers.map(user => {
            const timeRemaining = this.calculateTimeRemaining(user.expiry_date);
            const statusClass = this.getStatusClass(timeRemaining);
            const userClass = this.getUserClass(timeRemaining);
            
            return `
                <div class="user-item ${userClass}">
                    <div class="user-username">
                        <div class="user-icon"></div>
                        ${this.escapeHtml(user.username)}
                    </div>
                    <div>••••••••</div>
                    <div>${new Date(user.expiry_date).toLocaleDateString()}</div>
                    <div>
                        <span class="time-remaining ${statusClass}">
                            ${timeRemaining}
                        </span>
                    </div>
                    <div>${user.status}</div>
                    <div class="user-actions">
                        <button class="btn-action btn-edit" data-username="${this.escapeHtml(user.username)}">Editar</button>
                        <button class="btn-action btn-extend" data-username="${this.escapeHtml(user.username)}">Extender</button>
                        <button class="btn-action btn-delete" data-username="${this.escapeHtml(user.username)}">Eliminar</button>
                    </div>
                </div>
            `;
        }).join('');

        this.attachEventListenersToButtons();
    }

    async makeRequest(action, data = {}) {
        if (!this.credentials) {
            throw new Error('Credenciales SSH no configuradas');
        }

        const response = await fetch('/ssh/php/endpoints/ssh_connect.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                action: action,
                ...data,
                ...this.credentials
            })
        });
        
        if (!response.ok) {
            throw new Error('Error en la respuesta del servidor');
        }
        
        return await response.json();
    }

    showNotification(message, isError = false) {
        const notification = document.getElementById('notification');
        notification.textContent = message;
        notification.className = `notification ${isError ? 'error' : ''} show`;
        
        setTimeout(() => {
            notification.classList.remove('show');
        }, 3000);
    }

    toggleTheme() {
        const currentTheme = document.documentElement.getAttribute('data-theme');
        const newTheme = currentTheme === 'dark' ? 'light' : 'dark';
        document.documentElement.setAttribute('data-theme', newTheme);
        localStorage.setItem('theme', newTheme);
    }

    // Métodos auxiliares
    escapeHtml(text) {
        const div = document.createElement('div');
        div.textContent = text;
        return div.innerHTML;
    }

    attachEventListenersToButtons() {
        // Botones de editar
        document.querySelectorAll('.btn-edit').forEach(button => {
            button.addEventListener('click', (e) => {
                const username = e.target.getAttribute('data-username');
                this.editUser(username);
            });
        });

        // Botones de extender
        document.querySelectorAll('.btn-extend').forEach(button => {
            button.addEventListener('click', (e) => {
                const username = e.target.getAttribute('data-username');
                this.extendUser(username);
            });
        });

        // Botones de eliminar
        document.querySelectorAll('.btn-delete').forEach(button => {
            button.addEventListener('click', (e) => {
                const username = e.target.getAttribute('data-username');
                this.deleteUser(username);
            });
        });
    }
}

// Inicializar la aplicación cuando el DOM esté listo
document.addEventListener('DOMContentLoaded', () => {
    let sshManager = null;
    
    // Cargar tema guardado
    const savedTheme = localStorage.getItem('theme');
    if (savedTheme) {
        document.documentElement.setAttribute('data-theme', savedTheme);
    }
    
    // Modal de credenciales SSH
    document.getElementById("openmodalCred").addEventListener("click", function() {
        document.getElementById("modalCred").style.display = "flex";
    });

    // Conectar SSH
    document.getElementById("sshcon").addEventListener("click", function() {
        const ip = document.getElementById('input1').value.trim();
        const user = document.getElementById('input2').value.trim();
        const pass = document.getElementById('input3').value.trim();
        const port = document.getElementById('input4').value.trim() || '8022';

        if (!ip || !user || !pass) {
            alert('Por favor completa todos los campos de conexión SSH');
            return;
        }

        if (!sshManager) {
            sshManager = new SSHManager();
        }

        sshManager.setCredentials(ip, user, pass, port);
        document.getElementById("modalCred").style.display = "none";
    });

    // Cancelar conexión SSH
    document.getElementById("canceladdsssh").addEventListener("click", function() {
        document.getElementById("modalCred").style.display = "none";
    });

    // Cerrar modal con ESC
    document.addEventListener('keydown', function(e) {
        if (e.key === 'Escape') {
            const userModal = document.getElementById('userModal');
            const credModal = document.getElementById('modalCred');
            
            if (userModal.classList.contains('show')) {
                if (sshManager) sshManager.hideModal();
            }
            
            if (credModal.style.display === 'flex') {
                credModal.style.display = 'none';
            }
        }
    });

    // Cerrar modal haciendo click fuera
    document.addEventListener('click', function(e) {
        const userModal = document.getElementById('userModal');
        const credModal = document.getElementById('modalCred');
        
        if (e.target === userModal) {
            if (sshManager) sshManager.hideModal();
        }
        
        if (e.target === credModal) {
            credModal.style.display = 'none';
        }
    });
});