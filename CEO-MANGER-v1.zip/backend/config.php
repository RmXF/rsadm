<?php
session_start();

define('INSTALL_FILE', __DIR__ . '/storage/app/install.json');

function getInstallData() {
    if (!file_exists(INSTALL_FILE)) {
        die("Sistema no instalado.");
    }

    return json_decode(file_get_contents(INSTALL_FILE), true);
}
