<?php
require 'config.php';

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $data = getInstallData();

    $user = $_POST['username'] ?? '';
    $pass = $_POST['password'] ?? '';

    if ($user === $data['admin_user'] && $pass === $data['admin_pass']) {

        $_SESSION['user'] = $user;
        header("Location: dashboard.php");
        exit;

    } else {
        $error = "Credenciales incorrectas.";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
<title>CEO MANGER - Login</title>
<style>
body {
    background:#0f172a;
    font-family: Arial;
    display:flex;
    justify-content:center;
    align-items:center;
    height:100vh;
}
.card {
    background:#1e293b;
    padding:40px;
    border-radius:10px;
    width:300px;
    color:white;
}
input {
    width:100%;
    padding:10px;
    margin:10px 0;
    border:none;
    border-radius:5px;
}
button {
    width:100%;
    padding:10px;
    background:#3b82f6;
    border:none;
    color:white;
    border-radius:5px;
}
.error {
    color:red;
}
</style>
</head>
<body>

<div class="card">
<h2>CEO MANGER</h2>

<?php if($error): ?>
<p class="error"><?= $error ?></p>
<?php endif; ?>

<form method="POST">
<input type="text" name="username" placeholder="Usuario" required>
<input type="password" name="password" placeholder="Contraseña" required>
<button type="submit">Ingresar</button>
</form>

</div>

</body>
</html>
