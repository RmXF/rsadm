<?php
require 'config.php';

if (!isset($_SESSION['user'])) {
    header("Location: login.php");
    exit;
}
?>

<!DOCTYPE html>
<html>
<head>
<title>Dashboard</title>
<style>
body {
    background:#0f172a;
    color:white;
    font-family:Arial;
    padding:40px;
}
a {
    color:#3b82f6;
}
</style>
</head>
<body>

<h1>Bienvenido, <?= $_SESSION['user'] ?></h1>
<p>CEO MANGER v1 - Dashboard vacío</p>

<a href="logout.php">Cerrar sesión</a>

</body>
</html>
