SSHNET - Panel (minimal demo)
This ZIP contains a minimal PHP panel skeleton (Tailwind CSS) with:
- Login/logout
- Dashboard
- Basic users CRUD (list + create)
- app/config.php sample
- SQL in /sql/panel_rs_init.sql

Important:
1) Edit app/config.php to set correct DB credentials or create app/config.local.php to override.
2) Run the provided installer script (install_panel.sh) on a Debian/Ubuntu VPS to install and deploy automatically.
