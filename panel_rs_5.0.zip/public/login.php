<?php
session_start();
require_once __DIR__ . '/../app/config.php';
if(isset($_SESSION['user'])) header('Location: /dashboard.php');

$err = '';
if($_SERVER['REQUEST_METHOD'] === 'POST'){
    $u = $_POST['username'] ?? '';
    $p = $_POST['password'] ?? '';
    $stmt = $pdo->prepare('SELECT id, username, password_hash, role FROM users WHERE username = ? LIMIT 1');
    $stmt->execute([$u]);
    if($row = $stmt->fetch(PDO::FETCH_ASSOC)){
        if(password_verify($p, $row['password_hash'])){
            $_SESSION['user'] = ['id'=>$row['id'],'username'=>$row['username'],'role'=>$row['role']];
            header('Location: /dashboard.php');
            exit;
        }
    }
    $err = 'Credenciales inválidas';
}
?>
<!doctype html>
<html>
<head>
  <meta charset="utf-8">
  <title>Panel - Login</title>
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-100">
  <div class="min-h-screen flex items-center justify-center">
    <div class="w-full max-w-md bg-white p-6 rounded-2xl shadow-lg">
      <h1 class="text-2xl font-semibold mb-4">Iniciar sesión</h1>
      <?php if($err): ?>
        <div class="mb-3 text-red-600"><?=htmlspecialchars($err)?></div>
      <?php endif; ?>
      <form method="post" class="space-y-4">
        <input name="username" placeholder="Usuario" required class="w-full p-3 border rounded" />
        <input name="password" type="password" placeholder="Contraseña" required class="w-full p-3 border rounded" />
        <button class="w-full py-3 rounded bg-indigo-600 text-white">Entrar</button>
      </form>
      <p class="text-sm text-gray-500 mt-4">Usuario demo: <strong>admin</strong> / contraseña <strong>password123</strong></p>
    </div>
  </div>
</body>
</html>
