<?php
session_start();
require_once __DIR__ . '/../app/config.php';
if(!isset($_SESSION['user'])) header('Location: /login.php');
?>
<!doctype html><html><head><meta charset="utf-8"><title>Settings</title><script src="https://cdn.tailwindcss.com"></script></head><body class="bg-gray-50"><div class="min-h-screen flex"><main class="flex-1 p-8"><h1 class="text-xl mb-4">Configuración</h1><div class="bg-white p-4 rounded shadow">Aquí puedes agregar configuraciones visuales del panel (logo, tipografía, idioma).</div></main></div></body></html>