<?php
// Simple landing / login redirect
header('Location: /login.php');
exit;
