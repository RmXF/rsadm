<?php
session_start();
require_once __DIR__ . '/../app/config.php';
if(!isset($_SESSION['user'])) header('Location: /login.php');

$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
$users = $pdo->query('SELECT id, username, role, created_at FROM users ORDER BY id DESC')->fetchAll(PDO::FETCH_ASSOC);
?>
<!doctype html>
<html>
<head>
  <meta charset="utf-8">
  <title>Usuarios - Panel</title>
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-50">
  <div class="min-h-screen flex">
    <aside class="w-64 bg-white p-4 border-r">
      <h2 class="text-xl font-bold mb-6">SSHNET</h2>
      <nav class="space-y-2">
        <a href="/dashboard.php" class="block p-2 rounded hover:bg-gray-100">Dashboard</a>
        <a href="/users.php" class="block p-2 rounded hover:bg-gray-100">Usuarios</a>
      </nav>
    </aside>
    <main class="flex-1 p-8">
      <h1 class="text-xl font-semibold">Usuarios</h1>
      <a href="/user_create.php" class="inline-block mt-4 mb-4 px-4 py-2 bg-indigo-600 text-white rounded">Crear usuario</a>
      <div class="bg-white rounded shadow overflow-x-auto">
        <table class="min-w-full">
          <thead class="bg-gray-100">
            <tr>
              <th class="p-3 text-left">ID</th>
              <th class="p-3 text-left">Usuario</th>
              <th class="p-3 text-left">Rol</th>
              <th class="p-3 text-left">Creado</th>
              <th class="p-3 text-left">Acciones</th>
            </tr>
          </thead>
          <tbody>
            <?php foreach($users as $u): ?>
            <tr>
              <td class="p-3"><?=htmlspecialchars($u['id'])?></td>
              <td class="p-3"><?=htmlspecialchars($u['username'])?></td>
              <td class="p-3"><?=htmlspecialchars($u['role'])?></td>
              <td class="p-3"><?=htmlspecialchars($u['created_at'])?></td>
              <td class="p-3">
                <a href="/user_edit.php?id=<?=urlencode($u['id'])?>" class="text-sm underline">Editar</a>
              </td>
            </tr>
            <?php endforeach;?>
          </tbody>
        </table>
      </div>
    </main>
  </div>
</body>
</html>
