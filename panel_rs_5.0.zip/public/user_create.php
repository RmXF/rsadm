<?php
session_start();
require_once __DIR__ . '/../app/config.php';
if($_SERVER['REQUEST_METHOD'] === 'POST'){
    $username = $_POST['username'] ?? '';
    $password = $_POST['password'] ?? '';
    $role = $_POST['role'] ?? 'user';
    $hash = password_hash($password, PASSWORD_DEFAULT);
    $stmt = $pdo->prepare('INSERT INTO users (username, password_hash, role, created_at) VALUES (?, ?, ?, NOW())');
    $stmt->execute([$username, $hash, $role]);
    header('Location: /users.php');
    exit;
}
?>
<!doctype html><html><head><meta charset="utf-8"><title>Crear usuario</title><script src="https://cdn.tailwindcss.com"></script></head><body class="bg-gray-50"><div class="min-h-screen flex"><main class="flex-1 p-8"><h1 class="text-xl mb-4">Crear usuario</h1><form method="post" class="space-y-3 bg-white p-4 rounded shadow"><input name="username" placeholder="Usuario" required class="w-full p-2 border rounded"/><input name="password" placeholder="Contraseña" required class="w-full p-2 border rounded"/><select name="role" class="w-full p-2 border rounded"><option value="admin">admin</option><option value="user" selected>user</option></select><button class="px-4 py-2 bg-indigo-600 text-white rounded">Crear</button></form></main></div></body></html>