<?php
session_start();
require_once __DIR__ . '/../app/config.php';
if(!isset($_SESSION['user'])) header('Location: /login.php');
$user = $_SESSION['user'];
?>
<!doctype html>
<html>
<head>
  <meta charset="utf-8">
  <title>Panel - Dashboard</title>
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-50">
  <div class="min-h-screen flex">
    <aside class="w-64 bg-white p-4 border-r">
      <h2 class="text-xl font-bold mb-6">SSHNET</h2>
      <nav class="space-y-2">
        <a href="/dashboard.php" class="block p-2 rounded hover:bg-gray-100">Dashboard</a>
        <a href="/users.php" class="block p-2 rounded hover:bg-gray-100">Usuarios</a>
        <a href="/settings.php" class="block p-2 rounded hover:bg-gray-100">Configuración</a>
        <a href="/logout.php" class="block p-2 rounded hover:bg-gray-100">Cerrar sesión</a>
      </nav>
    </aside>
    <main class="flex-1 p-8">
      <h1 class="text-2xl font-semibold">Bienvenido, <?=htmlspecialchars($user['username'])?></h1>
      <div class="grid grid-cols-3 gap-4 mt-6">
        <div class="p-4 bg-white rounded shadow">Tarjeta 1</div>
        <div class="p-4 bg-white rounded shadow">Tarjeta 2</div>
        <div class="p-4 bg-white rounded shadow">Tarjeta 3</div>
      </div>
    </main>
  </div>
</body>
</html>
