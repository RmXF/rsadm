<?php
// Sample config - edit or create a copy at app/config.local.php to override
$db = [
    'host' => '127.0.0.1',
    'name' => 'panel_rs',
    'user' => 'panel_user',
    'pass' => 'panel_pass'
];

$dsn = "mysql:host={$db['host']};dbname={$db['name']};charset=utf8mb4";
try {
    $pdo = new PDO($dsn, $db['user'], $db['pass'], [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]);
} catch(Exception $e){
    // For production, handle errors properly
    die('DB connection error: ' . $e->getMessage());
}
