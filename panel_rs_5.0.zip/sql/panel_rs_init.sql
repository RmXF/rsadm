-- Sample database for SSHNET panel
CREATE DATABASE IF NOT EXISTS panel_rs DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE panel_rs;
CREATE TABLE IF NOT EXISTS users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  username VARCHAR(100) NOT NULL UNIQUE,
  password_hash VARCHAR(255) NOT NULL,
  role VARCHAR(20) NOT NULL DEFAULT 'user',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO users (username, password_hash, role) VALUES
('admin', '$2y$10$e0NRmQ1K1vV4aWZ1YkZceu5a1K1eG/6hK1k1k1k1k1k1k1k1k1k1', 'admin');
