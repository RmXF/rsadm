<?php
require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/includes/db.php';

$total_vps = $pdo->query("SELECT COUNT(*) FROM servers")->fetchColumn();
$total_users = $pdo->query("SELECT COUNT(*) FROM ssh_users")->fetchColumn();
$expired = $pdo->query("SELECT COUNT(*) FROM ssh_users WHERE expire_date < CURDATE()")->fetchColumn();
?>

<!DOCTYPE html>
<html>
<head>
    <title>Dashboard</title>
</head>
<body>

<h1>Dashboard</h1>

<p>VPS Registradas: <?= $total_vps ?></p>
<p>Usuarios Totales: <?= $total_users ?></p>
<p>Usuarios Expirados: <?= $expired ?></p>

<hr>

<a href="/vps/add.php">Agregar VPS</a><br>
<a href="/vps/list.php">Lista VPS</a><br>
<a href="/users/add.php">Agregar Usuario</a><br>
<a href="/users/list.php">Lista Usuarios</a><br>
<a href="/logout.php">Cerrar sesión</a>

</body>
</html>