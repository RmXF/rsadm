<?php
require_once '../includes/auth.php';
require_once '../includes/ssh_engine.php';

if ($_POST) {
    $server_id = $_POST['server_id'];
    $user = $_POST['username'];
    $pass = $_POST['password'];
    $days = $_POST['days'];

    $expire = date('Y-m-d', strtotime("+$days days"));

    ssh_execute($server_id, "useradd -m -s /bin/bash $user");
    ssh_execute($server_id, "echo '$user:$pass' | chpasswd");
    ssh_execute($server_id, "chage -E $expire $user");

    echo "Usuario creado";
}
?>

<form method="POST">
Servidor ID: <input name="server_id"><br>
Usuario: <input name="username"><br>
Password: <input name="password"><br>
Días duración: <input name="days"><br>
<button>Crear</button>
</form>