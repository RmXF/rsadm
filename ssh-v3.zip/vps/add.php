<?php
require_once '../includes/auth.php';
require_once '../includes/db.php';

if ($_POST) {
    $stmt = $pdo->prepare("INSERT INTO servers (name, ip, port, username, auth_type, password)
        VALUES (?, ?, ?, ?, ?, ?)");
    $stmt->execute([
        $_POST['name'],
        $_POST['ip'],
        $_POST['port'],
        $_POST['username'],
        $_POST['auth_type'],
        $_POST['password']
    ]);
    echo "VPS Agregada";
}
?>

<form method="POST">
Nombre: <input name="name"><br>
IP: <input name="ip"><br>
Puerto: <input name="port" value="22"><br>
Usuario: <input name="username"><br>
Tipo Auth:
<select name="auth_type">
<option value="password">Password</option>
<option value="key">Key</option>
</select><br>
Password (si aplica): <input name="password"><br>
<button>Guardar</button>
</form>