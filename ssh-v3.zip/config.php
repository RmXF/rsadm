<?php

// CONFIGURACIÓN BASE DE DATOS
define('DB_HOST', 'localhost');
define('DB_NAME', 'panelssh');
define('DB_USER', 'paneluser');
define('DB_PASS', 'TU_PASSWORD_DB');

// INICIAR SESIÓN DE FORMA SEGURA
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}