<?php
require_once __DIR__ . '/includes/db.php';

if (isset($_SESSION['admin'])) {
    header("Location: /dashboard.php");
    exit;
}

$error = "";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $user = trim($_POST['username'] ?? '');
    $pass = trim($_POST['password'] ?? '');

    if (!empty($user) && !empty($pass)) {

        $stmt = $pdo->prepare("SELECT * FROM admins WHERE username = ?");
        $stmt->execute([$user]);
        $admin = $stmt->fetch();

        if ($admin && password_verify($pass, $admin['password'])) {

            $_SESSION['admin'] = $admin['username'];

            header("Location: /dashboard.php");
            exit;

        } else {
            $error = "Credenciales inválidas";
        }
    } else {
        $error = "Complete todos los campos";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Login Panel</title>
</head>
<body>

<h2>Login</h2>

<form method="POST">
    <input name="username" placeholder="Usuario" required><br><br>
    <input name="password" type="password" placeholder="Contraseña" required><br><br>
    <button type="submit">Entrar</button>
</form>

<?php if (!empty($error)): ?>
<p style="color:red"><?= htmlspecialchars($error) ?></p>
<?php endif; ?>

</body>
</html>