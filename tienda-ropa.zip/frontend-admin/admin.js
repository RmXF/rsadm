// ============================================================
// PANEL ADMIN - LÓGICA COMPLETA
// ============================================================

const API_URL = window.location.origin + '/api';
let token = localStorage.getItem('adminToken');
let prendas = [];
let editandoId = null;

// ============================================================
// REFERENCIAS DOM
// ============================================================

const loginScreen = document.getElementById('loginScreen');
const panelScreen = document.getElementById('panelScreen');
const loginForm = document.getElementById('loginForm');
const loginEmail = document.getElementById('loginEmail');
const loginPassword = document.getElementById('loginPassword');
const loginError = document.getElementById('loginError');
const userEmail = document.getElementById('userEmail');
const logoutBtn = document.getElementById('logoutBtn');
const tablaBody = document.getElementById('tablaBody');
const searchInput = document.getElementById('searchInput');
const resultCount = document.getElementById('resultCount');
const totalPrendas = document.getElementById('totalPrendas');
const totalMasculino = document.getElementById('totalMasculino');
const totalFemenino = document.getElementById('totalFemenino');
const totalUnisex = document.getElementById('totalUnisex');
const modalOverlay = document.getElementById('modalOverlay');
const modalTitulo = document.getElementById('modalTitulo');
const formPrenda = document.getElementById('formPrenda');
const nombreInput = document.getElementById('nombreInput');
const generoInput = document.getElementById('generoInput');
const precioInput = document.getElementById('precioInput');
const tallesInput = document.getElementById('tallesInput');
const btnNuevaPrenda = document.getElementById('btnNuevaPrenda');
const btnCancelar = document.getElementById('btnCancelar');
const btnGuardar = document.getElementById('btnGuardar');

// ============================================================
// AUTENTICACIÓN
// ============================================================

function checkAuth() {
    if (token) {
        showPanel();
    } else {
        showLogin();
    }
}

function showLogin() {
    loginScreen.classList.add('active');
    panelScreen.classList.remove('active');
}

function showPanel() {
    loginScreen.classList.remove('active');
    panelScreen.classList.add('active');
    cargarDatos();
}

loginForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    loginError.classList.add('hidden');

    try {
        const response = await fetch(API_URL + '/auth/login', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                email: loginEmail.value.trim(),
                password: loginPassword.value.trim()
            })
        });

        const data = await response.json();

        if (data.success) {
            token = data.token;
            localStorage.setItem('adminToken', token);
            userEmail.textContent = loginEmail.value;
            showPanel();
        } else {
            loginError.textContent = data.error || 'Credenciales inválidas';
            loginError.classList.remove('hidden');
        }
    } catch (error) {
        loginError.textContent = 'Error de conexión';
        loginError.classList.remove('hidden');
    }
});

logoutBtn.addEventListener('click', () => {
    localStorage.removeItem('adminToken');
    token = null;
    showLogin();
});

// ============================================================
// CRUD
// ============================================================

async function cargarDatos() {
    try {
        const response = await fetch(API_URL + '/prendas');
        prendas = await response.json();
        renderizarTabla();
        cargarEstadisticas();
    } catch (error) {
        console.error('Error cargando datos:', error);
    }
}

async function cargarEstadisticas() {
    try {
        const response = await fetch(API_URL + '/stats', {
            headers: { 'Authorization': 'Bearer ' + token }
        });
        const data = await response.json();

        totalPrendas.textContent = data.total || 0;

        const generos = data.generos || [];
        totalMasculino.textContent = generos.find(g => g.genero === 'masculino')?.count || 0;
        totalFemenino.textContent = generos.find(g => g.genero === 'femenino')?.count || 0;
        totalUnisex.textContent = generos.find(g => g.genero === 'unisex')?.count || 0;
    } catch (error) {
        console.error('Error cargando estadísticas:', error);
    }
}

function renderizarTabla() {
    const search = searchInput.value.toLowerCase().trim();
    const filtradas = search ? prendas.filter(p => p.nombre.toLowerCase().includes(search)) : prendas;

    resultCount.textContent = filtradas.length + ' prendas';

    if (filtradas.length === 0) {
        tablaBody.innerHTML = `
            <tr>
                <td colspan="6">
                    <div class="empty-state">
                        <i class="fas fa-box-open"></i>
                        <p>${search ? 'No se encontraron resultados' : 'No hay prendas disponibles'}</p>
                    </div>
                </td>
            </tr>
        `;
        return;
    }

    let html = '';
    filtradas.forEach(p => {
        const gClass = p.genero || 'unisex';
        const gLabel = {
            masculino: '👨 Masculino',
            femenino: '👩 Femenino',
            unisex: '👤 Unisex'
        } [gClass] || 'Unisex';

        const tallesHtml = (p.talles || []).map(t =>
            '<span class="talle-badge">' + t + '</span>'
        ).join('') || '<span style="color:#9aaec3;">Sin talles</span>';

        html += `
            <tr>
                <td>#${p.id}</td>
                <td><strong>${p.nombre}</strong></td>
                <td><span class="genero-badge ${gClass}">${gLabel}</span></td>
                <td>${p.precio.toFixed(2)} €</td>
                <td>${tallesHtml}</td>
                <td>
                    <div class="acciones">
                        <button class="btn-icon" onclick="editarPrenda(${p.id})"><i class="fas fa-pen"></i></button>
                        <button class="btn-icon danger" onclick="eliminarPrenda(${p.id})"><i class="fas fa-trash-alt"></i></button>
                    </div>
                </td>
            </tr>
        `;
    });

    tablaBody.innerHTML = html;
}

// ============================================================
// OPERACIONES
// ============================================================

async function crearPrenda(nombre, genero, precio, talles) {
    try {
        const response = await fetch(API_URL + '/prendas', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': 'Bearer ' + token
            },
            body: JSON.stringify({ nombre, genero, precio, talles })
        });

        if (response.ok) {
            await cargarDatos();
            cerrarModal();
        } else {
            const error = await response.json();
            alert(error.error || 'Error al crear la prenda');
        }
    } catch (error) {
        alert('Error de conexión');
    }
}

async function actualizarPrenda(id, nombre, genero, precio, talles) {
    try {
        const response = await fetch(API_URL + '/prendas/' + id, {
            method: 'PUT',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': 'Bearer ' + token
            },
            body: JSON.stringify({ nombre, genero, precio, talles })
        });

        if (response.ok) {
            await cargarDatos();
            cerrarModal();
        } else {
            const error = await response.json();
            alert(error.error || 'Error al actualizar la prenda');
        }
    } catch (error) {
        alert('Error de conexión');
    }
}

async function eliminarPrenda(id) {
    if (!confirm('¿Seguro que deseas eliminar esta prenda?')) return;

    try {
        const response = await fetch(API_URL + '/prendas/' + id, {
            method: 'DELETE',
            headers: { 'Authorization': 'Bearer ' + token }
        });

        if (response.ok) {
            await cargarDatos();
        } else {
            const error = await response.json();
            alert(error.error || 'Error al eliminar la prenda');
        }
    } catch (error) {
        alert('Error de conexión');
    }
}

function editarPrenda(id) {
    const p = prendas.find(x => x.id === id);
    if (!p) return;

    editandoId = id;
    modalTitulo.innerHTML = '<i class="fas fa-pen"></i> Editar Prenda';
    nombreInput.value = p.nombre;
    generoInput.value = p.genero || 'unisex';
    precioInput.value = p.precio;
    tallesInput.value = (p.talles || []).join(', ');
    btnGuardar.innerHTML = '<i class="fas fa-save"></i> Actualizar';
    modalOverlay.classList.add('active');
}

function abrirModalNuevo() {
    editandoId = null;
    modalTitulo.innerHTML = '<i class="fas fa-plus"></i> Nueva Prenda';
    formPrenda.reset();
    generoInput.value = 'unisex';
    btnGuardar.innerHTML = '<i class="fas fa-save"></i> Guardar';
    modalOverlay.classList.add('active');
}

function cerrarModal() {
    modalOverlay.classList.remove('active');
    editandoId = null;
    formPrenda.reset();
}

// ============================================================
// EVENTOS
// ============================================================

searchInput.addEventListener('input', renderizarTabla);
btnNuevaPrenda.addEventListener('click', abrirModalNuevo);
btnCancelar.addEventListener('click', cerrarModal);

modalOverlay.addEventListener('click', (e) => {
    if (e.target === modalOverlay) cerrarModal();
});

formPrenda.addEventListener('submit', async (e) => {
    e.preventDefault();

    const nombre = nombreInput.value.trim();
    const genero = generoInput.value;
    const precio = parseFloat(precioInput.value);
    const talles = tallesInput.value.split(',').map(t => t.trim().toUpperCase()).filter(t => t);

    if (!nombre) {
        alert('Ingresa el nombre de la prenda');
        nombreInput.focus();
        return;
    }

    if (isNaN(precio) || precio < 0) {
        alert('Ingresa un precio válido');
        precioInput.focus();
        return;
    }

    if (editandoId) {
        await actualizarPrenda(editandoId, nombre, genero, precio, talles);
    } else {
        await crearPrenda(nombre, genero, precio, talles);
    }
});

document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape' && modalOverlay.classList.contains('active')) {
        cerrarModal();
    }
});

// ============================================================
// INICIALIZAR
// ============================================================

checkAuth();