const { Pool } = require('pg');
require('dotenv').config({ path: '../.env' });

const pool = new Pool({
  host: process.env.DB_HOST || 'localhost',
  port: process.env.DB_PORT || 5432,
  database: process.env.DB_NAME || 'tienda_ropa',
  user: process.env.DB_USER || 'tienda_admin',
  password: process.env.DB_PASS || '',
});

async function initDatabase() {
  try {
    console.log('🔨 Creando tablas...');
    
    await pool.query(`
            CREATE TABLE IF NOT EXISTS prendas (
                id SERIAL PRIMARY KEY,
                nombre VARCHAR(255) NOT NULL,
                genero VARCHAR(50) NOT NULL CHECK (genero IN ('masculino', 'femenino', 'unisex')),
                precio DECIMAL(10, 2) NOT NULL CHECK (precio >= 0),
                talles TEXT[] DEFAULT '{}',
                created_at TIMESTAMP DEFAULT NOW(),
                updated_at TIMESTAMP DEFAULT NOW()
            );
        `);
    
    const countResult = await pool.query('SELECT COUNT(*) FROM prendas');
    if (parseInt(countResult.rows[0].count) === 0) {
      console.log('📦 Insertando datos de ejemplo...');
      await pool.query(`
                INSERT INTO prendas (nombre, genero, precio, talles) VALUES
                ('Camisa Oxford', 'masculino', 49.99, ARRAY['S', 'M', 'L', 'XL']),
                ('Vestido Floral', 'femenino', 59.90, ARRAY['XS', 'S', 'M']),
                ('Sudadera Oversize', 'unisex', 45.50, ARRAY['S', 'M', 'L']),
                ('Pantalón Chino', 'unisex', 69.50, ARRAY['M', 'L']),
                ('Chaqueta Denim', 'unisex', 89.00, ARRAY['S', 'M', 'L']),
                ('Camiseta Básica', 'unisex', 19.99, ARRAY['S', 'M', 'L', 'XL']),
                ('Blazer Negro', 'masculino', 120.00, ARRAY['M', 'L', 'XL']),
                ('Jeans Skinny', 'femenino', 75.00, ARRAY['28', '30', '32', '34']),
                ('Falda Plisada', 'femenino', 39.99, ARRAY['XS', 'S', 'M', 'L']),
                ('Traje Formal', 'masculino', 199.00, ARRAY['M', 'L', 'XL'])
            `);
      console.log('✅ Datos de ejemplo insertados');
    }
    
    console.log('✅ Base de datos inicializada correctamente');
    process.exit(0);
  } catch (error) {
    console.error('❌ Error inicializando base de datos:', error);
    process.exit(1);
  }
}

initDatabase();