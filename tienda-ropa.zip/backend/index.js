const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const rateLimit = require('express-rate-limit');
const { Pool } = require('pg');
const jwt = require('jsonwebtoken');
require('dotenv').config();

const app = express();
const PORT = process.env.PORT || 3000;

// ============================================================
// SEGURIDAD
// ============================================================

const limiter = rateLimit({
    windowMs: 15 * 60 * 1000,
    max: 100
});

app.use(helmet());
app.use(cors({
    origin: ['http://localhost', `http://${process.env.DOMAIN}`, `http://panel.${process.env.DOMAIN}`],
    credentials: true
}));
app.use(express.json());
app.use('/api/', limiter);

// ============================================================
// BASE DE DATOS
// ============================================================

const pool = new Pool({
    host: process.env.DB_HOST || 'localhost',
    port: process.env.DB_PORT || 5432,
    database: process.env.DB_NAME || 'tienda_ropa',
    user: process.env.DB_USER || 'tienda_admin',
    password: process.env.DB_PASS || '',
    max: 20,
    idleTimeoutMillis: 30000,
});

pool.connect((err) => {
    if (err) {
        console.error('❌ Error conectando a PostgreSQL:', err.stack);
        process.exit(1);
    }
    console.log('✅ Conectado a PostgreSQL');
});

// ============================================================
// MIDDLEWARE DE AUTENTICACIÓN
// ============================================================

const authenticate = (req, res, next) => {
    try {
        const token = req.headers.authorization?.split(' ')[1];
        if (!token) {
            return res.status(401).json({ error: 'No autorizado' });
        }
        const decoded = jwt.verify(token, process.env.JWT_SECRET);
        req.user = decoded;
        next();
    } catch (error) {
        return res.status(401).json({ error: 'Token inválido' });
    }
};

// ============================================================
// ENDPOINTS PÚBLICOS
// ============================================================

app.get('/api/prendas', async (req, res) => {
    try {
        const result = await pool.query('SELECT * FROM prendas ORDER BY id DESC');
        res.json(result.rows);
    } catch (error) {
        console.error('Error:', error);
        res.status(500).json({ error: 'Error en el servidor' });
    }
});

app.get('/api/prendas/:id', async (req, res) => {
    try {
        const { id } = req.params;
        const result = await pool.query('SELECT * FROM prendas WHERE id = $1', [id]);
        if (result.rows.length === 0) {
            return res.status(404).json({ error: 'Prenda no encontrada' });
        }
        res.json(result.rows[0]);
    } catch (error) {
        res.status(500).json({ error: 'Error en el servidor' });
    }
});

// ============================================================
// ENDPOINTS PRIVADOS (ADMIN)
// ============================================================

app.post('/api/auth/login', async (req, res) => {
    try {
        const { email, password } = req.body;
        if (password === process.env.ADMIN_PASS) {
            const token = jwt.sign(
                { email, role: 'admin' },
                process.env.JWT_SECRET,
                { expiresIn: '24h' }
            );
            res.json({
                success: true,
                token,
                user: { email, role: 'admin' }
            });
        } else {
            res.status(401).json({ error: 'Credenciales inválidas' });
        }
    } catch (error) {
        res.status(500).json({ error: 'Error en el servidor' });
    }
});

app.post('/api/prendas', authenticate, async (req, res) => {
    try {
        const { nombre, genero, precio, talles } = req.body;
        if (!nombre || !genero || !precio) {
            return res.status(400).json({ error: 'Faltan campos requeridos' });
        }
        const result = await pool.query(
            `INSERT INTO prendas (nombre, genero, precio, talles)
             VALUES ($1, $2, $3, $4)
             RETURNING *`,
            [nombre, genero, precio, talles || []]
        );
        res.status(201).json(result.rows[0]);
    } catch (error) {
        console.error('Error:', error);
        res.status(500).json({ error: 'Error en el servidor' });
    }
});

app.put('/api/prendas/:id', authenticate, async (req, res) => {
    try {
        const { id } = req.params;
        const { nombre, genero, precio, talles } = req.body;
        const result = await pool.query(
            `UPDATE prendas
             SET nombre = $1, genero = $2, precio = $3, talles = $4, updated_at = NOW()
             WHERE id = $5
             RETURNING *`,
            [nombre, genero, precio, talles || [], id]
        );
        if (result.rows.length === 0) {
            return res.status(404).json({ error: 'Prenda no encontrada' });
        }
        res.json(result.rows[0]);
    } catch (error) {
        console.error('Error:', error);
        res.status(500).json({ error: 'Error en el servidor' });
    }
});

app.delete('/api/prendas/:id', authenticate, async (req, res) => {
    try {
        const { id } = req.params;
        const result = await pool.query(
            'DELETE FROM prendas WHERE id = $1 RETURNING *',
            [id]
        );
        if (result.rows.length === 0) {
            return res.status(404).json({ error: 'Prenda no encontrada' });
        }
        res.json({ success: true, message: 'Prenda eliminada' });
    } catch (error) {
        console.error('Error:', error);
        res.status(500).json({ error: 'Error en el servidor' });
    }
});

app.get('/api/stats', authenticate, async (req, res) => {
    try {
        const totalResult = await pool.query('SELECT COUNT(*) FROM prendas');
        const generosResult = await pool.query(
            'SELECT genero, COUNT(*) FROM prendas GROUP BY genero'
        );
        res.json({
            total: parseInt(totalResult.rows[0].count),
            generos: generosResult.rows
        });
    } catch (error) {
        console.error('Error:', error);
        res.status(500).json({ error: 'Error en el servidor' });
    }
});

// ============================================================
// INICIAR SERVIDOR
// ============================================================

app.listen(PORT, () => {
    console.log(`🚀 Servidor corriendo en http://localhost:${PORT}`);
    console.log(`📊 Panel Admin: http://panel.${process.env.DOMAIN}`);
    console.log(`🛍️  Tienda: http://${process.env.DOMAIN}`);
});

// Manejo de errores no capturados
process.on('unhandledRejection', (err) => {
    console.error('Error no manejado:', err);
});