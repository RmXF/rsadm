// ============================================================
// TIENDA PÚBLICA - LÓGICA COMPLETA
// ============================================================

const API_URL = window.location.origin + '/api';
let prendas = [];

// ============================================================
// REFERENCIAS DOM
// ============================================================

const gridContainer = document.getElementById('gridContainer');
const searchInput = document.getElementById('searchInput');
const resultCount = document.getElementById('resultCount');
const totalCount = document.getElementById('totalCount');

// ============================================================
// CARGAR PRENDAS
// ============================================================

async function cargarPrendas() {
  try {
    const response = await fetch(API_URL + '/prendas');
    prendas = await response.json();
    totalCount.textContent = prendas.length + ' prendas';
    renderizarGrid();
  } catch (error) {
    gridContainer.innerHTML = `
            <div class="empty-state">
                <i class="fas fa-exclamation-triangle"></i>
                <p>Error al cargar las prendas</p>
                <div class="sub">Intenta recargar la página</div>
            </div>
        `;
  }
}

// ============================================================
// RENDERIZAR GRID
// ============================================================

function renderizarGrid() {
  const search = searchInput.value.toLowerCase().trim();
  const filtradas = search ? prendas.filter(p => p.nombre.toLowerCase().includes(search)) : prendas;
  
  resultCount.textContent = 'Mostrando ' + filtradas.length + ' prendas';
  
  if (filtradas.length === 0) {
    gridContainer.innerHTML = `
            <div class="empty-state">
                <i class="fas fa-${search ? 'search' : 'box-open'}"></i>
                <p>${search ? 'No se encontraron resultados' : 'No hay prendas disponibles'}</p>
                ${search ? '<div class="sub">Intenta con otras palabras</div>' : ''}
            </div>
        `;
    return;
  }
  
  let html = '';
  filtradas.forEach(p => {
    const gClass = p.genero || 'unisex';
    const gLabel = {
      masculino: '👨 Masculino',
      femenino: '👩 Femenino',
      unisex: '👤 Unisex'
    } [gClass] || 'Unisex';
    
    const tallesHtml = (p.talles || []).map(t =>
      '<span class="talle-badge">' + t + '</span>'
    ).join('') || '<span style="color:#9aaec3;font-size:0.8rem;">Sin talles</span>';
    
    html += `
            <div class="card">
                <div class="card-header">
                    <h3>${p.nombre}</h3>
                    <span class="genero-badge ${gClass}">${gLabel}</span>
                </div>
                <div class="card-price">${p.precio.toFixed(2)}</div>
                <div class="card-talles">${tallesHtml}</div>
            </div>
        `;
  });
  
  gridContainer.innerHTML = html;
}

// ============================================================
// EVENTOS
// ============================================================

searchInput.addEventListener('input', renderizarGrid);

// Atajo: Ctrl+F para enfocar buscador
document.addEventListener('keydown', (e) => {
  if ((e.ctrlKey || e.metaKey) && e.key === 'f') {
    e.preventDefault();
    searchInput.focus();
    searchInput.select();
  }
});

// ============================================================
// INICIALIZAR
// ============================================================

cargarPrendas();