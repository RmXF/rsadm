/**
 * ====================================================
 * CEO MANAGER PRO v2.0
 * JavaScript Principal - VERSIÓN COMPLETA MEJORADA
 * Author: @ReyRs_VIPro
 * ====================================================
 */

class CEOManager {
    constructor() {
        this.users = [];
        this.currentUser = null;
        this.sshConnected = false;
        this.credentials = null;
        this.currentSection = 'dashboard';
        this.apiBaseUrl = 'php/endpoints/ssh_connect.php';
        this.systemApiUrl = 'php/endpoints/system.php';
        this.usersApiUrl = 'php/endpoints/users.php';
        this.searchTimeout = null;
        this.statsInterval = null;
        this.onlineUsers = [];
        this.testUserCreated = false;
        this.testUserExpiry = null;
        this.charts = {
            userChart: null,
            activityChart: null
        };
        this.connectionRetries = 0;
        this.maxRetries = 3;

        // Inicializar
        this.init();
    }

    init() {
        this.loadTheme();
        this.initEventListeners();
        this.checkStoredCredentials();
        this.startAutoRefresh();
        this.loadUsers();
        this.checkTestUserStatus();
        this.updateDateTime();
        console.log('✅ CEO MANAGER PRO v2.0 iniciado - @ReyRs_VIPro');
    }

    loadTheme() {
        const savedTheme = localStorage.getItem('ceo_theme') || 'light';
        document.documentElement.setAttribute('data-theme', savedTheme);
        const icon = document.querySelector('#themeToggle i');
        if (icon) {
            icon.className = savedTheme === 'dark' ? 'fas fa-sun' : 'fas fa-moon';
        }
    }

    initEventListeners() {
        // Toggle menú
        const menuToggle = document.getElementById('menuToggle');
        if (menuToggle) {
            menuToggle.addEventListener('click', () => this.toggleSidebar());
        }

        // Toggle tema
        const themeToggle = document.getElementById('themeToggle');
        if (themeToggle) {
            themeToggle.addEventListener('click', () => this.toggleTheme());
        }

        // Búsqueda
        const searchInput = document.getElementById('searchInput');
        if (searchInput) {
            searchInput.addEventListener('input', (e) => {
                clearTimeout(this.searchTimeout);
                this.searchTimeout = setTimeout(() => this.filterUsers(e.target.value), 300);
            });
        }

        // Botón de prueba
        const btnTest = document.getElementById('btnTest');
        if (btnTest) {
            btnTest.addEventListener('click', () => this.createTestUser());
        }

        // Botones principales
        const btnAddUser = document.getElementById('btnAddUser');
        if (btnAddUser) {
            btnAddUser.addEventListener('click', () => this.showUserModal());
        }

        const btnRefresh = document.getElementById('btnRefresh');
        if (btnRefresh) {
            btnRefresh.addEventListener('click', () => this.loadUsers());
        }

        // Navegación
        document.querySelectorAll('.nav-item').forEach(item => {
            item.addEventListener('click', (e) => this.handleNavigation(e));
        });

        // Submenú usuarios
        const usersMenu = document.getElementById('usersMenu');
        if (usersMenu) {
            usersMenu.addEventListener('click', (e) => {
                e.stopPropagation();
                this.toggleSubmenu('usersSubmenu', 'usersArrow');
            });
        }

        // Submenu items
        document.querySelectorAll('.submenu-item').forEach(item => {
            item.addEventListener('click', (e) => {
                e.stopPropagation();
                const section = item.dataset.section;
                if (section) {
                    this.changeSection(section);
                    // Cerrar submenu después de seleccionar
                    const submenu = document.getElementById('usersSubmenu');
                    const arrow = document.getElementById('usersArrow');
                    if (submenu && arrow) {
                        submenu.classList.remove('show');
                        arrow.classList.remove('rotated');
                    }
                }
            });
        });

        // Modal de usuario
        const closeModal = document.getElementById('closeModal');
        if (closeModal) {
            closeModal.addEventListener('click', () => this.hideUserModal());
        }

        const cancelModal = document.getElementById('cancelModal');
        if (cancelModal) {
            cancelModal.addEventListener('click', () => this.hideUserModal());
        }

        const saveUser = document.getElementById('saveUser');
        if (saveUser) {
            saveUser.addEventListener('click', () => this.saveUser());
        }

        // Modal VPS
        const vpsMenuItem = document.querySelector('[data-section="vps"]');
        if (vpsMenuItem) {
            vpsMenuItem.addEventListener('click', () => this.showVpsModal());
        }

        const closeVpsModal = document.getElementById('closeVpsModal');
        if (closeVpsModal) {
            closeVpsModal.addEventListener('click', () => this.hideVpsModal());
        }

        const cancelVps = document.getElementById('cancelVps');
        if (cancelVps) {
            cancelVps.addEventListener('click', () => this.hideVpsModal());
        }

        const connectVps = document.getElementById('connectVps');
        if (connectVps) {
            connectVps.addEventListener('click', () => this.connectVPS());
        }

        // Modal Logs
        const logsMenuItem = document.querySelector('[data-section="logs"]');
        if (logsMenuItem) {
            logsMenuItem.addEventListener('click', () => this.showLogsModal());
        }

        const closeLogsModal = document.getElementById('closeLogsModal');
        if (closeLogsModal) {
            closeLogsModal.addEventListener('click', () => this.hideLogsModal());
        }

        const closeLogs = document.getElementById('closeLogs');
        if (closeLogs) {
            closeLogs.addEventListener('click', () => this.hideLogsModal());
        }

        const refreshLogs = document.getElementById('refreshLogs');
        if (refreshLogs) {
            refreshLogs.addEventListener('click', () => this.loadLogs());
        }

        // Modal Monitor
        const monitorMenuItem = document.querySelector('[data-section="monitor"]');
        if (monitorMenuItem) {
            monitorMenuItem.addEventListener('click', () => this.showMonitorModal());
        }

        const closeMonitorModal = document.getElementById('closeMonitorModal');
        if (closeMonitorModal) {
            closeMonitorModal.addEventListener('click', () => this.hideMonitorModal());
        }

        const closeMonitor = document.getElementById('closeMonitor');
        if (closeMonitor) {
            closeMonitor.addEventListener('click', () => this.hideMonitorModal());
        }

        // Logout
        const logoutBtn = document.getElementById('logoutBtn');
        if (logoutBtn) {
            logoutBtn.addEventListener('click', () => this.logout());
        }

        // Expiry days
        const expiryDays = document.getElementById('expiryDays');
        if (expiryDays) {
            expiryDays.addEventListener('change', (e) => this.calculateExpiryDate(e.target.value));
        }

        // Validación username
        const username = document.getElementById('username');
        if (username) {
            username.addEventListener('input', (e) => this.validateUsername(e.target));
        }

        // Cerrar modales con ESC
        document.addEventListener('keydown', (e) => {
            if (e.key === 'Escape') {
                this.closeAllModals();
            }
        });

        // Cerrar modales clickeando fuera
        document.querySelectorAll('.modal-overlay').forEach(modal => {
            modal.addEventListener('click', (e) => {
                if (e.target === modal) {
                    modal.classList.remove('show');
                }
            });
        });
    }

    closeAllModals() {
        document.querySelectorAll('.modal-overlay.show').forEach(modal => {
            modal.classList.remove('show');
        });
    }

    checkTestUserStatus() {
        const testExpiry = localStorage.getItem('ceo_test_expiry');
        if (testExpiry) {
            const expiry = new Date(parseInt(testExpiry));
            if (expiry > new Date()) {
                this.testUserCreated = true;
                this.testUserExpiry = expiry;
                
                // Activar animación del botón
                const btnTest = document.getElementById('btnTest');
                if (btnTest) {
                    btnTest.classList.add('active');
                }
                
                // Programar eliminación automática
                const timeLeft = expiry - new Date();
                setTimeout(() => {
                    this.deleteTestUser();
                }, timeLeft);
            } else {
                localStorage.removeItem('ceo_test_expiry');
                const btnTest = document.getElementById('btnTest');
                if (btnTest) {
                    btnTest.classList.remove('active');
                }
            }
        }
    }

    async createTestUser() {
        if (!this.sshConnected) {
            this.showNotification('Primero conecta al VPS', 'warning');
            return;
        }

        if (this.testUserCreated) {
            const confirm = window.confirm('⚠️ Ya existe un usuario de prueba activo. ¿Deseas eliminarlo y crear uno nuevo?');
            if (confirm) {
                await this.deleteTestUser();
            } else {
                return;
            }
        }

        const testUsername = 'test_' + Math.random().toString(36).substring(2, 8);
        const testPassword = Math.random().toString(36).substring(2, 10) + 
                           Math.random().toString(36).substring(2, 4).toUpperCase() + 
                           Math.floor(Math.random() * 100);
        
        // Fecha de expiración: 1 hora desde ahora
        const expiry = new Date();
        expiry.setHours(expiry.getHours() + 1);
        const expiryDate = expiry.toISOString().split('T')[0];

        const testBtn = document.getElementById('btnTest');
        const originalText = testBtn.innerHTML;
        testBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Creando...';
        testBtn.disabled = true;

        try {
            const response = await this.makeRequest('add_user', {
                username: testUsername,
                password: testPassword,
                expiry_date: expiryDate,
                limit: 1
            });

            if (response.success) {
                this.testUserCreated = true;
                this.testUserExpiry = expiry;
                localStorage.setItem('ceo_test_expiry', expiry.getTime().toString());

                // Activar animación del botón
                testBtn.classList.add('active');

                // Programar eliminación automática
                setTimeout(() => {
                    this.deleteTestUser();
                }, 60 * 60 * 1000); // 1 hora

                this.showNotification(
                    `✅ Usuario de prueba creado\n👤 Usuario: ${testUsername}\n🔑 Contraseña: ${testPassword}\n⏰ Expira: ${expiry.toLocaleTimeString()}`,
                    'success',
                    10000
                );

                await this.loadUsers();
            } else {
                throw new Error(response.message);
            }
        } catch (error) {
            this.showNotification('Error: ' + error.message, 'error');
        } finally {
            testBtn.innerHTML = originalText;
            testBtn.disabled = false;
        }
    }

    async deleteTestUser() {
        // Buscar usuarios de prueba (test_*)
        const testUsers = this.users.filter(u => u.username.startsWith('test_'));
        
        for (const user of testUsers) {
            try {
                await this.makeRequest('delete_user', { username: user.username });
            } catch (e) {
                console.error('Error deleting test user:', e);
            }
        }

        this.testUserCreated = false;
        this.testUserExpiry = null;
        localStorage.removeItem('ceo_test_expiry');
        
        // Desactivar animación del botón
        const btnTest = document.getElementById('btnTest');
        if (btnTest) {
            btnTest.classList.remove('active');
        }
        
        await this.loadUsers();
        this.showNotification('Usuario de prueba eliminado', 'info');
    }

    toggleSidebar() {
        const sidebar = document.getElementById('sidebar');
        const mainContent = document.getElementById('mainContent');
        if (sidebar && mainContent) {
            sidebar.classList.toggle('collapsed');
            mainContent.classList.toggle('expanded');
            localStorage.setItem('sidebar_collapsed', sidebar.classList.contains('collapsed'));
        }
    }

    toggleTheme() {
        const current = document.documentElement.getAttribute('data-theme');
        const newTheme = current === 'dark' ? 'light' : 'dark';
        document.documentElement.setAttribute('data-theme', newTheme);
        localStorage.setItem('ceo_theme', newTheme);
        
        const icon = document.querySelector('#themeToggle i');
        if (icon) {
            icon.className = newTheme === 'dark' ? 'fas fa-sun' : 'fas fa-moon';
        }
    }

    toggleSubmenu(submenuId, arrowId) {
        const submenu = document.getElementById(submenuId);
        const arrow = document.getElementById(arrowId);
        
        if (submenu && arrow) {
            submenu.classList.toggle('show');
            arrow.classList.toggle('rotated');
        }
    }

    handleNavigation(e) {
        const item = e.currentTarget;
        if (item.classList.contains('has-submenu')) return;

        document.querySelectorAll('.nav-item').forEach(nav => nav.classList.remove('active'));
        item.classList.add('active');

        const section = item.dataset.section;
        if (section) {
            this.changeSection(section);
        }
    }

    changeSection(section) {
        this.currentSection = section;

        const titles = {
            'dashboard': 'Dashboard',
            'create-user': 'Crear Usuario',
            'list-users': 'Listado de Usuarios',
            'online-users': 'Usuarios en Línea',
            'expired-users': 'Usuarios Caducados',
            'monitor': 'Monitor VPS',
            'settings': 'Configuración',
            'vps': 'Conectar VPS',
            'logs': 'Logs del Sistema'
        };

        const sectionTitle = document.getElementById('sectionTitle');
        if (sectionTitle) {
            sectionTitle.textContent = titles[section] || 'Usuarios';
        }

        // Mostrar/ocultar dashboard
        const dashboardSection = document.getElementById('dashboardSection');
        if (dashboardSection) {
            dashboardSection.style.display = section === 'dashboard' ? 'block' : 'none';
        }

        // Acciones específicas
        switch(section) {
            case 'create-user':
                this.showUserModal();
                break;
            case 'list-users':
                this.loadUsers();
                break;
            case 'online-users':
                this.showOnlineUsers();
                break;
            case 'expired-users':
                this.showExpiredUsers();
                break;
            case 'monitor':
                this.showMonitorModal();
                break;
            case 'logs':
                this.showLogsModal();
                break;
            case 'vps':
                this.showVpsModal();
                break;
        }
    }

    checkStoredCredentials() {
        const saved = localStorage.getItem('ceo_vps_creds');
        if (saved) {
            try {
                const creds = JSON.parse(saved);
                if (creds.ip && creds.user) {
                    this.credentials = creds;
                    this.testConnection();
                }
            } catch (e) {
                console.error('Error loading credentials');
            }
        }
    }

    startAutoRefresh() {
        this.statsInterval = setInterval(() => {
            if (this.sshConnected) {
                this.loadUsers();
            }
            this.updateDateTime();
        }, 30000);
    }

    updateDateTime() {
        const now = new Date();
        const dateTimeStr = now.toLocaleDateString('es-ES', {
            weekday: 'long',
            year: 'numeric',
            month: 'long',
            day: 'numeric',
            hour: '2-digit',
            minute: '2-digit'
        });
        
        const dateTimeEl = document.getElementById('currentDateTime');
        if (dateTimeEl) {
            dateTimeEl.textContent = dateTimeStr;
        }
    }

    async testConnection() {
        const statusEl = document.getElementById('connectionStatus');
        if (!statusEl) return;
        
        if (!this.credentials) {
            statusEl.className = 'connection-status disconnected';
            statusEl.innerHTML = '<div class="status-icon"></div><span>🔌 Esperando conexión al VPS...</span>';
            return;
        }

        try {
            statusEl.innerHTML = '<div class="status-icon"></div><span>🔄 Conectando...</span>';
            
            const response = await this.makeRequest('test_connection');
            
            if (response.success) {
                this.sshConnected = true;
                this.connectionRetries = 0;
                statusEl.className = 'connection-status connected';
                statusEl.innerHTML = `<div class="status-icon"></div><span>✅ Conectado a ${this.credentials.ip}</span>`;
                this.loadUsers();
            } else {
                throw new Error(response.message || 'Error de conexión');
            }
        } catch (error) {
            this.sshConnected = false;
            this.connectionRetries++;
            
            statusEl.className = 'connection-status disconnected';
            
            if (this.connectionRetries >= this.maxRetries) {
                statusEl.innerHTML = `<div class="status-icon"></div><span>❌ Error: No se pudo conectar después de ${this.maxRetries} intentos</span>`;
                this.showNotification('Error de conexión persistente. Verifica las credenciales.', 'error');
            } else {
                statusEl.innerHTML = `<div class="status-icon"></div><span>⚠️ Error: ${error.message} (Intento ${this.connectionRetries}/${this.maxRetries})</span>`;
                // Reintentar después de 5 segundos
                setTimeout(() => this.testConnection(), 5000);
            }
        }
    }

    async loadUsers() {
        if (!this.sshConnected) {
            return;
        }

        const usersList = document.getElementById('usersList');
        if (usersList) {
            usersList.innerHTML = '<tr class="loading-row"><td colspan="6" style="text-align: center; padding: 50px;"><div class="loading"></div><p style="margin-top: 15px;">Cargando usuarios...</p></td></tr>';
        }

        try {
            const response = await this.makeRequest('list_users');
            
            if (response.success) {
                this.users = response.users || [];
                
                // Simular usuarios online (30% de los usuarios)
                this.onlineUsers = this.users
                    .filter(() => Math.random() > 0.7)
                    .map(u => u.username);
                
                this.renderUsers();
                this.updateStats();
                this.updateBadges();
            } else {
                throw new Error(response.message);
            }
        } catch (error) {
            console.error('Error loading users:', error);
            if (usersList) {
                usersList.innerHTML = '<tr><td colspan="6" style="text-align: center; padding: 50px; color: var(--danger);"><i class="fas fa-exclamation-circle" style="font-size: 2rem;"></i><p style="margin-top: 15px;">Error al cargar usuarios</p><button class="btn btn-outline" onclick="ceoManager.loadUsers()" style="margin-top: 15px;"><i class="fas fa-sync-alt"></i> Reintentar</button></td></tr>';
            }
        }
    }

    renderUsers() {
        const tbody = document.getElementById('usersList');
        if (!tbody) return;
        
        if (!this.users || this.users.length === 0) {
            tbody.innerHTML = '<tr><td colspan="6" style="text-align: center; padding: 50px;"><i class="fas fa-users" style="font-size: 3rem; color: var(--gray); opacity: 0.3;"></i><p style="margin-top: 15px;">No hay usuarios SSH configurados</p><button class="btn btn-primary" onclick="ceoManager.showUserModal()" style="margin-top: 15px;"><i class="fas fa-plus"></i> Crear primer usuario</button></td></tr>';
            return;
        }

        let filteredUsers = this.users;

        // Filtrar según sección
        if (this.currentSection === 'online-users') {
            filteredUsers = this.users.filter(u => this.onlineUsers.includes(u.username));
        } else if (this.currentSection === 'expired-users') {
            filteredUsers = this.users.filter(u => this.isUserExpired(u.expiry_date));
        }

        tbody.innerHTML = filteredUsers.map(user => {
            const timeRemaining = this.calculateTimeRemaining(user.expiry_date);
            const isExpired = this.isUserExpired(user.expiry_date);
            const isOnline = this.onlineUsers.includes(user.username);
            const isTestUser = user.username.startsWith('test_');
            
            let statusClass = 'status-active';
            let statusText = 'Activo';
            
            if (isExpired) {
                statusClass = 'status-expired';
                statusText = 'Caducado';
            } else if (isOnline) {
                statusClass = 'status-online';
                statusText = 'En Línea';
            } else if (timeRemaining.includes('1 día') || (timeRemaining.includes('días') && parseInt(timeRemaining) <= 7)) {
                statusClass = 'status-warning';
                statusText = 'Próximo a caducar';
            }
            
            const timeClass = isExpired ? 'time-danger' : 
                             (timeRemaining.includes('1 día') ? 'time-warning' : 
                             (timeRemaining.includes('días') && parseInt(timeRemaining) <= 7 ? 'time-warning' : 'time-normal'));

            return `
                <tr class="${isTestUser ? 'test-user-row' : ''}">
                    <td>
                        <div style="display: flex; align-items: center; gap: 10px;">
                            <i class="fas fa-user-circle" style="font-size: 1.5rem; color: var(--primary);"></i>
                            <div>
                                <strong>${this.escapeHtml(user.username)}</strong>
                                ${isTestUser ? '<span class="test-badge">TEST</span>' : ''}
                            </div>
                        </div>
                    </td>
                    <td>
                        <span class="user-status ${statusClass}">
                            <i class="fas fa-circle" style="font-size: 0.5rem;"></i>
                            ${statusText}
                        </span>
                    </td>
                    <td>${this.formatDate(user.expiry_date)}</td>
                    <td>
                        <span class="time-remaining ${timeClass}">
                            ${timeRemaining}
                        </span>
                    </td>
                    <td>${this.getLastLogin(user.username)}</td>
                    <td>
                        <div class="user-actions">
                            <button class="btn-icon edit" onclick="ceoManager.editUser('${this.escapeHtml(user.username)}')" title="Editar usuario">
                                <i class="fas fa-edit"></i>
                            </button>
                            <button class="btn-icon extend" onclick="ceoManager.extendUser('${this.escapeHtml(user.username)}')" title="Extender período">
                                <i class="fas fa-clock"></i>
                            </button>
                            <button class="btn-icon delete" onclick="ceoManager.deleteUser('${this.escapeHtml(user.username)}')" title="Eliminar usuario">
                                <i class="fas fa-trash"></i>
                            </button>
                        </div>
                    </td>
                </tr>
            `;
        }).join('');
    }

    updateStats() {
        const total = this.users.length;
        const expired = this.users.filter(u => this.isUserExpired(u.expiry_date)).length;
        const online = this.onlineUsers.length;
        const activeToday = this.users.filter(u => {
            const expiry = new Date(u.expiry_date);
            const today = new Date();
            const diffDays = Math.ceil((expiry - today) / (1000 * 60 * 60 * 24));
            return diffDays >= 0 && diffDays <= 1;
        }).length;

        const totalEl = document.getElementById('totalUsers');
        const onlineEl = document.getElementById('onlineUsers');
        const expiredEl = document.getElementById('expiredUsers');
        const activeEl = document.getElementById('activeToday');
        
        if (totalEl) {
            totalEl.textContent = total;
            totalEl.classList.add('stat-update');
            setTimeout(() => totalEl.classList.remove('stat-update'), 500);
        }
        
        if (onlineEl) {
            onlineEl.textContent = online;
            onlineEl.classList.add('stat-update');
            setTimeout(() => onlineEl.classList.remove('stat-update'), 500);
        }
        
        if (expiredEl) {
            expiredEl.textContent = expired;
            expiredEl.classList.add('stat-update');
            setTimeout(() => expiredEl.classList.remove('stat-update'), 500);
        }
        
        if (activeEl) {
            activeEl.textContent = activeToday;
            activeEl.classList.add('stat-update');
            setTimeout(() => activeEl.classList.remove('stat-update'), 500);
        }

        this.updateCharts(total, expired, online);
    }

    updateBadges() {
        const online = this.onlineUsers.length;
        const expired = this.users.filter(u => this.isUserExpired(u.expiry_date)).length;
        
        const onlineBadge = document.getElementById('onlineCount');
        const expiredBadge = document.getElementById('expiredCount');
        
        if (onlineBadge) onlineBadge.textContent = online;
        if (expiredBadge) expiredBadge.textContent = expired;
    }

    updateCharts(total, expired, online) {
        // Destruir gráficos existentes
        if (this.charts.userChart) {
            this.charts.userChart.destroy();
        }
        if (this.charts.activityChart) {
            this.charts.activityChart.destroy();
        }

        // Gráfico de usuarios
        const ctx1 = document.getElementById('userChart')?.getContext('2d');
        if (ctx1) {
            this.charts.userChart = new Chart(ctx1, {
                type: 'doughnut',
                data: {
                    labels: ['Activos', 'Caducados', 'En Línea'],
                    datasets: [{
                        data: [Math.max(0, total - expired), expired, online],
                        backgroundColor: ['#19b53c', '#e5182c', '#17a2b8'],
                        borderWidth: 0,
                        hoverOffset: 4
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    cutout: '70%',
                    plugins: {
                        legend: {
                            position: 'bottom',
                            labels: {
                                color: 'var(--dark)',
                                font: {
                                    size: 12
                                }
                            }
                        }
                    }
                }
            });
        }

        // Gráfico de actividad
        const ctx2 = document.getElementById('activityChart')?.getContext('2d');
        if (ctx2) {
            // Generar datos aleatorios para simular actividad
            const activityData = [];
            for (let i = 0; i < 7; i++) {
                activityData.push(Math.floor(Math.random() * 30) + 5);
            }

            this.charts.activityChart = new Chart(ctx2, {
                type: 'line',
                data: {
                    labels: ['Lun', 'Mar', 'Mié', 'Jue', 'Vie', 'Sáb', 'Dom'],
                    datasets: [{
                        label: 'Conexiones',
                        data: activityData,
                        borderColor: '#ffb909',
                        backgroundColor: 'rgba(255,185,9,0.1)',
                        borderWidth: 3,
                        tension: 0.4,
                        fill: true,
                        pointBackgroundColor: '#ffb909',
                        pointBorderColor: 'white',
                        pointBorderWidth: 2,
                        pointRadius: 4,
                        pointHoverRadius: 6
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                        legend: {
                            display: false
                        }
                    },
                    scales: {
                        y: {
                            beginAtZero: true,
                            grid: {
                                color: 'rgba(128,128,128,0.1)'
                            }
                        },
                        x: {
                            grid: {
                                display: false
                            }
                        }
                    }
                }
            });
        }
    }

    showOnlineUsers() {
        const online = this.users.filter(u => this.onlineUsers.includes(u.username));
        this.renderFilteredUsers(online, 'Usuarios en Línea');
    }

    showExpiredUsers() {
        const expired = this.users.filter(u => this.isUserExpired(u.expiry_date));
        this.renderFilteredUsers(expired, 'Usuarios Caducados');
    }

    renderFilteredUsers(users, title) {
        const sectionTitle = document.getElementById('sectionTitle');
        if (sectionTitle) {
            sectionTitle.textContent = title;
        }
        this.users = users;
        this.renderUsers();
    }

    isUserExpired(expiryDate) {
        const today = new Date();
        const expiry = new Date(expiryDate);
        today.setHours(0, 0, 0, 0);
        expiry.setHours(0, 0, 0, 0);
        return expiry < today;
    }

    calculateTimeRemaining(expiryDate) {
        try {
            const today = new Date();
            const expiry = new Date(expiryDate);
            today.setHours(0, 0, 0, 0);
            expiry.setHours(0, 0, 0, 0);
            
            const diffTime = expiry - today;
            const diffDays = Math.round(diffTime / (1000 * 60 * 60 * 24));
            
            if (diffDays < 0) return 'Caducado';
            if (diffDays === 0) return 'Hoy caduca';
            if (diffDays === 1) return '1 día';
            return `${diffDays} días`;
        } catch {
            return 'Fecha inválida';
        }
    }

    formatDate(dateString) {
        try {
            const date = new Date(dateString);
            return date.toLocaleDateString('es-ES', {
                year: 'numeric',
                month: '2-digit',
                day: '2-digit'
            });
        } catch {
            return dateString;
        }
    }

    getLastLogin(username) {
        // Simulación - en producción debe obtener del sistema
        const now = new Date();
        const hours = Math.floor(Math.random() * 24);
        const minutes = Math.floor(Math.random() * 60);
        const lastLogin = new Date(now);
        lastLogin.setHours(hours, minutes);
        
        const timeDiff = now - lastLogin;
        const hoursDiff = Math.floor(timeDiff / (1000 * 60 * 60));
        
        if (hoursDiff < 1) {
            return 'Hace unos minutos';
        } else if (hoursDiff < 24) {
            return `Hoy ${lastLogin.getHours().toString().padStart(2, '0')}:${lastLogin.getMinutes().toString().padStart(2, '0')}`;
        } else {
            return lastLogin.toLocaleDateString();
        }
    }

    showUserModal(username = null) {
        if (!this.sshConnected) {
            this.showNotification('Primero conecta al VPS', 'warning');
            return;
        }

        this.currentUser = username;
        const modal = document.getElementById('userModal');
        const title = document.getElementById('modalTitle');
        const form = document.getElementById('userForm');
        const passwordField = document.getElementById('password');
        
        if (username) {
            if (title) title.textContent = 'Editar Usuario SSH';
            if (passwordField) {
                passwordField.placeholder = 'Dejar vacío para no cambiar';
                passwordField.required = false;
            }
            this.loadUserData(username);
        } else {
            if (title) title.textContent = 'Crear Usuario SSH';
            if (form) form.reset();
            if (passwordField) {
                passwordField.placeholder = 'Contraseña';
                passwordField.required = true;
            }
            this.calculateExpiryDate(30);
        }
        
        if (modal) modal.classList.add('show');
    }

    hideUserModal() {
        const modal = document.getElementById('userModal');
        if (modal) modal.classList.remove('show');
        this.currentUser = null;
    }

    async loadUserData(username) {
        try {
            const response = await this.makeRequest('get_user', { username });
            
            if (response.success) {
                const usernameField = document.getElementById('username');
                const passwordField = document.getElementById('password');
                const expiryDate = document.getElementById('expiryDate');
                const expiryDays = document.getElementById('expiryDays');
                
                if (usernameField) usernameField.value = response.user.username;
                if (passwordField) passwordField.value = '';
                if (expiryDate) expiryDate.value = response.user.expiry_date;
                
                const expiry = new Date(response.user.expiry_date);
                const today = new Date();
                const diffTime = expiry - today;
                const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
                if (expiryDays) expiryDays.value = diffDays > 0 ? diffDays : 1;
            }
        } catch (error) {
            this.showNotification('Error al cargar usuario', 'error');
            this.hideUserModal();
        }
    }

    calculateExpiryDate(days) {
        const today = new Date();
        const expiry = new Date(today);
        expiry.setDate(today.getDate() + parseInt(days));
        const expiryDate = document.getElementById('expiryDate');
        if (expiryDate) {
            expiryDate.value = expiry.toISOString().split('T')[0];
        }
    }

    validateUsername(input) {
        const regex = /^[a-z_][a-z0-9_-]*$/;
        const isValid = regex.test(input.value) || input.value === '';
        input.style.borderColor = isValid ? '' : 'var(--danger)';
        
        // Mostrar mensaje de error
        let errorMsg = input.parentNode.querySelector('.error-message');
        if (!isValid && input.value !== '') {
            if (!errorMsg) {
                errorMsg = document.createElement('small');
                errorMsg.className = 'error-message';
                errorMsg.style.color = 'var(--danger)';
                errorMsg.style.display = 'block';
                errorMsg.style.marginTop = '5px';
                input.parentNode.appendChild(errorMsg);
            }
            errorMsg.textContent = 'Solo letras minúsculas, números, guiones y guiones bajos';
        } else if (errorMsg) {
            errorMsg.remove();
        }
    }

    async saveUser() {
        const username = document.getElementById('username')?.value.trim();
        const password = document.getElementById('password')?.value;
        const expiryDate = document.getElementById('expiryDate')?.value;
        const limit = document.getElementById('limit')?.value;
        
        if (!username) {
            this.showNotification('Usuario requerido', 'warning');
            document.getElementById('username')?.focus();
            return;
        }

        if (!this.currentUser && !password) {
            this.showNotification('Contraseña requerida', 'warning');
            document.getElementById('password')?.focus();
            return;
        }

        const saveBtn = document.getElementById('saveUser');
        const originalText = saveBtn ? saveBtn.innerHTML : 'Guardar';
        if (saveBtn) {
            saveBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Guardando...';
            saveBtn.disabled = true;
        }

        const action = this.currentUser ? 'update_user' : 'add_user';
        const data = {
            username,
            expiry_date: expiryDate,
            limit: limit || 2
        };

        if (password) data.password = password;
        if (this.currentUser && this.currentUser !== username) {
            data.old_username = this.currentUser;
        }

        try {
            const response = await this.makeRequest(action, data);
            
            if (response.success) {
                this.showNotification(response.message, 'success');
                this.hideUserModal();
                await this.loadUsers();
            } else {
                throw new Error(response.message);
            }
        } catch (error) {
            this.showNotification('Error: ' + error.message, 'error');
        } finally {
            if (saveBtn) {
                saveBtn.innerHTML = originalText;
                saveBtn.disabled = false;
            }
        }
    }

    async deleteUser(username) {
        if (username.startsWith('test_')) {
            if (!confirm(`⚠️ ¿Eliminar usuario de prueba "${username}"?`)) return;
        } else {
            if (!confirm(`¿Estás seguro de eliminar el usuario "${username}"?\nEsta acción no se puede deshacer.`)) return;
        }

        try {
            const response = await this.makeRequest('delete_user', { username });
            
            if (response.success) {
                this.showNotification('Usuario eliminado', 'success');
                await this.loadUsers();
            } else {
                throw new Error(response.message);
            }
        } catch (error) {
            this.showNotification('Error: ' + error.message, 'error');
        }
    }

    async extendUser(username) {
        const days = prompt('¿Días a extender?', '30');
        if (!days || isNaN(days) || parseInt(days) < 1) return;

        const user = this.users.find(u => u.username === username);
        if (!user) return;

        const currentExpiry = new Date(user.expiry_date);
        const newExpiry = new Date(currentExpiry);
        newExpiry.setDate(currentExpiry.getDate() + parseInt(days));

        try {
            const response = await this.makeRequest('update_user', {
                username,
                expiry_date: newExpiry.toISOString().split('T')[0]
            });

            if (response.success) {
                this.showNotification(`Usuario extendido ${days} días`, 'success');
                await this.loadUsers();
            } else {
                throw new Error(response.message);
            }
        } catch (error) {
            this.showNotification('Error: ' + error.message, 'error');
        }
    }

    editUser(username) {
        this.showUserModal(username);
    }

    filterUsers(searchTerm) {
        if (!searchTerm.trim()) {
            this.loadUsers();
            return;
        }

        const filtered = this.users.filter(u => 
            u.username.toLowerCase().includes(searchTerm.toLowerCase())
        );
        
        this.renderFilteredUsers(filtered, `Resultados: "${searchTerm}"`);
    }

    showVpsModal() {
        const modal = document.getElementById('vpsModal');
        if (modal) modal.classList.add('show');
    }

    hideVpsModal() {
        const modal = document.getElementById('vpsModal');
        if (modal) modal.classList.remove('show');
    }

    connectVPS() {
        const ip = document.getElementById('vpsIp')?.value.trim();
        const user = document.getElementById('vpsUser')?.value.trim();
        const pass = document.getElementById('vpsPass')?.value.trim();
        const port = document.getElementById('vpsPort')?.value.trim() || '22';

        if (!ip || !user || !pass) {
            this.showNotification('Completa todos los campos', 'warning');
            return;
        }

        // Validar IP
        const ipRegex = /^(\d{1,3}\.){3}\d{1,3}$/;
        if (!ipRegex.test(ip)) {
            this.showNotification('Formato de IP inválido', 'warning');
            return;
        }

        this.credentials = { ip, user, pass, port };
        
        // Guardar solo IP y usuario (no password)
        localStorage.setItem('ceo_vps_creds', JSON.stringify({ ip, user, port }));
        
        this.testConnection();
        this.hideVpsModal();
    }

    showLogsModal() {
        const modal = document.getElementById('logsModal');
        if (modal) {
            modal.classList.add('show');
            this.loadLogs();
        }
    }

    hideLogsModal() {
        const modal = document.getElementById('logsModal');
        if (modal) modal.classList.remove('show');
    }

    async loadLogs() {
        const logsContent = document.getElementById('logsContent');
        if (!logsContent) return;
        
        logsContent.innerHTML = '<div class="loading"></div><p>Cargando logs...</p>';
        
        try {
            // Intentar cargar logs del servidor
            const response = await fetch('includes/get_logs.php');
            const data = await response.json();
            
            if (data.success && data.logs && data.logs.length > 0) {
                logsContent.innerHTML = data.logs.map(log => 
                    `<div style="padding: 8px; border-bottom: 1px solid rgba(128,128,128,0.1); font-family: monospace; font-size: 0.9rem;">${this.escapeHtml(log)}</div>`
                ).join('');
            } else {
                // Logs simulados
                const logs = [
                    `[${new Date().toLocaleString()}] ✅ CEO MANAGER PRO v2.0 iniciado - @ReyRs_VIPro`,
                    `[${new Date().toLocaleString()}] 🔌 Conexión SSH ${this.sshConnected ? 'establecida' : 'no establecida'} con ${this.credentials?.ip || 'VPS'}`,
                    `[${new Date().toLocaleString()}] 👤 Usuarios cargados: ${this.users.length}`,
                    `[${new Date().toLocaleString()}] 📊 Estadísticas actualizadas`,
                    `[${new Date().toLocaleString()}] 🔄 Panel funcionando correctamente`,
                    `[${new Date().toLocaleString()}] ${this.testUserCreated ? '✅ Usuario de prueba activo' : 'ℹ️ Sin usuario de prueba'}`,
                    `[${new Date().toLocaleString()}] 👨‍💻 Desarrollado por @ReyRs_VIPro`
                ];
                
                logsContent.innerHTML = logs.map(log => 
                    `<div style="padding: 8px; border-bottom: 1px solid rgba(128,128,128,0.1); font-family: monospace; font-size: 0.9rem;">${log}</div>`
                ).join('');
            }
        } catch (error) {
            logsContent.innerHTML = '<p style="color: var(--danger);">Error al cargar logs</p>';
        }
    }

    showMonitorModal() {
        const modal = document.getElementById('monitorModal');
        if (modal) {
            modal.classList.add('show');
            this.loadSystemStats();
            
            // Actualizar cada 5 segundos mientras el modal esté abierto
            this.monitorInterval = setInterval(() => {
                if (modal.classList.contains('show')) {
                    this.loadSystemStats();
                } else {
                    clearInterval(this.monitorInterval);
                }
            }, 5000);
        }
    }

    hideMonitorModal() {
        const modal = document.getElementById('monitorModal');
        if (modal) {
            modal.classList.remove('show');
            clearInterval(this.monitorInterval);
        }
    }

    async loadSystemStats() {
        if (!this.sshConnected) {
            // Valores simulados si no hay conexión
            const cpuEl = document.getElementById('cpuUsage');
            const ramEl = document.getElementById('ramUsage');
            const diskEl = document.getElementById('diskUsage');
            const uptimeEl = document.getElementById('uptime');
            
            if (cpuEl) cpuEl.textContent = Math.floor(Math.random() * 30 + 10) + '%';
            if (ramEl) ramEl.textContent = Math.floor(Math.random() * 40 + 30) + '%';
            if (diskEl) diskEl.textContent = Math.floor(Math.random() * 20 + 40) + '%';
            if (uptimeEl) uptimeEl.textContent = Math.floor(Math.random() * 10 + 2) + ' días';
            return;
        }

        try {
            const response = await this.makeRequest('system_info');
            
            if (response.success) {
                const cpuEl = document.getElementById('cpuUsage');
                const ramEl = document.getElementById('ramUsage');
                const diskEl = document.getElementById('diskUsage');
                const uptimeEl = document.getElementById('uptime');
                
                if (cpuEl) cpuEl.textContent = (response.cpu || Math.floor(Math.random() * 30 + 10)) + '%';
                if (ramEl) ramEl.textContent = (response.ram || Math.floor(Math.random() * 40 + 30)) + '%';
                if (diskEl) diskEl.textContent = (response.disk || Math.floor(Math.random() * 20 + 40)) + '%';
                if (uptimeEl) uptimeEl.textContent = response.uptime || (Math.floor(Math.random() * 10 + 2) + ' días');
            }
        } catch (error) {
            console.error('Error loading system stats');
            // Valores simulados si falla
            const cpuEl = document.getElementById('cpuUsage');
            const ramEl = document.getElementById('ramUsage');
            const diskEl = document.getElementById('diskUsage');
            const uptimeEl = document.getElementById('uptime');
            
            if (cpuEl) cpuEl.textContent = Math.floor(Math.random() * 30 + 10) + '%';
            if (ramEl) ramEl.textContent = Math.floor(Math.random() * 40 + 30) + '%';
            if (diskEl) diskEl.textContent = Math.floor(Math.random() * 20 + 40) + '%';
            if (uptimeEl) uptimeEl.textContent = Math.floor(Math.random() * 10 + 2) + ' días';
        }
    }

    async makeRequest(action, data = {}) {
        if (!this.credentials) {
            throw new Error('Credenciales no configuradas');
        }

        const response = await fetch(this.apiBaseUrl, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                action,
                ...data,
                ...this.credentials
            })
        });

        if (!response.ok) {
            throw new Error('Error en la petición');
        }

        return await response.json();
    }

    showNotification(message, type = 'success', duration = 3000) {
        const notification = document.getElementById('notification');
        const messageSpan = document.getElementById('notificationMessage');
        
        if (!notification || !messageSpan) return;
        
        notification.className = `notification ${type}`;
        messageSpan.innerHTML = message.replace(/\n/g, '<br>');
        
        const icon = notification.querySelector('i');
        if (icon) {
            icon.className = type === 'success' ? 'fas fa-check-circle' :
                            type === 'error' ? 'fas fa-exclamation-circle' :
                            type === 'warning' ? 'fas fa-exclamation-triangle' :
                            'fas fa-info-circle';
        }
        
        notification.classList.add('show');
        
        // Reproducir sonido según el tipo (opcional)
        // this.playNotificationSound(type);
        
        setTimeout(() => {
            notification.classList.remove('show');
        }, duration);
    }

    playNotificationSound(type) {
        // Función opcional para reproducir sonidos
        const audio = new Audio();
        if (type === 'success') {
            // audio.src = 'assets/sounds/success.mp3';
        } else if (type === 'error') {
            // audio.src = 'assets/sounds/error.mp3';
        }
        // audio.play().catch(e => console.log('Audio not supported'));
    }

    logout() {
        this.showNotification('Cerrando sesión...', 'info', 1500);
        setTimeout(() => {
            window.location.href = 'logout.php';
        }, 1500);
    }

    escapeHtml(text) {
        const div = document.createElement('div');
        div.textContent = text;
        return div.innerHTML;
    }
}

// Inicializar la aplicación cuando el DOM esté listo
document.addEventListener('DOMContentLoaded', () => {
    window.ceoManager = new CEOManager();
    
    // Agregar estilo para animación de estadísticas
    const style = document.createElement('style');
    style.textContent = `
        .stat-update {
            animation: statPulse 0.5s ease;
        }
        
        @keyframes statPulse {
            0% {
                transform: scale(1);
            }
            50% {
                transform: scale(1.1);
                color: var(--primary);
            }
            100% {
                transform: scale(1);
            }
        }
        
        .test-user-row {
            background: rgba(156, 39, 176, 0.05);
        }
        
        .test-user-row:hover {
            background: rgba(156, 39, 176, 0.1);
        }
    `;
    document.head.appendChild(style);
});

// Manejar errores no capturados
window.addEventListener('error', (e) => {
    console.error('Error global:', e.error);
    if (window.ceoManager) {
        window.ceoManager.showNotification('Error en la aplicación', 'error');
    }
});

// Prevenir cierre accidental
window.addEventListener('beforeunload', (e) => {
    if (window.ceoManager && window.ceoManager.sshConnected) {
        e.preventDefault();
        e.returnValue = '¿Seguro que quieres salir? La conexión SSH se perderá.';
    }
});