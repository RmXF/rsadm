<?php
/**
 * ====================================================
 * CEO MANAGER PRO v2.0
 * Obtener Usuario Específico
 * Author: @ReyRs_VIPro
 * ====================================================
 */

header('Content-Type: application/json');
require_once __DIR__ . '/ssh_connect.php';

// Este archivo usa la misma lógica que ssh_connect.php
// La función get_user ya está implementada en ssh_connect.php
?>