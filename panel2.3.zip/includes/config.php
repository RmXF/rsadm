<?php
/**
 * ====================================================
 * CEO MANAGER PRO v1.0
 * Configuración Principal
 * Author: @ReyRs_VIPro
 * ====================================================
 */

define('CEO_VERSION', '1.0.0');
define('CEO_NAME', 'CEO MANAGER PRO');
define('CEO_AUTHOR', '@ReyRs_VIPro');
define('SESSION_TIMEOUT', 3600); // 1 hora
define('MAX_LOGIN_ATTEMPTS', 5);

// Credenciales del panel (serán reemplazadas por el instalador)
define('CEO_USER', 'admin');
define('CEO_PASS', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi'); // password

// Configuración de logging
define('LOG_FILE', __DIR__ . '/../logs/panel.log');
define('ACCESS_LOG', __DIR__ . '/../logs/access.log');
define('ERROR_LOG', __DIR__ . '/../logs/error.log');

// Configuración SSH por defecto
define('DEFAULT_SSH_PORT', 22);
define('SSH_TIMEOUT', 10);
?>