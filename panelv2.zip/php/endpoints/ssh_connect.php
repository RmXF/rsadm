<?php
/**
 * ====================================================
 * CEO MANAGER PRO v1.0
 * Endpoint SSH
 * Author: @ReyRs_VIPro
 * ====================================================
 */

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

require_once __DIR__ . '/../../includes/config.php';

// Verificar sesión
session_start();
if (!isset($_SESSION['ceo_logged_in']) || $_SESSION['ceo_logged_in'] !== true) {
    echo json_encode(['success' => false, 'message' => 'No autorizado']);
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

function sendResponse($success, $message = '', $data = []) {
    $response = ['success' => $success];
    if ($message) $response['message'] = $message;
    if (!empty($data)) $response = array_merge($response, $data);
    echo json_encode($response);
    exit();
}

class SSHManager {
    private $credentials;
    
    public function __construct($creds) {
        $this->credentials = $creds;
    }
    
    public function execute($command) {
        try {
            $ip = escapeshellarg($this->credentials['ip']);
            $user = escapeshellarg($this->credentials['user']);
            $pass = $this->credentials['pass'];
            $port = (int)($this->credentials['port'] ?? 22);
            
            $tempFile = tempnam(sys_get_temp_dir(), 'ceo_');
            file_put_contents($tempFile, $pass);
            chmod($tempFile, 0600);
            
            $sshCmd = sprintf(
                "sshpass -f %s ssh -o StrictHostKeyChecking=no -o ConnectTimeout=10 -p %d %s@%s '%s' 2>&1",
                escapeshellarg($tempFile),
                $port,
                $user,
                $ip,
                addslashes($command)
            );
            
            $output = [];
            $returnVar = 0;
            exec($sshCmd, $output, $returnVar);
            
            unlink($tempFile);
            
            if ($returnVar !== 0) {
                return ['success' => false, 'message' => 'Error SSH'];
            }
            
            return ['success' => true, 'output' => implode("\n", $output)];
            
        } catch (Exception $e) {
            return ['success' => false, 'message' => $e->getMessage()];
        }
    }
    
    public function testConnection() {
        return $this->execute('echo "ceo_manager_ok"');
    }
    
    public function listUsers() {
        $cmd = "cat /etc/passwd | grep -E ':/bin/(bash|sh)' | cut -d: -f1";
        $result = $this->execute($cmd);
        
        if (!$result['success']) {
            return ['success' => false];
        }
        
        $users = array_filter(explode("\n", $result['output']));
        $systemUsers = ['root', 'daemon', 'bin', 'sys', 'sync', 'games', 'man', 'lp', 'mail', 'news', 'uucp', 'proxy', 'www-data', 'backup', 'list', 'irc', 'nobody'];
        
        $sshUsers = array_values(array_diff($users, $systemUsers));
        $userDetails = [];
        
        foreach ($sshUsers as $username) {
            $username = trim($username);
            if (empty($username)) continue;
            
            $expiry = $this->getUserExpiry($username);
            $status = $this->getUserStatus($username);
            
            $userDetails[] = [
                'username' => $username,
                'expiry_date' => $expiry,
                'status' => $status
            ];
        }
        
        return ['success' => true, 'users' => $userDetails];
    }
    
    private function getUserExpiry($username) {
        $cmd = "chage -l " . escapeshellarg($username) . " 2>/dev/null | grep 'Account expires' | cut -d: -f2";
        $result = $this->execute($cmd);
        
        if ($result['success'] && !empty($result['output'])) {
            $expiry = trim($result['output']);
            if (strtolower($expiry) === 'never' || empty($expiry)) {
                return '2099-12-31';
            }
            $parsed = strtotime($expiry);
            if ($parsed) {
                return date('Y-m-d', $parsed);
            }
        }
        return '2099-12-31';
    }
    
    private function getUserStatus($username) {
        $cmd = "passwd -S " . escapeshellarg($username) . " 2>/dev/null | awk '{print $2}'";
        $result = $this->execute($cmd);
        
        if ($result['success'] && !empty($result['output'])) {
            $status = trim($result['output']);
            if ($status === 'P') return 'active';
            if ($status === 'L') return 'locked';
        }
        return 'unknown';
    }
    
    public function addUser($username, $password, $expiry) {
        $username = escapeshellarg($username);
        $password = escapeshellarg($password);
        
        // Crear usuario
        $result = $this->execute("useradd -m -s /bin/bash $username");
        if (!$result['success']) return ['success' => false, 'message' => 'Error creando usuario'];
        
        // Establecer contraseña
        $result = $this->execute("echo $username:$password | chpasswd");
        if (!$result['success']) {
            $this->execute("userdel -r $username");
            return ['success' => false, 'message' => 'Error estableciendo contraseña'];
        }
        
        // Establecer expiración
        if ($expiry && $expiry !== '2099-12-31') {
            $this->execute("chage -E " . escapeshellarg($expiry) . " $username");
        }
        
        return ['success' => true, 'message' => 'Usuario creado correctamente'];
    }
    
    public function deleteUser($username) {
        if (in_array($username, ['root', 'admin'])) {
            return ['success' => false, 'message' => 'No se puede eliminar este usuario'];
        }
        
        $result = $this->execute("userdel -r " . escapeshellarg($username));
        return $result['success'] 
            ? ['success' => true, 'message' => 'Usuario eliminado'] 
            : ['success' => false, 'message' => 'Error eliminando usuario'];
    }
    
    public function updateUser($username, $oldUsername, $password, $expiry) {
        // Cambiar nombre
        if ($username !== $oldUsername) {
            $result = $this->execute("usermod -l " . escapeshellarg($username) . " " . escapeshellarg($oldUsername));
            if (!$result['success']) {
                return ['success' => false, 'message' => 'Error cambiando nombre'];
            }
        }
        
        // Cambiar contraseña
        if (!empty($password)) {
            $result = $this->execute("echo " . escapeshellarg("$username:$password") . " | chpasswd");
            if (!$result['success']) {
                return ['success' => false, 'message' => 'Error cambiando contraseña'];
            }
        }
        
        // Cambiar expiración
        if ($expiry) {
            $this->execute("chage -E " . escapeshellarg($expiry) . " " . escapeshellarg($username));
        }
        
        return ['success' => true, 'message' => 'Usuario actualizado'];
    }
    
    public function getSystemInfo() {
        $cpu = $this->execute("top -bn1 | grep 'Cpu(s)' | awk '{print $2}' | cut -d'%' -f1");
        $ram = $this->execute("free | grep Mem | awk '{print $3/$2 * 100.0}'");
        $disk = $this->execute("df -h / | awk 'NR==2 {print $5}' | cut -d'%' -f1");
        $uptime = $this->execute("uptime -p");
        
        return [
            'success' => true,
            'cpu' => round(floatval($cpu['output'] ?? 0), 1),
            'ram' => round(floatval($ram['output'] ?? 0), 1),
            'disk' => intval($disk['output'] ?? 0),
            'uptime' => trim(str_replace('up ', '', $uptime['output'] ?? ''))
        ];
    }
}

// Procesar petición
try {
    $input = json_decode(file_get_contents('php://input'), true);
    if (!$input) {
        sendResponse(false, 'JSON inválido');
    }
    
    $action = $input['action'] ?? '';
    
    if (!isset($input['ip']) || !isset($input['user']) || !isset($input['pass'])) {
        sendResponse(false, 'Credenciales SSH requeridas');
    }
    
    $ssh = new SSHManager($input);
    
    switch ($action) {
        case 'test_connection':
            $result = $ssh->testConnection();
            if ($result['success'] && trim($result['output']) === 'ceo_manager_ok') {
                sendResponse(true, 'Conexión exitosa');
            } else {
                sendResponse(false, 'Error de conexión');
            }
            break;
            
        case 'list_users':
            $result = $ssh->listUsers();
            if ($result['success']) {
                sendResponse(true, 'Usuarios obtenidos', ['users' => $result['users']]);
            } else {
                sendResponse(false, 'Error al listar usuarios');
            }
            break;
            
        case 'add_user':
            $username = $input['username'] ?? '';
            $password = $input['password'] ?? '';
            $expiry = $input['expiry_date'] ?? '';
            
            if (!$username || !$password) {
                sendResponse(false, 'Usuario y contraseña requeridos');
            }
            
            $result = $ssh->addUser($username, $password, $expiry);
            sendResponse($result['success'], $result['message'] ?? '');
            break;
            
        case 'delete_user':
            $username = $input['username'] ?? '';
            if (!$username) sendResponse(false, 'Usuario requerido');
            
            $result = $ssh->deleteUser($username);
            sendResponse($result['success'], $result['message'] ?? '');
            break;
            
        case 'update_user':
            $username = $input['username'] ?? '';
            $old = $input['old_username'] ?? $username;
            $password = $input['password'] ?? '';
            $expiry = $input['expiry_date'] ?? '';
            
            if (!$username) sendResponse(false, 'Usuario requerido');
            
            $result = $ssh->updateUser($username, $old, $password, $expiry);
            sendResponse($result['success'], $result['message'] ?? '');
            break;
            
        case 'system_info':
            $result = $ssh->getSystemInfo();
            sendResponse(true, 'Info del sistema', $result);
            break;
            
        default:
            sendResponse(false, 'Acción no válida');
    }
    
} catch (Exception $e) {
    sendResponse(false, 'Error interno: ' . $e->getMessage());
}
?>