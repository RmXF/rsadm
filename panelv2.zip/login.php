<?php
/**
 * ====================================================
 * CEO MANAGER PRO v1.0
 * Login Page
 * Author: @ReyRs_VIPro
 * ====================================================
 */

session_start();

// Redirigir si ya está logueado
if (isset($_SESSION['ceo_logged_in']) && $_SESSION['ceo_logged_in'] === true) {
    header('Location: index.html');
    exit();
}

// Archivo de configuración
define('CONFIG_FILE', __DIR__ . '/includes/config.php');

// Cargar configuración
if (file_exists(CONFIG_FILE)) {
    require_once CONFIG_FILE;
} else {
    // Configuración por defecto (será reemplazada por el instalador)
    define('CEO_USER', 'admin');
    define('CEO_PASS', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi');
}

$error = '';

// Procesar login
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = $_POST['username'] ?? '';
    $password = $_POST['password'] ?? '';
    
    if ($username === CEO_USER && password_verify($password, CEO_PASS)) {
        $_SESSION['ceo_logged_in'] = true;
        $_SESSION['ceo_user'] = $username;
        $_SESSION['ceo_login_time'] = time();
        $_SESSION['ceo_ip'] = $_SERVER['REMOTE_ADDR'];
        
        // Registrar login
        $log = date('Y-m-d H:i:s') . " - Login - Usuario: $username - IP: " . $_SERVER['REMOTE_ADDR'] . " - @ReyRs_VIPro\n";
        file_put_contents(__DIR__ . '/logs/access.log', $log, FILE_APPEND);
        
        header('Location: index.html');
        exit();
    } else {
        $error = 'Usuario o contraseña incorrectos';
        
        // Registrar intento fallido
        $log = date('Y-m-d H:i:s') . " - Intento fallido - Usuario: $username - IP: " . $_SERVER['REMOTE_ADDR'] . " - @ReyRs_VIPro\n";
        file_put_contents(__DIR__ . '/logs/access.log', $log, FILE_APPEND);
    }
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CEO MANAGER PRO - Login</title>
    <!-- 
        ====================================================
        CEO MANAGER PRO v1.0
        Desarrollado por: @ReyRs_VIPro
        ====================================================
    -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }

        body {
            min-height: 100vh;
            background: linear-gradient(135deg, #1a1a2e 0%, #16213e 100%);
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
        }

        .login-container {
            width: 100%;
            max-width: 450px;
            animation: fadeInUp 0.6s ease;
        }

        @keyframes fadeInUp {
            from {
                opacity: 0;
                transform: translateY(30px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .login-card {
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(10px);
            border-radius: 20px;
            box-shadow: 0 20px 60px rgba(0, 0, 0, 0.3);
            overflow: hidden;
        }

        .login-header {
            background: linear-gradient(135deg, #ffb909 0%, #e5a80e 100%);
            padding: 40px 30px;
            text-align: center;
            position: relative;
        }

        .login-header i {
            font-size: 3.5rem;
            color: #1a1a2e;
            margin-bottom: 15px;
            animation: pulse 2s infinite;
        }

        @keyframes pulse {
            0%, 100% { transform: scale(1); }
            50% { transform: scale(1.1); }
        }

        .login-header h1 {
            font-size: 2rem;
            color: #1a1a2e;
            margin-bottom: 5px;
        }

        .login-header p {
            color: #1a1a2e;
            opacity: 0.8;
            font-size: 0.9rem;
        }

        .login-header .watermark {
            position: absolute;
            bottom: 10px;
            right: 20px;
            font-size: 0.7rem;
            color: rgba(26, 26, 46, 0.3);
        }

        .login-body {
            padding: 40px 30px;
        }

        .form-group {
            margin-bottom: 25px;
            position: relative;
        }

        .form-group i {
            position: absolute;
            left: 15px;
            top: 50%;
            transform: translateY(-50%);
            color: #ffb909;
            font-size: 1.1rem;
        }

        .form-group input {
            width: 100%;
            padding: 15px 15px 15px 45px;
            border: 2px solid #e0e0e0;
            border-radius: 12px;
            font-size: 1rem;
            transition: all 0.3s ease;
        }

        .form-group input:focus {
            outline: none;
            border-color: #ffb909;
            box-shadow: 0 0 0 4px rgba(255, 185, 9, 0.1);
        }

        .password-toggle {
            position: absolute;
            right: 15px;
            top: 50%;
            transform: translateY(-50%);
            cursor: pointer;
            color: #ffb909;
            z-index: 10;
        }

        .btn-login {
            width: 100%;
            padding: 15px;
            background: linear-gradient(135deg, #ffb909 0%, #e5a80e 100%);
            border: none;
            border-radius: 12px;
            color: #1a1a2e;
            font-size: 1.1rem;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s ease;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 10px;
        }

        .btn-login:hover {
            transform: translateY(-2px);
            box-shadow: 0 10px 30px rgba(255, 185, 9, 0.4);
        }

        .alert {
            padding: 15px 20px;
            border-radius: 12px;
            margin-bottom: 25px;
            display: flex;
            align-items: center;
            gap: 10px;
            animation: shake 0.5s ease;
        }

        @keyframes shake {
            0%, 100% { transform: translateX(0); }
            25% { transform: translateX(-5px); }
            75% { transform: translateX(5px); }
        }

        .alert-error {
            background: #fee;
            color: #e5182c;
            border-left: 4px solid #e5182c;
        }

        .footer {
            text-align: center;
            margin-top: 20px;
            color: rgba(255,255,255,0.5);
            font-size: 0.8rem;
        }

        .footer .author {
            color: #ffb909;
        }
    </style>
</head>
<body>
    <div class="login-container">
        <div class="login-card">
            <div class="login-header">
                <i class="fas fa-crown"></i>
                <h1>CEO MANAGER PRO</h1>
                <p>Panel de administración SSH</p>
                <div class="watermark">@ReyRs_VIPro</div>
            </div>
            
            <div class="login-body">
                <?php if ($error): ?>
                    <div class="alert alert-error">
                        <i class="fas fa-exclamation-circle"></i>
                        <span><?php echo htmlspecialchars($error); ?></span>
                    </div>
                <?php endif; ?>
                
                <form method="POST" action="" id="loginForm">
                    <div class="form-group">
                        <i class="fas fa-user"></i>
                        <input type="text" name="username" placeholder="Usuario" required autofocus>
                    </div>
                    
                    <div class="form-group">
                        <i class="fas fa-lock"></i>
                        <input type="password" name="password" placeholder="Contraseña" required id="password">
                        <i class="fas fa-eye password-toggle" id="togglePassword"></i>
                    </div>
                    
                    <button type="submit" class="btn-login" id="loginBtn">
                        <i class="fas fa-sign-in-alt"></i> Ingresar al Panel
                    </button>
                </form>
            </div>
        </div>
        
        <div class="footer">
            <p>CEO MANAGER PRO v1.0 | Desarrollado por <span class="author">@ReyRs_VIPro</span></p>
        </div>
    </div>

    <script>
        // Toggle password visibility
        document.getElementById('togglePassword').addEventListener('click', function() {
            const password = document.getElementById('password');
            const type = password.type === 'password' ? 'text' : 'password';
            password.type = type;
            this.classList.toggle('fa-eye');
            this.classList.toggle('fa-eye-slash');
        });

        // Loading animation
        document.getElementById('loginForm').addEventListener('submit', function() {
            const btn = document.getElementById('loginBtn');
            btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Verificando...';
            btn.disabled = true;
        });
    </script>
</body>
</html>