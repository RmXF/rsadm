/**
 * ====================================================
 * CEO MANAGER PRO v1.0
 * JavaScript Principal
 * Author: @ReyRs_VIPro
 * ====================================================
 */

class CEOManager {
    constructor() {
        this.users = [];
        this.currentUser = null;
        this.sshConnected = false;
        this.credentials = null;
        this.currentSection = 'dashboard';
        this.apiBaseUrl = 'php/endpoints/ssh_connect.php';
        this.systemApiUrl = 'php/endpoints/system.php';
        this.usersApiUrl = 'php/endpoints/users.php';
        this.searchTimeout = null;
        this.statsInterval = null;
        this.onlineUsers = [];

        // Inicializar
        this.init();
    }

    init() {
        this.loadTheme();
        this.initEventListeners();
        this.checkStoredCredentials();
        this.startAutoRefresh();
        console.log('✅ CEO MANAGER PRO iniciado - @ReyRs_VIPro');
    }

    loadTheme() {
        const savedTheme = localStorage.getItem('ceo_theme') || 'light';
        document.documentElement.setAttribute('data-theme', savedTheme);
        const icon = document.querySelector('#themeToggle i');
        if (icon) {
            icon.className = savedTheme === 'dark' ? 'fas fa-sun' : 'fas fa-moon';
        }
    }

    initEventListeners() {
        // Toggle menú
        document.getElementById('menuToggle')?.addEventListener('click', () => this.toggleSidebar());

        // Toggle tema
        document.getElementById('themeToggle')?.addEventListener('click', () => this.toggleTheme());

        // Búsqueda
        document.getElementById('searchInput')?.addEventListener('input', (e) => {
            clearTimeout(this.searchTimeout);
            this.searchTimeout = setTimeout(() => this.filterUsers(e.target.value), 300);
        });

        // Botones principales
        document.getElementById('btnAddUser')?.addEventListener('click', () => this.showUserModal());
        document.getElementById('btnRefresh')?.addEventListener('click', () => this.loadUsers());

        // Navegación
        document.querySelectorAll('.nav-item').forEach(item => {
            item.addEventListener('click', (e) => this.handleNavigation(e));
        });

        // Submenú usuarios
        document.getElementById('usersMenu')?.addEventListener('click', (e) => {
            e.stopPropagation();
            this.toggleSubmenu('usersSubmenu', 'usersArrow');
        });

        // Submenu items
        document.querySelectorAll('.submenu-item').forEach(item => {
            item.addEventListener('click', (e) => {
                e.stopPropagation();
                const section = item.dataset.section;
                this.changeSection(section);
            });
        });

        // Modal de usuario
        document.getElementById('closeModal')?.addEventListener('click', () => this.hideUserModal());
        document.getElementById('cancelModal')?.addEventListener('click', () => this.hideUserModal());
        document.getElementById('saveUser')?.addEventListener('click', () => this.saveUser());

        // Modal VPS
        document.querySelector('[data-section="vps"]')?.addEventListener('click', () => this.showVpsModal());
        document.getElementById('closeVpsModal')?.addEventListener('click', () => this.hideVpsModal());
        document.getElementById('cancelVps')?.addEventListener('click', () => this.hideVpsModal());
        document.getElementById('connectVps')?.addEventListener('click', () => this.connectVPS());

        // Modal Logs
        document.querySelector('[data-section="logs"]')?.addEventListener('click', () => this.showLogsModal());
        document.getElementById('closeLogsModal')?.addEventListener('click', () => this.hideLogsModal());
        document.getElementById('closeLogs')?.addEventListener('click', () => this.hideLogsModal());
        document.getElementById('refreshLogs')?.addEventListener('click', () => this.loadLogs());

        // Modal Monitor
        document.querySelector('[data-section="monitor"]')?.addEventListener('click', () => this.showMonitorModal());
        document.getElementById('closeMonitorModal')?.addEventListener('click', () => this.hideMonitorModal());
        document.getElementById('closeMonitor')?.addEventListener('click', () => this.hideMonitorModal());

        // Logout
        document.getElementById('logoutBtn')?.addEventListener('click', () => this.logout());

        // Expiry days
        document.getElementById('expiryDays')?.addEventListener('change', (e) => this.calculateExpiryDate(e.target.value));

        // Validación username
        document.getElementById('username')?.addEventListener('input', (e) => this.validateUsername(e.target));
    }

    toggleSidebar() {
        const sidebar = document.getElementById('sidebar');
        const mainContent = document.getElementById('mainContent');
        sidebar.classList.toggle('collapsed');
        mainContent.classList.toggle('expanded');
    }

    toggleTheme() {
        const current = document.documentElement.getAttribute('data-theme');
        const newTheme = current === 'dark' ? 'light' : 'dark';
        document.documentElement.setAttribute('data-theme', newTheme);
        localStorage.setItem('ceo_theme', newTheme);
        
        const icon = document.querySelector('#themeToggle i');
        if (icon) {
            icon.className = newTheme === 'dark' ? 'fas fa-sun' : 'fas fa-moon';
        }
    }

    toggleSubmenu(submenuId, arrowId) {
        const submenu = document.getElementById(submenuId);
        const arrow = document.getElementById(arrowId);
        
        if (submenu && arrow) {
            submenu.classList.toggle('show');
            arrow.classList.toggle('rotated');
        }
    }

    handleNavigation(e) {
        const item = e.currentTarget;
        if (item.classList.contains('has-submenu')) return;

        document.querySelectorAll('.nav-item').forEach(nav => nav.classList.remove('active'));
        item.classList.add('active');

        const section = item.dataset.section;
        if (section) {
            this.changeSection(section);
        }
    }

    changeSection(section) {
        this.currentSection = section;

        // Actualizar título
        const titles = {
            'dashboard': 'Dashboard',
            'create-user': 'Crear Usuario',
            'list-users': 'Listado de Usuarios',
            'online-users': 'Usuarios en Línea',
            'expired-users': 'Usuarios Caducados',
            'monitor': 'Monitor VPS',
            'settings': 'Configuración',
            'vps': 'Conectar VPS',
            'logs': 'Logs del Sistema'
        };

        document.getElementById('sectionTitle').textContent = titles[section] || 'Usuarios';

        // Mostrar/ocultar secciones
        if (section === 'dashboard') {
            document.getElementById('dashboardSection').style.display = 'block';
        } else {
            document.getElementById('dashboardSection').style.display = 'none';
        }

        // Acciones específicas
        switch(section) {
            case 'create-user':
                this.showUserModal();
                break;
            case 'list-users':
                this.loadUsers();
                break;
            case 'online-users':
                this.showOnlineUsers();
                break;
            case 'expired-users':
                this.showExpiredUsers();
                break;
            case 'monitor':
                this.showMonitorModal();
                break;
            case 'logs':
                this.showLogsModal();
                break;
            case 'vps':
                this.showVpsModal();
                break;
        }
    }

    checkStoredCredentials() {
        const saved = localStorage.getItem('ceo_vps_creds');
        if (saved) {
            try {
                const creds = JSON.parse(saved);
                if (creds.ip && creds.user) {
                    this.credentials = creds;
                    this.testConnection();
                }
            } catch (e) {
                console.error('Error loading credentials');
            }
        }
    }

    startAutoRefresh() {
        this.statsInterval = setInterval(() => {
            if (this.sshConnected) {
                this.loadUsers();
            }
        }, 30000);
    }

    async testConnection() {
        const statusEl = document.getElementById('connectionStatus');
        
        if (!this.credentials) {
            statusEl.className = 'connection-status disconnected';
            statusEl.innerHTML = '<div class="status-icon"></div><span>Esperando conexión al VPS...</span>';
            return;
        }

        try {
            statusEl.innerHTML = '<div class="status-icon"></div><span>Conectando...</span>';
            
            const response = await this.makeRequest('test_connection');
            
            if (response.success) {
                this.sshConnected = true;
                statusEl.className = 'connection-status connected';
                statusEl.innerHTML = `<div class="status-icon"></div><span>Conectado a ${this.credentials.ip}</span>`;
                this.loadUsers();
            } else {
                throw new Error(response.message);
            }
        } catch (error) {
            this.sshConnected = false;
            statusEl.className = 'connection-status disconnected';
            statusEl.innerHTML = `<div class="status-icon"></div><span>Error: ${error.message}</span>`;
            this.showNotification('Error de conexión: ' + error.message, 'error');
        }
    }

    async loadUsers() {
        if (!this.sshConnected) {
            this.showNotification('No hay conexión al VPS', 'warning');
            return;
        }

        try {
            const response = await this.makeRequest('list_users');
            
            if (response.success) {
                this.users = response.users || [];
                this.renderUsers();
                this.updateStats();
                this.updateBadges();
            } else {
                throw new Error(response.message);
            }
        } catch (error) {
            console.error('Error loading users:', error);
            this.showNotification('Error al cargar usuarios', 'error');
        }
    }

    renderUsers() {
        const tbody = document.getElementById('usersList');
        
        if (!this.users || this.users.length === 0) {
            tbody.innerHTML = '<tr><td colspan="6" style="text-align: center; padding: 50px;"><i class="fas fa-users" style="font-size: 3rem; color: var(--gray); opacity: 0.3;"></i><p style="margin-top: 15px;">No hay usuarios SSH configurados</p></td></tr>';
            return;
        }

        let filteredUsers = this.users;

        // Filtrar según sección
        if (this.currentSection === 'online-users') {
            filteredUsers = this.users.filter(u => this.isUserOnline(u.username));
        } else if (this.currentSection === 'expired-users') {
            filteredUsers = this.users.filter(u => this.isUserExpired(u.expiry_date));
        }

        tbody.innerHTML = filteredUsers.map(user => {
            const timeRemaining = this.calculateTimeRemaining(user.expiry_date);
            const isExpired = this.isUserExpired(user.expiry_date);
            const isOnline = this.isUserOnline(user.username);
            
            let statusClass = 'status-active';
            let statusText = 'Activo';
            
            if (isExpired) {
                statusClass = 'status-expired';
                statusText = 'Caducado';
            } else if (isOnline) {
                statusClass = 'status-online';
                statusText = 'En Línea';
            } else if (timeRemaining.includes('1 día') || (timeRemaining.includes('días') && parseInt(timeRemaining) <= 7)) {
                statusClass = 'status-warning';
                statusText = 'Próximo a caducar';
            }
            
            const timeClass = isExpired ? 'time-danger' : 
                             (timeRemaining.includes('1 día') ? 'time-warning' : 
                             (timeRemaining.includes('días') && parseInt(timeRemaining) <= 7 ? 'time-warning' : 'time-normal'));

            return `
                <tr>
                    <td>
                        <div style="display: flex; align-items: center; gap: 10px;">
                            <i class="fas fa-user-circle" style="font-size: 1.5rem; color: var(--primary);"></i>
                            <strong>${this.escapeHtml(user.username)}</strong>
                        </div>
                    </td>
                    <td>
                        <span class="user-status ${statusClass}">
                            <i class="fas fa-circle" style="font-size: 0.5rem;"></i>
                            ${statusText}
                        </span>
                    </td>
                    <td>${this.formatDate(user.expiry_date)}</td>
                    <td>
                        <span class="time-remaining ${timeClass}">
                            ${timeRemaining}
                        </span>
                    </td>
                    <td>${this.getLastLogin(user.username)}</td>
                    <td>
                        <div class="user-actions">
                            <button class="btn-icon edit" onclick="ceoManager.editUser('${this.escapeHtml(user.username)}')" title="Editar">
                                <i class="fas fa-edit"></i>
                            </button>
                            <button class="btn-icon extend" onclick="ceoManager.extendUser('${this.escapeHtml(user.username)}')" title="Extender">
                                <i class="fas fa-clock"></i>
                            </button>
                            <button class="btn-icon delete" onclick="ceoManager.deleteUser('${this.escapeHtml(user.username)}')" title="Eliminar">
                                <i class="fas fa-trash"></i>
                            </button>
                        </div>
                    </td>
                </tr>
            `;
        }).join('');
    }

    updateStats() {
        const total = this.users.length;
        const expired = this.users.filter(u => this.isUserExpired(u.expiry_date)).length;
        const online = this.onlineUsers.length;
        const activeToday = this.users.filter(u => {
            const expiry = new Date(u.expiry_date);
            const today = new Date();
            const diffDays = Math.ceil((expiry - today) / (1000 * 60 * 60 * 24));
            return diffDays >= 0 && diffDays <= 1;
        }).length;

        document.getElementById('totalUsers').textContent = total;
        document.getElementById('onlineUsers').textContent = online;
        document.getElementById('expiredUsers').textContent = expired;
        document.getElementById('activeToday').textContent = activeToday;

        this.updateCharts(total, expired, online);
    }

    updateBadges() {
        const online = this.onlineUsers.length;
        const expired = this.users.filter(u => this.isUserExpired(u.expiry_date)).length;
        
        document.getElementById('onlineCount').textContent = online;
        document.getElementById('expiredCount').textContent = expired;
    }

    updateCharts(total, expired, online) {
        if (this.userChart) this.userChart.destroy();
        if (this.activityChart) this.activityChart.destroy();

        const ctx1 = document.getElementById('userChart')?.getContext('2d');
        if (ctx1) {
            this.userChart = new Chart(ctx1, {
                type: 'doughnut',
                data: {
                    labels: ['Activos', 'Caducados', 'En Línea'],
                    datasets: [{
                        data: [total - expired, expired, online],
                        backgroundColor: ['#19b53c', '#e5182c', '#17a2b8'],
                        borderWidth: 0
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                        legend: { position: 'bottom' }
                    }
                }
            });
        }

        // Actividad simulada
        const ctx2 = document.getElementById('activityChart')?.getContext('2d');
        if (ctx2) {
            this.activityChart = new Chart(ctx2, {
                type: 'line',
                data: {
                    labels: ['Lun', 'Mar', 'Mié', 'Jue', 'Vie', 'Sáb', 'Dom'],
                    datasets: [{
                        label: 'Conexiones',
                        data: [12, 19, 15, 17, 24, 30, 28],
                        borderColor: '#ffb909',
                        backgroundColor: 'rgba(255,185,9,0.1)',
                        tension: 0.4,
                        fill: true
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                        legend: { display: false }
                    }
                }
            });
        }
    }

    showOnlineUsers() {
        const online = this.users.filter(u => this.isUserOnline(u.username));
        this.renderFilteredUsers(online, 'Usuarios en Línea');
    }

    showExpiredUsers() {
        const expired = this.users.filter(u => this.isUserExpired(u.expiry_date));
        this.renderFilteredUsers(expired, 'Usuarios Caducados');
    }

    renderFilteredUsers(users, title) {
        document.getElementById('sectionTitle').textContent = title;
        this.users = users;
        this.renderUsers();
    }

    isUserOnline(username) {
        // Simulación - en producción debe verificar conexiones activas
        return this.onlineUsers.some(u => u === username);
    }

    isUserExpired(expiryDate) {
        const today = new Date();
        const expiry = new Date(expiryDate);
        return expiry < today;
    }

    calculateTimeRemaining(expiryDate) {
        try {
            const today = new Date();
            const expiry = new Date(expiryDate);
            today.setHours(0, 0, 0, 0);
            expiry.setHours(0, 0, 0, 0);
            
            const diffTime = expiry - today;
            const diffDays = Math.round(diffTime / (1000 * 60 * 60 * 24));
            
            if (diffDays < 0) return 'Caducado';
            if (diffDays === 0) return 'Hoy caduca';
            if (diffDays === 1) return '1 día';
            return `${diffDays} días`;
        } catch {
            return 'Fecha inválida';
        }
    }

    formatDate(dateString) {
        try {
            const date = new Date(dateString);
            return date.toLocaleDateString('es-ES', {
                year: 'numeric',
                month: '2-digit',
                day: '2-digit'
            });
        } catch {
            return dateString;
        }
    }

    getLastLogin(username) {
        // Simulación - en producción debe obtener del sistema
        const hours = Math.floor(Math.random() * 24);
        const minutes = Math.floor(Math.random() * 60);
        return `Hoy ${hours}:${minutes.toString().padStart(2, '0')}`;
    }

    showUserModal(username = null) {
        if (!this.sshConnected) {
            this.showNotification('Primero conecta al VPS', 'warning');
            return;
        }

        this.currentUser = username;
        const modal = document.getElementById('userModal');
        const title = document.getElementById('modalTitle');
        const form = document.getElementById('userForm');
        const passwordField = document.getElementById('password');
        
        if (username) {
            title.textContent = 'Editar Usuario SSH';
            passwordField.placeholder = 'Dejar vacío para no cambiar';
            passwordField.required = false;
            this.loadUserData(username);
        } else {
            title.textContent = 'Crear Usuario SSH';
            form.reset();
            passwordField.placeholder = 'Contraseña';
            passwordField.required = true;
            this.calculateExpiryDate(30);
        }
        
        modal.classList.add('show');
    }

    hideUserModal() {
        document.getElementById('userModal').classList.remove('show');
        this.currentUser = null;
    }

    async loadUserData(username) {
        try {
            const response = await this.makeRequest('get_user', { username });
            
            if (response.success) {
                document.getElementById('username').value = response.user.username;
                document.getElementById('password').value = '';
                document.getElementById('expiryDate').value = response.user.expiry_date;
                
                const expiry = new Date(response.user.expiry_date);
                const today = new Date();
                const diffTime = expiry - today;
                const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
                document.getElementById('expiryDays').value = diffDays > 0 ? diffDays : 1;
            }
        } catch (error) {
            this.showNotification('Error al cargar usuario', 'error');
            this.hideUserModal();
        }
    }

    calculateExpiryDate(days) {
        const today = new Date();
        const expiry = new Date(today);
        expiry.setDate(today.getDate() + parseInt(days));
        document.getElementById('expiryDate').value = expiry.toISOString().split('T')[0];
    }

    validateUsername(input) {
        const regex = /^[a-z_][a-z0-9_-]*$/;
        const isValid = regex.test(input.value) || input.value === '';
        input.style.borderColor = isValid ? '' : 'var(--danger)';
    }

    async saveUser() {
        const username = document.getElementById('username').value.trim();
        const password = document.getElementById('password').value;
        const expiryDate = document.getElementById('expiryDate').value;
        const limit = document.getElementById('limit').value;
        
        if (!username) {
            this.showNotification('Usuario requerido', 'warning');
            return;
        }

        if (!this.currentUser && !password) {
            this.showNotification('Contraseña requerida', 'warning');
            return;
        }

        const saveBtn = document.getElementById('saveUser');
        const originalText = saveBtn.innerHTML;
        saveBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Guardando...';
        saveBtn.disabled = true;

        const action = this.currentUser ? 'update_user' : 'add_user';
        const data = {
            username,
            expiry_date: expiryDate,
            limit
        };

        if (password) data.password = password;
        if (this.currentUser && this.currentUser !== username) {
            data.old_username = this.currentUser;
        }

        try {
            const response = await this.makeRequest(action, data);
            
            if (response.success) {
                this.showNotification(response.message, 'success');
                this.hideUserModal();
                await this.loadUsers();
            } else {
                throw new Error(response.message);
            }
        } catch (error) {
            this.showNotification('Error: ' + error.message, 'error');
        } finally {
            saveBtn.innerHTML = originalText;
            saveBtn.disabled = false;
        }
    }

    async deleteUser(username) {
        if (!confirm(`¿Eliminar usuario "${username}"?`)) return;

        try {
            const response = await this.makeRequest('delete_user', { username });
            
            if (response.success) {
                this.showNotification('Usuario eliminado', 'success');
                await this.loadUsers();
            } else {
                throw new Error(response.message);
            }
        } catch (error) {
            this.showNotification('Error: ' + error.message, 'error');
        }
    }

    async extendUser(username) {
        const days = prompt('¿Días a extender?', '30');
        if (!days || isNaN(days)) return;

        const user = this.users.find(u => u.username === username);
        if (!user) return;

        const currentExpiry = new Date(user.expiry_date);
        const newExpiry = new Date(currentExpiry);
        newExpiry.setDate(currentExpiry.getDate() + parseInt(days));

        try {
            const response = await this.makeRequest('update_user', {
                username,
                expiry_date: newExpiry.toISOString().split('T')[0]
            });

            if (response.success) {
                this.showNotification(`Usuario extendido ${days} días`, 'success');
                await this.loadUsers();
            } else {
                throw new Error(response.message);
            }
        } catch (error) {
            this.showNotification('Error: ' + error.message, 'error');
        }
    }

    editUser(username) {
        this.showUserModal(username);
    }

    filterUsers(searchTerm) {
        if (!searchTerm.trim()) {
            this.loadUsers();
            return;
        }

        const filtered = this.users.filter(u => 
            u.username.toLowerCase().includes(searchTerm.toLowerCase())
        );
        
        this.renderFilteredUsers(filtered, 'Resultados de Búsqueda');
    }

    showVpsModal() {
        document.getElementById('vpsModal').classList.add('show');
    }

    hideVpsModal() {
        document.getElementById('vpsModal').classList.remove('show');
    }

    connectVPS() {
        const ip = document.getElementById('vpsIp').value.trim();
        const user = document.getElementById('vpsUser').value.trim();
        const pass = document.getElementById('vpsPass').value.trim();
        const port = document.getElementById('vpsPort').value.trim() || '22';

        if (!ip || !user || !pass) {
            this.showNotification('Completa todos los campos', 'warning');
            return;
        }

        this.credentials = { ip, user, pass, port };
        
        // Guardar solo IP y usuario (no password)
        localStorage.setItem('ceo_vps_creds', JSON.stringify({ ip, user, port }));
        
        this.testConnection();
        this.hideVpsModal();
    }

    showLogsModal() {
        document.getElementById('logsModal').classList.add('show');
        this.loadLogs();
    }

    hideLogsModal() {
        document.getElementById('logsModal').classList.remove('show');
    }

    async loadLogs() {
        const logsContent = document.getElementById('logsContent');
        logsContent.innerHTML = '<div class="loading"></div><p>Cargando logs...</p>';
        
        // Simulación - en producción obtener del servidor
        setTimeout(() => {
            const logs = [
                `[${new Date().toLocaleString()}] ✅ CEO MANAGER PRO iniciado - @ReyRs_VIPro`,
                `[${new Date().toLocaleString()}] 🔌 Conexión SSH establecida`,
                `[${new Date().toLocaleString()}] 👤 Usuario "demo" creado`,
                `[${new Date().toLocaleString()}] 🗑️ Usuario "test" eliminado`,
                `[${new Date().toLocaleString()}] 🔄 Panel actualizado`
            ];
            
            logsContent.innerHTML = logs.map(log => 
                `<div style="padding: 8px; border-bottom: 1px solid rgba(128,128,128,0.1); font-family: monospace;">${log}</div>`
            ).join('');
        }, 1000);
    }

    showMonitorModal() {
        document.getElementById('monitorModal').classList.add('show');
        this.loadSystemStats();
    }

    hideMonitorModal() {
        document.getElementById('monitorModal').classList.remove('show');
    }

    async loadSystemStats() {
        if (!this.sshConnected) {
            this.showNotification('Sin conexión al VPS', 'warning');
            return;
        }

        try {
            const response = await this.makeRequest('system_info');
            
            if (response.success) {
                document.getElementById('cpuUsage').textContent = response.cpu + '%';
                document.getElementById('ramUsage').textContent = response.ram + '%';
                document.getElementById('diskUsage').textContent = response.disk + '%';
                document.getElementById('uptime').textContent = response.uptime;
            }
        } catch (error) {
            console.error('Error loading system stats');
        }
    }

    async makeRequest(action, data = {}) {
        if (!this.credentials) {
            throw new Error('Credenciales no configuradas');
        }

        const response = await fetch(this.apiBaseUrl, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                action,
                ...data,
                ...this.credentials
            })
        });

        if (!response.ok) {
            throw new Error('Error en la petición');
        }

        return await response.json();
    }

    showNotification(message, type = 'success') {
        const notification = document.getElementById('notification');
        const messageSpan = document.getElementById('notificationMessage');
        
        notification.className = `notification ${type}`;
        messageSpan.textContent = message;
        
        const icon = notification.querySelector('i');
        if (icon) {
            icon.className = type === 'success' ? 'fas fa-check-circle' :
                            type === 'error' ? 'fas fa-exclamation-circle' :
                            'fas fa-exclamation-triangle';
        }
        
        notification.classList.add('show');
        
        setTimeout(() => {
            notification.classList.remove('show');
        }, 3000);
    }

    logout() {
        window.location.href = 'logout.php';
    }

    escapeHtml(text) {
        const div = document.createElement('div');
        div.textContent = text;
        return div.innerHTML;
    }
}

// Inicializar