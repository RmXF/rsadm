<?php
require_once '../includes/config.php';
require_once '../includes/database.php';
require_once '../includes/functions.php';
require_once '../includes/auth.php';
require_once '../includes/validation.php';

// Verificar login
requireLogin();
requireAdmin();

$message = '';
$error = '';

// Crear backup
if (isset($_POST['action']) && $_POST['action'] === 'create_backup') {
    $filename = createBackup();
    if ($filename) {
        $message = "Backup creado exitosamente: $filename";
        addLog($_SESSION['user_id'], 'create_backup', "Creó backup: $filename", getClientIP(), getUserAgent());
    } else {
        $error = "Error al crear backup";
    }
}

// Eliminar backup
if (isset($_GET['delete'])) {
    $filename = basename($_GET['delete']);
    $filepath = BACKUP_PATH . '/' . $filename;
    
    if (file_exists($filepath)) {
        unlink($filepath);
        db_delete('backups', 'filename = ?', [$filename]);
        $message = "Backup eliminado: $filename";
        addLog($_SESSION['user_id'], 'delete_backup', "Eliminó backup: $filename", getClientIP(), getUserAgent());
    } else {
        $error = "Archivo no encontrado";
    }
}

// Descargar backup
if (isset($_GET['download'])) {
    $filename = basename($_GET['download']);
    $filepath = BACKUP_PATH . '/' . $filename;
    
    if (file_exists($filepath)) {
        header('Content-Type: application/sql');
        header('Content-Disposition: attachment; filename="' . $filename . '"');
        header('Content-Length: ' . filesize($filepath));
        readfile($filepath);
        exit;
    }
}

// Obtener lista de backups
$backups = [];
$files = glob(BACKUP_PATH . '/backup_*.sql');
rsort($files);

foreach ($files as $file) {
    $backups[] = [
        'filename' => basename($file),
        'size' => filesize($file),
        'date' => date('d/m/Y H:i:s', filemtime($file))
    ];
}

// Limpiar backups antiguos
cleanOldBackups();
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Backups - CEO SSH Panel</title>
    <link rel="icon" href="../assets/img/favicon.ico">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="../assets/css/responsive.css">
    <script src="../assets/js/app.js" defer></script>
</head>
<body>
    <div class="app-container">
        <aside class="sidebar" id="sidebar">
            <div class="logo">
                <div class="logo-icon"><i class="fas fa-shield-alt"></i></div>
                <div class="logo-text">CEO SSH</div>
            </div>
            <nav class="sidebar-nav">
                <div class="nav-section">
                    <div class="nav-label">Principal</div>
                    <a href="dashboard.php" class="sidebar-link"><i class="fas fa-tachometer-alt"></i><span>Dashboard</span></a>
                    <a href="users.php" class="sidebar-link"><i class="fas fa-users"></i><span>Usuarios</span></a>
                </div>
                <div class="nav-section">
                    <div class="nav-label">Configuración</div>
                    <a href="profile.php" class="sidebar-link"><i class="fas fa-user"></i><span>Mi Perfil</span></a>
                    <a href="settings.php" class="sidebar-link"><i class="fas fa-cog"></i><span>Configuración</span></a>
                    <a href="backups.php" class="sidebar-link active"><i class="fas fa-database"></i><span>Backups</span></a>
                    <a href="logs.php" class="sidebar-link"><i class="fas fa-history"></i><span>Logs</span></a>
                    <a href="help.php" class="sidebar-link"><i class="fas fa-question-circle"></i><span>Ayuda</span></a>
                </div>
            </nav>
            <div class="user-info">
                <div style="display: flex; align-items: center; gap: 12px;">
                    <div class="user-avatar"><?php echo strtoupper(substr($_SESSION['username'], 0, 1)); ?></div>
                    <div class="user-details">
                        <div class="user-name"><?php echo htmlspecialchars($_SESSION['username']); ?></div>
                        <div class="user-role">Administrador</div>
                    </div>
                </div>
            </div>
        </aside>
        
        <main class="main-content" id="mainContent">
            <header class="header">
                <div class="header-left">
                    <button class="toggle-sidebar" onclick="toggleSidebar()"><i class="fas fa-bars"></i></button>
                    <div class="page-title">
                        <h1>Backups</h1>
                        <p>Gestión de copias de seguridad</p>
                    </div>
                </div>
                <div class="header-right">
                    <button class="theme-toggle" onclick="toggleTheme()"><i class="fas fa-moon" id="themeIcon"></i></button>
                    <div class="user-dropdown">
                        <button class="user-btn" onclick="toggleDropdown('userDropdown')">
                            <div class="user-avatar-small"><?php echo strtoupper(substr($_SESSION['username'], 0, 1)); ?></div>
                            <span class="user-name-small"><?php echo htmlspecialchars($_SESSION['username']); ?></span>
                            <i class="fas fa-chevron-down"></i>
                        </button>
                        <div class="dropdown-menu" id="userDropdown">
                            <a href="profile.php" class="dropdown-item"><i class="fas fa-user"></i><span>Mi Perfil</span></a>
                            <div class="dropdown-divider"></div>
                            <a href="../api/auth.php?action=logout" class="dropdown-item"><i class="fas fa-sign-out-alt"></i><span>Cerrar Sesión</span></a>
                        </div>
                    </div>
                </div>
            </header>
            
            <div class="content">
                <?php if ($message): ?>
                    <div style="background: var(--success); color: white; padding: 12px 16px; border-radius: 12px; margin-bottom: 20px;">
                        <i class="fas fa-check-circle"></i> <?php echo $message; ?>
                    </div>
                <?php endif; ?>
                
                <?php if ($error): ?>
                    <div style="background: var(--error); color: white; padding: 12px 16px; border-radius: 12px; margin-bottom: 20px;">
                        <i class="fas fa-exclamation-triangle"></i> <?php echo $error; ?>
                    </div>
                <?php endif; ?>
                
                <div class="row">
                    <div class="col-12 col-md-4">
                        <div class="card">
                            <div class="card-header">
                                <h3 class="card-title">Crear Backup</h3>
                            </div>
                            <div class="card-body">
                                <form method="POST">
                                    <input type="hidden" name="action" value="create_backup">
                                    <p style="margin-bottom: 20px; color: var(--text-secondary);">
                                        <i class="fas fa-info-circle"></i> Se creará una copia completa de la base de datos.
                                    </p>
                                    <button type="submit" class="btn btn-primary" style="width: 100%;">
                                        <i class="fas fa-plus-circle"></i> Crear Nuevo Backup
                                    </button>
                                </form>
                            </div>
                        </div>
                    </div>
                    
                    <div class="col-12 col-md-8">
                        <div class="card">
                            <div class="card-header">
                                <h3 class="card-title">Backups Disponibles</h3>
                                <span style="color: var(--text-tertiary); font-size: 12px;">
                                    <i class="fas fa-folder"></i> Directorio: <?php echo BACKUP_PATH; ?>
                                </span>
                            </div>
                            <div class="card-body">
                                <?php if (empty($backups)): ?>
                                    <div class="empty-state">
                                        <i class="fas fa-database"></i>
                                        <p>No hay backups disponibles</p>
                                    </div>
                                <?php else: ?>
                                    <div class="table-container">
                                        <table style="width: 100%;">
                                            <thead>
                                                <tr>
                                                    <th>Archivo</th>
                                                    <th>Fecha</th>
                                                    <th>Tamaño</th>
                                                    <th>Acciones</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php foreach ($backups as $backup): ?>
                                                <tr>
                                                    <td><?php echo htmlspecialchars($backup['filename']); ?></td>
                                                    <td><?php echo $backup['date']; ?></td>
                                                    <td><?php echo formatBytes($backup['size']); ?></td>
                                                    <td>
                                                        <a href="?download=<?php echo urlencode($backup['filename']); ?>" class="btn btn-sm btn-success">
                                                            <i class="fas fa-download"></i>
                                                        </a>
                                                        <a href="?delete=<?php echo urlencode($backup['filename']); ?>" class="btn btn-sm btn-danger" onclick="return confirm('¿Eliminar este backup?')">
                                                            <i class="fas fa-trash"></i>
                                                        </a>
                                                    </td>
                                                </tr>
                                                <?php endforeach; ?>
                                            </tbody>
                                        </table>
                                    </div>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- Información de respaldo -->
                <div class="card" style="margin-top: 20px;">
                    <div class="card-header">
                        <h3 class="card-title"><i class="fas fa-info-circle"></i> Información</h3>
                    </div>
                    <div class="card-body">
                        <div class="row">
                            <div class="col-12 col-md-6">
                                <strong>Ubicación de backups:</strong><br>
                                <code><?php echo BACKUP_PATH; ?></code>
                            </div>
                            <div class="col-12 col-md-6">
                                <strong>Retención:</strong><br>
                                Se mantienen los últimos <?php echo BACKUP_KEEP_DAYS; ?> días
                            </div>
                        </div>
                        <div style="margin-top: 15px; padding: 12px; background: var(--bg-tertiary); border-radius: 8px;">
                            <small>
                                <i class="fas fa-clock"></i> Los backups automáticos se generan diariamente a las 2:00 AM
                            </small>
                        </div>
                    </div>
                </div>
            </div>
        </main>
    </div>
</body>
</html>