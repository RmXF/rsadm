<?php
require_once '../includes/config.php';
require_once '../includes/database.php';
require_once '../includes/functions.php';
require_once '../includes/auth.php';
require_once '../includes/validation.php';

// Verificar login
requireLogin();
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ayuda - CEO SSH Panel</title>
    <link rel="icon" href="../assets/img/favicon.ico">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="../assets/css/responsive.css">
    <script src="../assets/js/app.js" defer></script>
</head>
<body>
    <div class="app-container">
        <aside class="sidebar" id="sidebar">
            <div class="logo">
                <div class="logo-icon"><i class="fas fa-shield-alt"></i></div>
                <div class="logo-text">CEO SSH</div>
            </div>
            <nav class="sidebar-nav">
                <div class="nav-section">
                    <div class="nav-label">Principal</div>
                    <a href="dashboard.php" class="sidebar-link"><i class="fas fa-tachometer-alt"></i><span>Dashboard</span></a>
                    <a href="users.php" class="sidebar-link"><i class="fas fa-users"></i><span>Usuarios</span></a>
                </div>
                <div class="nav-section">
                    <div class="nav-label">Configuración</div>
                    <a href="profile.php" class="sidebar-link"><i class="fas fa-user"></i><span>Mi Perfil</span></a>
                    <?php if (isAdmin()): ?>
                    <a href="settings.php" class="sidebar-link"><i class="fas fa-cog"></i><span>Configuración</span></a>
                    <a href="backups.php" class="sidebar-link"><i class="fas fa-database"></i><span>Backups</span></a>
                    <a href="logs.php" class="sidebar-link"><i class="fas fa-history"></i><span>Logs</span></a>
                    <?php endif; ?>
                    <a href="help.php" class="sidebar-link active"><i class="fas fa-question-circle"></i><span>Ayuda</span></a>
                </div>
            </nav>
            <div class="user-info">
                <div style="display: flex; align-items: center; gap: 12px;">
                    <div class="user-avatar"><?php echo strtoupper(substr($_SESSION['username'], 0, 1)); ?></div>
                    <div class="user-details">
                        <div class="user-name"><?php echo htmlspecialchars($_SESSION['username']); ?></div>
                        <div class="user-role"><?php echo $_SESSION['role'] === 'admin' ? 'Administrador' : 'Usuario'; ?></div>
                    </div>
                </div>
            </div>
        </aside>
        
        <main class="main-content" id="mainContent">
            <header class="header">
                <div class="header-left">
                    <button class="toggle-sidebar" onclick="toggleSidebar()"><i class="fas fa-bars"></i></button>
                    <div class="page-title">
                        <h1>Centro de Ayuda</h1>
                        <p>Documentación y guías de uso</p>
                    </div>
                </div>
                <div class="header-right">
                    <button class="theme-toggle" onclick="toggleTheme()"><i class="fas fa-moon" id="themeIcon"></i></button>
                    <div class="user-dropdown">
                        <button class="user-btn" onclick="toggleDropdown('userDropdown')">
                            <div class="user-avatar-small"><?php echo strtoupper(substr($_SESSION['username'], 0, 1)); ?></div>
                            <span class="user-name-small"><?php echo htmlspecialchars($_SESSION['username']); ?></span>
                            <i class="fas fa-chevron-down"></i>
                        </button>
                        <div class="dropdown-menu" id="userDropdown">
                            <a href="profile.php" class="dropdown-item"><i class="fas fa-user"></i><span>Mi Perfil</span></a>
                            <div class="dropdown-divider"></div>
                            <a href="../api/auth.php?action=logout" class="dropdown-item"><i class="fas fa-sign-out-alt"></i><span>Cerrar Sesión</span></a>
                        </div>
                    </div>
                </div>
            </header>
            
            <div class="content">
                <div class="row">
                    <!-- Guía rápida -->
                    <div class="col-12">
                        <div class="card">
                            <div class="card-header">
                                <h3 class="card-title"><i class="fas fa-rocket"></i> Guía Rápida</h3>
                            </div>
                            <div class="card-body">
                                <div class="row">
                                    <div class="col-12 col-md-6">
                                        <div style="padding: 15px;">
                                            <h4><i class="fas fa-user-plus"></i> Crear Usuario</h4>
                                            <p>1. Ve a la sección <strong>Usuarios</strong><br>
                                            2. Haz clic en <strong>Crear Usuario</strong><br>
                                            3. Completa los datos (usuario, contraseña, días)<br>
                                            4. El usuario se creará automáticamente en el sistema</p>
                                        </div>
                                    </div>
                                    <div class="col-12 col-md-6">
                                        <div style="padding: 15px;">
                                            <h4><i class="fas fa-calendar-plus"></i> Extender Usuario</h4>
                                            <p>1. Ve a la sección <strong>Usuarios</strong><br>
                                            2. Busca el usuario que deseas extender<br>
                                            3. Haz clic en el botón <strong>Extender</strong><br>
                                            4. Ingresa los días adicionales</p>
                                        </div>
                                    </div>
                                    <div class="col-12 col-md-6">
                                        <div style="padding: 15px;">
                                            <h4><i class="fas fa-trash"></i> Eliminar Usuario</h4>
                                            <p>1. Ve a la sección <strong>Usuarios</strong><br>
                                            2. Busca el usuario a eliminar<br>
                                            3. Haz clic en el botón <strong>Eliminar</strong><br>
                                            4. Confirma la acción</p>
                                        </div>
                                    </div>
                                    <div class="col-12 col-md-6">
                                        <div style="padding: 15px;">
                                            <h4><i class="fas fa-chart-line"></i> Ver Estadísticas</h4>
                                            <p>1. El <strong>Dashboard</strong> muestra estadísticas en tiempo real<br>
                                            2. Puedes ver usuarios online, carga del servidor, etc.<br>
                                            3. Las gráficas muestran el crecimiento de usuarios</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Preguntas frecuentes -->
                    <div class="col-12">
                        <div class="card">
                            <div class="card-header">
                                <h3 class="card-title"><i class="fas fa-question-circle"></i> Preguntas Frecuentes</h3>
                            </div>
                            <div class="card-body">
                                <div class="faq-item" style="margin-bottom: 20px; padding: 15px; background: var(--bg-tertiary); border-radius: 12px;">
                                    <h4><i class="fas fa-key"></i> ¿Cómo conectarme al servidor SSH?</h4>
                                    <p style="margin-top: 10px; color: var(--text-secondary);">
                                        Usa cualquier cliente SSH (PuTTY, Terminal, etc.) con los siguientes datos:<br>
                                        <code>Host: <?php echo $_SERVER['HTTP_HOST']; ?></code><br>
                                        <code>Puerto: <?php echo SSH_PORT; ?></code><br>
                                        <code>Usuario: [tu_usuario]</code><br>
                                        <code>Contraseña: [tu_contraseña]</code>
                                    </p>
                                </div>
                                
                                <div class="faq-item" style="margin-bottom: 20px; padding: 15px; background: var(--bg-tertiary); border-radius: 12px;">
                                    <h4><i class="fas fa-clock"></i> ¿Qué pasa cuando expira un usuario?</h4>
                                    <p style="margin-top: 10px; color: var(--text-secondary);">
                                        Cuando un usuario expira, automáticamente se bloquea el acceso al sistema. Puedes extender su tiempo desde el panel.
                                    </p>
                                </div>
                                
                                <div class="faq-item" style="margin-bottom: 20px; padding: 15px; background: var(--bg-tertiary); border-radius: 12px;">
                                    <h4><i class="fas fa-shield-alt"></i> ¿Es seguro el panel?</h4>
                                    <p style="margin-top: 10px; color: var(--text-secondary);">
                                        Sí, el panel implementa múltiples medidas de seguridad: contraseñas hasheadas, protección CSRF, rate limiting, logs de actividad, y más.
                                    </p>
                                </div>
                                
                                <div class="faq-item" style="margin-bottom: 20px; padding: 15px; background: var(--bg-tertiary); border-radius: 12px;">
                                    <h4><i class="fas fa-database"></i> ¿Cómo hacer un backup?</h4>
                                    <p style="margin-top: 10px; color: var(--text-secondary);">
                                        Ve a la sección <strong>Backups</strong> y haz clic en "Crear Nuevo Backup". También hay backups automáticos diarios.
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Comandos útiles -->
                    <div class="col-12 col-md-6">
                        <div class="card">
                            <div class="card-header">
                                <h3 class="card-title"><i class="fas fa-terminal"></i> Comandos Útiles (SSH)</h3>
                            </div>
                            <div class="card-body">
                                <pre style="background: var(--bg-tertiary); padding: 15px; border-radius: 12px; overflow-x: auto; font-size: 12px;">
<code># Ver usuarios del sistema
cat /etc/passwd | grep '/home'

# Ver usuarios conectados
who
w

# Ver logs del panel
tail -f /var/log/ceo-ssh-php.log

# Reiniciar servicios
systemctl restart nginx
systemctl restart php8.2-fpm
systemctl restart mariadb

# Ver estado de servicios
systemctl status nginx
systemctl status mariadb

# Ver puertos abiertos
netstat -tulpn

# Hacer backup manual
mysqldump -u ceo_ssh -p ceo_ssh > backup.sql</code>
                                </pre>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Contacto y soporte -->
                    <div class="col-12 col-md-6">
                        <div class="card">
                            <div class="card-header">
                                <h3 class="card-title"><i class="fas fa-headset"></i> Soporte</h3>
                            </div>
                            <div class="card-body">
                                <p style="margin-bottom: 15px;">¿Necesitas ayuda adicional? Contáctanos:</p>
                                <div style="display: flex; flex-direction: column; gap: 10px;">
                                    <div style="display: flex; align-items: center; gap: 10px;">
                                        <i class="fas fa-envelope" style="width: 30px; color: var(--accent);"></i>
                                        <span>soporte@ceo-ssh.com</span>
                                    </div>
                                    <div style="display: flex; align-items: center; gap: 10px;">
                                        <i class="fab fa-telegram" style="width: 30px; color: var(--accent);"></i>
                                        <span>@ceo_ssh_support</span>
                                    </div>
                                    <div style="display: flex; align-items: center; gap: 10px;">
                                        <i class="fab fa-whatsapp" style="width: 30px; color: var(--accent);"></i>
                                        <span>+123 456 7890</span>
                                    </div>
                                </div>
                                
                                <div style="margin-top: 20px; padding: 12px; background: var(--bg-tertiary); border-radius: 8px;">
                                    <small>
                                        <i class="fas fa-info-circle"></i> Tiempo de respuesta: 24-48 horas hábiles
                                    </small>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Versión y créditos -->
                    <div class="col-12">
                        <div class="card">
                            <div class="card-body" style="text-align: center;">
                                <p>
                                    <strong>CEO SSH Panel</strong> v<?php echo PANEL_VERSION; ?><br>
                                    <small style="color: var(--text-tertiary);">
                                        Panel de control profesional para gestión de VPN<br>
                                        &copy; <?php echo date('Y'); ?> Todos los derechos reservados
                                    </small>
                                </p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </main>
    </div>
</body>
</html>