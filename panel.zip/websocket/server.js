// ==============================================
// CEO SSH PANEL - WebSocket Server
// Para monitoreo en tiempo real
// ==============================================

const WebSocket = require('ws');
const http = require('http');
const { exec } = require('child_process');
const jwt = require('jsonwebtoken');

const PORT = 3002;
const JWT_SECRET = 'JWT_SECRET_PLACEHOLDER';

const server = http.createServer();
const wss = new WebSocket.Server({ server });

// Almacenar clientes conectados
const clients = new Map();

// Obtener estadísticas del sistema
async function getSystemStats() {
  return new Promise((resolve) => {
    const stats = {
      timestamp: new Date().toISOString(),
      cpu_usage: 0,
      memory_usage: 0,
      disk_usage: 0,
      online_users: 0,
      load_average: 0
    };
    
    // Obtener carga del sistema
    exec("uptime | awk -F'load average:' '{print $2}' | cut -d, -f1", (err, stdout) => {
      stats.load_average = parseFloat(stdout) || 0;
    });
    
    // Obtener usuarios online
    exec("ps aux | grep -E 'sshd|dropbear' | grep -v grep | wc -l", (err, stdout) => {
      stats.online_users = parseInt(stdout) || 0;
    });
    
    // Obtener uso de CPU
    exec("top -bn1 | grep 'Cpu(s)' | awk '{print $2}' | cut -d'%' -f1", (err, stdout) => {
      stats.cpu_usage = parseFloat(stdout) || 0;
      resolve(stats);
    });
    
    // Obtener uso de memoria
    exec("free | grep Mem | awk '{print ($3/$2) * 100}'", (err, stdout) => {
      stats.memory_usage = parseFloat(stdout) || 0;
    });
    
    // Obtener uso de disco
    exec("df -h / | awk 'NR==2 {print $5}' | sed 's/%//'", (err, stdout) => {
      stats.disk_usage = parseInt(stdout) || 0;
    });
  });
}

// Enviar estadísticas a todos los clientes
async function broadcastStats() {
  const stats = await getSystemStats();
  const message = JSON.stringify({
    type: 'stats',
    data: stats
  });
  
  clients.forEach((client, ws) => {
    if (ws.readyState === WebSocket.OPEN) {
      ws.send(message);
    }
  });
}

// Enviar logs en tiempo real
function broadcastLog(log) {
  const message = JSON.stringify({
    type: 'log',
    data: log
  });
  
  clients.forEach((client, ws) => {
    if (ws.readyState === WebSocket.OPEN && client.userId) {
      ws.send(message);
    }
  });
}

// Monitorear logs del sistema
function monitorSystemLogs() {
  const logFile = '/var/log/ceo-ssh-php.log';
  let lastSize = 0;
  
  setInterval(() => {
    try {
      const fs = require('fs');
      if (fs.existsSync(logFile)) {
        const stats = fs.statSync(logFile);
        if (stats.size > lastSize) {
          const stream = fs.createReadStream(logFile, {
            start: lastSize,
            end: stats.size
          });
          
          stream.on('data', (chunk) => {
            const lines = chunk.toString().split('\n');
            lines.forEach(line => {
              if (line.trim()) {
                broadcastLog({
                  timestamp: new Date().toISOString(),
                  message: line,
                  source: 'system'
                });
              }
            });
          });
          
          lastSize = stats.size;
        }
      }
    } catch (error) {
      console.error('Error monitoring logs:', error);
    }
  }, 2000);
}

// WebSocket connection handler
wss.on('connection', (ws, req) => {
  console.log('New WebSocket connection');
  
  // Obtener token de la URL
  const url = new URL(req.url, `http://${req.headers.host}`);
  const token = url.searchParams.get('token');
  
  if (!token) {
    ws.close(1008, 'No token provided');
    return;
  }
  
  // Verificar token
  try {
    const decoded = jwt.verify(token, JWT_SECRET);
    clients.set(ws, {
      userId: decoded.id,
      username: decoded.username,
      role: decoded.role,
      connectedAt: new Date()
    });
    
    console.log(`Client ${decoded.username} connected`);
    
    // Enviar estadísticas iniciales
    getSystemStats().then(stats => {
      ws.send(JSON.stringify({
        type: 'stats',
        data: stats
      }));
    });
    
  } catch (error) {
    console.error('Invalid token:', error.message);
    ws.close(1008, 'Invalid token');
    return;
  }
  
  // Manejar mensajes
  ws.on('message', async (data) => {
    try {
      const message = JSON.parse(data);
      const client = clients.get(ws);
      
      switch (message.type) {
        case 'ping':
          ws.send(JSON.stringify({ type: 'pong', timestamp: new Date().toISOString() }));
          break;
          
        case 'get_stats':
          const stats = await getSystemStats();
          ws.send(JSON.stringify({ type: 'stats', data: stats }));
          break;
          
        case 'execute_command':
          // Solo admin puede ejecutar comandos
          if (client && client.role === 'admin') {
            const allowedCommands = ['ls', 'ps', 'uptime', 'df', 'free', 'who'];
            const cmd = message.command;
            
            if (allowedCommands.some(allowed => cmd.startsWith(allowed))) {
              exec(cmd, (error, stdout, stderr) => {
                ws.send(JSON.stringify({
                  type: 'command_result',
                  command: cmd,
                  output: stdout || stderr,
                  error: error ? error.message : null
                }));
              });
            } else {
              ws.send(JSON.stringify({
                type: 'command_result',
                command: cmd,
                error: 'Command not allowed'
              }));
            }
          }
          break;
          
        default:
          console.log('Unknown message type:', message.type);
      }
    } catch (error) {
      console.error('Error parsing message:', error);
    }
  });
  
  // Manejar desconexión
  ws.on('close', () => {
    const client = clients.get(ws);
    if (client) {
      console.log(`Client ${client.username} disconnected`);
    }
    clients.delete(ws);
  });
  
  // Manejar errores
  ws.on('error', (error) => {
    console.error('WebSocket error:', error);
    clients.delete(ws);
  });
});

// Iniciar broadcast de estadísticas cada 5 segundos
setInterval(broadcastStats, 5000);

// Iniciar monitoreo de logs
monitorSystemLogs();

// Iniciar servidor
server.listen(PORT, () => {
  console.log(`🔌 WebSocket server running on port ${PORT}`);
  console.log(`📡 Waiting for connections...`);
});

// Graceful shutdown
process.on('SIGTERM', () => {
  console.log('SIGTERM received, closing WebSocket server...');
  wss.close(() => {
    console.log('WebSocket server closed');
    process.exit(0);
  });
});