// ==============================================
// CEO SSH PANEL - DASHBOARD JS
// Estadísticas, gráficas y monitoreo
// ==============================================

// Variables globales del dashboard
let statsChart = null;
let userGrowthChart = null;
let serverLoadChart = null;
let chartUpdateInterval = null;

// ==============================================
// INICIALIZACIÓN DEL DASHBOARD
// ==============================================

document.addEventListener('DOMContentLoaded', () => {
    if (document.getElementById('dashboardContent')) {
        initDashboard();
    }
});

function initDashboard() {
    // Inicializar gráficas
    initUserGrowthChart();
    initServerLoadChart();
    
    // Cargar datos iniciales
    loadDashboardStats();
    loadRecentActivity();
    
    // Configurar actualización automática
    if (chartUpdateInterval) clearInterval(chartUpdateInterval);
    chartUpdateInterval = setInterval(() => {
        updateCharts();
    }, 60000); // Actualizar cada minuto
    
    // Escuchar eventos de WebSocket
    document.addEventListener('websocketConnected', () => {
        console.log('WebSocket connected, enabling real-time updates');
    });
}

// ==============================================
// GRÁFICA DE CRECIMIENTO DE USUARIOS
// ==============================================

async function initUserGrowthChart() {
    const canvas = document.getElementById('userGrowthChart');
    if (!canvas) return;
    
    // Esperar a que Chart.js esté cargado
    if (typeof Chart === 'undefined') {
        setTimeout(initUserGrowthChart, 500);
        return;
    }
    
    try {
        const response = await fetch('/api/stats.php?chart=growth', {
            credentials: 'include'
        });
        const data = await response.json();
        
        if (data.success) {
            const ctx = canvas.getContext('2d');
            
            userGrowthChart = new Chart(ctx, {
                type: 'line',
                data: {
                    labels: data.data.labels,
                    datasets: [{
                        label: 'Usuarios Creados',
                        data: data.data.values,
                        borderColor: '#0087ff',
                        backgroundColor: 'rgba(0, 135, 255, 0.1)',
                        borderWidth: 2,
                        fill: true,
                        tension: 0.4,
                        pointBackgroundColor: '#0087ff',
                        pointBorderColor: '#ffffff',
                        pointRadius: 4,
                        pointHoverRadius: 6
                    }]
                },
                options: getChartOptions('Crecimiento de Usuarios')
            });
        }
    } catch (error) {
        console.error('Error loading user growth chart:', error);
    }
}

// ==============================================
// GRÁFICA DE CARGA DEL SERVIDOR
// ==============================================

async function initServerLoadChart() {
    const canvas = document.getElementById('serverLoadChart');
    if (!canvas) return;
    
    if (typeof Chart === 'undefined') {
        setTimeout(initServerLoadChart, 500);
        return;
    }
    
    const ctx = canvas.getContext('2d');
    
    serverLoadChart = new Chart(ctx, {
        type: 'line',
        data: {
            labels: ['00:00', '01:00', '02:00', '03:00', '04:00', '05:00', '06:00', '07:00', '08:00', '09:00', '10:00', '11:00'],
            datasets: [{
                label: 'Carga del Servidor',
                data: [0.5, 0.6, 0.4, 0.3, 0.4, 0.5, 0.8, 1.2, 1.5, 1.8, 1.6, 1.4],
                borderColor: '#f59e0b',
                backgroundColor: 'rgba(245, 158, 11, 0.1)',
                borderWidth: 2,
                fill: true,
                tension: 0.4
            }]
        },
        options: getChartOptions('Carga del Servidor (Load Average)')
    });
}

// ==============================================
// CONFIGURACIÓN DE GRÁFICAS
// ==============================================

function getChartOptions(title) {
    const isDark = currentTheme === 'dark';
    
    return {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
            legend: {
                labels: {
                    color: isDark ? '#a1a1aa' : '#3f3f46',
                    font: { size: 12 }
                }
            },
            tooltip: {
                mode: 'index',
                intersect: false,
                backgroundColor: isDark ? '#1e1e2e' : '#ffffff',
                titleColor: isDark ? '#ffffff' : '#18181b',
                bodyColor: isDark ? '#a1a1aa' : '#3f3f46',
                borderColor: isDark ? '#27272a' : '#e4e4e7',
                borderWidth: 1
            }
        },
        scales: {
            y: {
                beginAtZero: true,
                grid: {
                    color: isDark ? '#27272a' : '#e4e4e7',
                    drawBorder: false
                },
                ticks: {
                    color: isDark ? '#a1a1aa' : '#3f3f46',
                    stepSize: 1
                }
            },
            x: {
                grid: {
                    display: false
                },
                ticks: {
                    color: isDark ? '#a1a1aa' : '#3f3f46'
                }
            }
        },
        interaction: {
            mode: 'nearest',
            axis: 'x',
            intersect: false
        }
    };
}

// ==============================================
// ACTUALIZAR GRÁFICAS
// ==============================================

async function updateCharts() {
    await updateUserGrowthChart();
    await updateServerLoadChart();
}

async function updateUserGrowthChart() {
    if (!userGrowthChart) return;
    
    try {
        const response = await fetch('/api/stats.php?chart=growth', {
            credentials: 'include'
        });
        const data = await response.json();
        
        if (data.success && userGrowthChart) {
            userGrowthChart.data.datasets[0].data = data.data.values;
            userGrowthChart.update();
        }
    } catch (error) {
        console.error('Error updating user growth chart:', error);
    }
}

async function updateServerLoadChart() {
    if (!serverLoadChart) return;
    
    try {
        const response = await fetch('/api/stats.php?chart=load', {
            credentials: 'include'
        });
        const data = await response.json();
        
        if (data.success && serverLoadChart) {
            serverLoadChart.data.datasets[0].data = data.data.values;
            serverLoadChart.update();
        }
    } catch (error) {
        console.error('Error updating server load chart:', error);
    }
}

// ==============================================
// ESTADÍSTICAS DEL DASHBOARD
// ==============================================

async function loadDashboardStats() {
    try {
        const response = await fetch('/api/stats.php', {
            credentials: 'include'
        });
        const data = await response.json();
        
        if (data.success) {
            updateDashboardStats(data.data);
        }
    } catch (error) {
        console.error('Error loading dashboard stats:', error);
    }
}

function updateDashboardStats(stats) {
    // Actualizar contadores principales
    const elements = {
        'totalUsers': stats.total_users,
        'activeUsers': stats.active_tokens,
        'onlineUsers': stats.online_users,
        'serverLoad': stats.load,
        'diskUsage': stats.disk_usage + '%',
        'memoryUsage': stats.memory_usage + '%'
    };
    
    for (const [id, value] of Object.entries(elements)) {
        const element = document.getElementById(id);
        if (element) {
            element.innerHTML = value;
            
            // Agregar animación de cambio
            element.classList.add('stat-updated');
            setTimeout(() => element.classList.remove('stat-updated'), 500);
        }
    }
}

// ==============================================
// ACTIVIDAD RECIENTE
// ==============================================

async function loadRecentActivity() {
    const container = document.getElementById('recentActivity');
    if (!container) return;
    
    try {
        const response = await fetch('/api/logs.php?limit=10', {
            credentials: 'include'
        });
        const data = await response.json();
        
        if (data.success && data.data.length > 0) {
            container.innerHTML = data.data.map(log => `
                <div class="activity-item">
                    <div class="activity-icon">
                        <i class="fas ${getActivityIcon(log.action)}"></i>
                    </div>
                    <div class="activity-content">
                        <div class="activity-action">${escapeHtml(log.action)}</div>
                        <div class="activity-details">${escapeHtml(log.details)}</div>
                        <div class="activity-time">${formatRelativeTime(log.created_at)}</div>
                    </div>
                </div>
            `).join('');
        } else {
            container.innerHTML = `
                <div class="empty-state">
                    <i class="fas fa-history"></i>
                    <p>No hay actividad reciente</p>
                </div>
            `;
        }
    } catch (error) {
        console.error('Error loading recent activity:', error);
    }
}

function getActivityIcon(action) {
    const icons = {
        'login': 'fa-sign-in-alt',
        'logout': 'fa-sign-out-alt',
        'create_user': 'fa-user-plus',
        'delete_user': 'fa-user-minus',
        'extend_user': 'fa-calendar-plus',
        'change_password': 'fa-key',
        'update_settings': 'fa-cog',
        'create_backup': 'fa-database',
        'delete_backup': 'fa-trash'
    };
    
    return icons[action] || 'fa-circle-info';
}

// ==============================================
// SERVIDORES Y SERVICIOS
// ==============================================

async function loadServerStatus() {
    const container = document.getElementById('serverStatus');
    if (!container) return;
    
    try {
        const response = await fetch('/api/server.php?action=status', {
            credentials: 'include'
        });
        const data = await response.json();
        
        if (data.success) {
            container.innerHTML = data.data.map(service => `
                <div class="service-item">
                    <div class="service-name">
                        <i class="fas ${service.icon}"></i>
                        ${service.name}
                    </div>
                    <div class="service-port">Puerto: ${service.port}</div>
                    <div class="service-status status-${service.status}">
                        <i class="fas ${service.status === 'active' ? 'fa-check-circle' : 'fa-exclamation-circle'}"></i>
                        ${service.status === 'active' ? 'Activo' : 'Inactivo'}
                    </div>
                </div>
            `).join('');
        }
    } catch (error) {
        console.error('Error loading server status:', error);
    }
}

// ==============================================
// ACCIONES RÁPIDAS
// ==============================================

function quickCreateUser() {
    openModal('createUserModal');
}

function quickBackup() {
    showLoading('quickBackupBtn', 'Creando backup...');
    
    fetch('/api/backup.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'X-Requested-With': 'XMLHttpRequest'
        },
        body: JSON.stringify({ action: 'create' }),
        credentials: 'include'
    })
    .then(response => response.json())
    .then(data => {
        hideLoading('quickBackupBtn');
        if (data.success) {
            showToast('Backup creado exitosamente', 'success');
            setTimeout(() => location.reload(), 1000);
        } else {
            showToast(data.error || 'Error al crear backup', 'error');
        }
    })
    .catch(error => {
        hideLoading('quickBackupBtn');
        showToast('Error de conexión', 'error');
    });
}

function quickRefresh() {
    showToast('Actualizando datos...', 'info');
    loadDashboardStats();
    loadRecentActivity();
    updateCharts();
}

// ==============================================
// EXPORTAR FUNCIONES
// ==============================================

window.quickCreateUser = quickCreateUser;
window.quickBackup = quickBackup;
window.quickRefresh = quickRefresh;