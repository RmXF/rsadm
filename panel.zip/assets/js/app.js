// ==============================================
// CEO SSH PANEL - JAVASCRIPT PRINCIPAL
// Versión: 2.0.0
// ==============================================

// ==============================================
// VARIABLES GLOBALES
// ==============================================

let currentTheme = localStorage.getItem('theme') || 'dark';
let notificationsInterval = null;
let statsInterval = null;
let currentUser = null;
let socket = null;
let csrfToken = null;

// ==============================================
// INICIALIZACIÓN
// ==============================================

document.addEventListener('DOMContentLoaded', () => {
    // Inicializar tema
    initTheme();
    
    // Inicializar sidebar
    initSidebar();
    
    // Inicializar CSRF
    initCSRF();
    
    // Cargar usuario actual
    loadCurrentUser();
    
    // Inicializar tooltips
    initTooltips();
    
    // Configurar eventos globales
    setupGlobalEvents();
    
    // Inicializar WebSocket si está disponible
    initWebSocket();
    
    // Cargar datos iniciales
    if (document.getElementById('stats-grid')) {
        loadStats();
        statsInterval = setInterval(loadStats, 30000);
    }
    
    if (document.getElementById('notificationList')) {
        loadNotifications();
        notificationsInterval = setInterval(loadNotifications, 60000);
    }
});

// Limpiar intervalos al salir
window.addEventListener('beforeunload', () => {
    if (statsInterval) clearInterval(statsInterval);
    if (notificationsInterval) clearInterval(notificationsInterval);
    if (socket) socket.close();
});

// ==============================================
// TEMA (MODO OSCURO/CLARO)
// ==============================================

function initTheme() {
    setTheme(currentTheme);
    
    // Detectar tema del sistema
    const prefersDark = window.matchMedia('(prefers-color-scheme: dark)');
    prefersDark.addEventListener('change', (e) => {
        if (!localStorage.getItem('theme')) {
            setTheme(e.matches ? 'dark' : 'light');
        }
    });
}

function setTheme(theme) {
    if (theme === 'light') {
        document.body.classList.add('light');
        document.documentElement.style.setProperty('--bg-primary', '#ffffff');
        document.documentElement.style.setProperty('--bg-secondary', '#f4f4f5');
        document.documentElement.style.setProperty('--bg-tertiary', '#e4e4e7');
        document.documentElement.style.setProperty('--bg-card', '#ffffff');
        document.documentElement.style.setProperty('--text-primary', '#18181b');
        document.documentElement.style.setProperty('--text-secondary', '#3f3f46');
        document.documentElement.style.setProperty('--text-tertiary', '#71717a');
        document.documentElement.style.setProperty('--border', '#e4e4e7');
    } else {
        document.body.classList.remove('light');
        document.documentElement.style.setProperty('--bg-primary', '#0a0a0f');
        document.documentElement.style.setProperty('--bg-secondary', '#11111b');
        document.documentElement.style.setProperty('--bg-tertiary', '#181825');
        document.documentElement.style.setProperty('--bg-card', '#1e1e2e');
        document.documentElement.style.setProperty('--text-primary', '#ffffff');
        document.documentElement.style.setProperty('--text-secondary', '#a1a1aa');
        document.documentElement.style.setProperty('--text-tertiary', '#71717a');
        document.documentElement.style.setProperty('--border', '#27272a');
    }
    
    localStorage.setItem('theme', theme);
    currentTheme = theme;
    
    // Actualizar icono
    const themeIcon = document.getElementById('themeIcon');
    if (themeIcon) {
        themeIcon.className = theme === 'dark' ? 'fas fa-sun' : 'fas fa-moon';
    }
    
    // Disparar evento personalizado
    document.dispatchEvent(new CustomEvent('themeChanged', { detail: { theme } }));
}

function toggleTheme() {
    setTheme(currentTheme === 'dark' ? 'light' : 'dark');
}

// ==============================================
// SIDEBAR
// ==============================================

function initSidebar() {
    const collapsed = localStorage.getItem('sidebarCollapsed') === 'true';
    const sidebar = document.getElementById('sidebar');
    const mainContent = document.getElementById('mainContent');
    
    if (collapsed && sidebar && mainContent) {
        sidebar.classList.add('collapsed');
        mainContent.classList.add('expanded');
    }
    
    // Cerrar sidebar en móvil al hacer clic en un enlace
    const sidebarLinks = document.querySelectorAll('.sidebar-link');
    sidebarLinks.forEach(link => {
        link.addEventListener('click', () => {
            if (window.innerWidth <= 768) {
                closeMobileSidebar();
            }
        });
    });
}

function toggleSidebar() {
    const sidebar = document.getElementById('sidebar');
    const mainContent = document.getElementById('mainContent');
    
    if (sidebar && mainContent) {
        sidebar.classList.toggle('collapsed');
        mainContent.classList.toggle('expanded');
        localStorage.setItem('sidebarCollapsed', sidebar.classList.contains('collapsed'));
    }
}

function openMobileSidebar() {
    const sidebar = document.getElementById('sidebar');
    if (sidebar) {
        sidebar.classList.add('mobile-open');
        document.body.style.overflow = 'hidden';
    }
}

function closeMobileSidebar() {
    const sidebar = document.getElementById('sidebar');
    if (sidebar) {
        sidebar.classList.remove('mobile-open');
        document.body.style.overflow = '';
    }
}

// ==============================================
// CSRF PROTECTION
// ==============================================

async function initCSRF() {
    try {
        const response = await fetch('/api/auth.php?action=csrf', {
            credentials: 'include'
        });
        const data = await response.json();
        if (data.success) {
            csrfToken = data.token;
        }
    } catch (error) {
        console.error('Error loading CSRF token:', error);
    }
}

function getCSRFToken() {
    return csrfToken;
}

// ==============================================
// MODALES
// ==============================================

function openModal(modalId) {
    const modal = document.getElementById(modalId);
    if (modal) {
        modal.classList.add('show');
        document.body.style.overflow = 'hidden';
        
        // Disparar evento
        document.dispatchEvent(new CustomEvent('modalOpened', { detail: { modalId } }));
    }
}

function closeModal(modalId) {
    const modal = document.getElementById(modalId);
    if (modal) {
        modal.classList.remove('show');
        document.body.style.overflow = '';
        
        // Disparar evento
        document.dispatchEvent(new CustomEvent('modalClosed', { detail: { modalId } }));
    }
}

function closeAllModals() {
    document.querySelectorAll('.modal.show').forEach(modal => {
        modal.classList.remove('show');
    });
    document.body.style.overflow = '';
}

// Cerrar modal con ESC
document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') {
        closeAllModals();
        closeDropdowns();
    }
});

// Cerrar modal al hacer clic fuera
document.addEventListener('click', (e) => {
    if (e.target.classList.contains('modal')) {
        closeModal(e.target.id);
    }
});

// ==============================================
// DROPDOWNS
// ==============================================

function toggleDropdown(dropdownId) {
    const dropdown = document.getElementById(dropdownId);
    if (dropdown) {
        const isOpen = dropdown.classList.contains('show');
        closeDropdowns();
        if (!isOpen) {
            dropdown.classList.add('show');
        }
    }
}

function closeDropdowns() {
    document.querySelectorAll('.dropdown-menu, .notification-dropdown').forEach(dropdown => {
        dropdown.classList.remove('show');
    });
}

// Cerrar dropdowns al hacer clic fuera
document.addEventListener('click', (e) => {
    if (!e.target.closest('.user-dropdown') && !e.target.closest('.notification-btn')) {
        closeDropdowns();
    }
});

// ==============================================
// WEB SOCKET
// ==============================================

function initWebSocket() {
    const token = localStorage.getItem('token');
    if (!token) return;
    
    const wsProtocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
    const wsUrl = `${wsProtocol}//${window.location.hostname}:3002?token=${token}`;
    
    try {
        socket = new WebSocket(wsUrl);
        
        socket.onopen = () => {
            console.log('WebSocket connected');
            document.dispatchEvent(new CustomEvent('websocketConnected'));
        };
        
        socket.onmessage = (event) => {
            try {
                const data = JSON.parse(event.data);
                handleWebSocketMessage(data);
            } catch (error) {
                console.error('Error parsing WebSocket message:', error);
            }
        };
        
        socket.onerror = (error) => {
            console.error('WebSocket error:', error);
        };
        
        socket.onclose = () => {
            console.log('WebSocket disconnected');
            // Intentar reconectar después de 5 segundos
            setTimeout(initWebSocket, 5000);
        };
    } catch (error) {
        console.error('Error creating WebSocket:', error);
    }
}

function handleWebSocketMessage(data) {
    switch (data.type) {
        case 'stats':
            updateRealtimeStats(data.data);
            break;
        case 'log':
            addRealtimeLog(data.data);
            break;
        case 'notification':
            showToast(data.data.message, data.data.type);
            loadNotifications(); // Recargar notificaciones
            break;
        case 'pong':
            // Heartbeat response
            break;
        default:
            console.log('Unknown WebSocket message type:', data.type);
    }
}

function updateRealtimeStats(stats) {
    const elements = {
        'onlineUsers': stats.online_users,
        'serverLoad': stats.load_average,
        'cpuUsage': stats.cpu_usage,
        'memoryUsage': stats.memory_usage
    };
    
    for (const [id, value] of Object.entries(elements)) {
        const element = document.getElementById(id);
        if (element) {
            element.innerHTML = value;
        }
    }
}

function addRealtimeLog(log) {
    const logContainer = document.getElementById('realtimeLogs');
    if (logContainer) {
        const logEntry = document.createElement('div');
        logEntry.className = 'log-entry';
        logEntry.innerHTML = `
            <span class="log-time">[${log.timestamp}]</span>
            <span class="log-message">${escapeHtml(log.message)}</span>
        `;
        logContainer.prepend(logEntry);
        
        // Limitar número de logs
        while (logContainer.children.length > 100) {
            logContainer.removeChild(logContainer.lastChild);
        }
    }
}

// ==============================================
// NOTIFICACIONES
// ==============================================

async function loadNotifications() {
    try {
        const response = await fetch('/api/notifications.php', {
            headers: {
                'X-Requested-With': 'XMLHttpRequest'
            },
            credentials: 'include'
        });
        const data = await response.json();
        
        if (data.success) {
            updateNotificationUI(data.data.notifications);
            updateNotificationBadge(data.data.unread_count);
        }
    } catch (error) {
        console.error('Error loading notifications:', error);
    }
}

function updateNotificationUI(notifications) {
    const container = document.getElementById('notificationList');
    if (!container) return;
    
    if (!notifications || notifications.length === 0) {
        container.innerHTML = `
            <div class="empty-state">
                <i class="fas fa-bell-slash"></i>
                <p>No hay notificaciones</p>
            </div>
        `;
        return;
    }
    
    container.innerHTML = notifications.map(notif => `
        <div class="notification-item ${notif.is_read ? '' : 'unread'}" onclick="markNotificationAsRead(${notif.id})">
            <div class="notification-icon">
                <i class="fas ${getNotificationIcon(notif.type)}"></i>
            </div>
            <div class="notification-content">
                <div class="notification-title">${escapeHtml(notif.title)}</div>
                <div class="notification-message">${escapeHtml(notif.message)}</div>
                <div class="notification-time">${formatRelativeTime(notif.created_at)}</div>
            </div>
        </div>
    `).join('');
}

function getNotificationIcon(type) {
    switch (type) {
        case 'success': return 'fa-check-circle';
        case 'error': return 'fa-exclamation-circle';
        case 'warning': return 'fa-exclamation-triangle';
        default: return 'fa-info-circle';
    }
}

function updateNotificationBadge(count) {
    const badge = document.getElementById('notificationBadge');
    if (badge) {
        if (count > 0) {
            badge.textContent = count > 99 ? '99+' : count;
            badge.style.display = 'flex';
        } else {
            badge.style.display = 'none';
        }
    }
}

async function markNotificationAsRead(id) {
    try {
        const response = await fetch('/api/notifications.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-Requested-With': 'XMLHttpRequest'
            },
            body: JSON.stringify({ action: 'mark_read', id: id }),
            credentials: 'include'
        });
        
        const data = await response.json();
        if (data.success) {
            loadNotifications();
        }
    } catch (error) {
        console.error('Error marking notification as read:', error);
    }
}

async function markAllNotificationsAsRead() {
    try {
        const response = await fetch('/api/notifications.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-Requested-With': 'XMLHttpRequest'
            },
            body: JSON.stringify({ action: 'mark_all_read' }),
            credentials: 'include'
        });
        
        const data = await response.json();
        if (data.success) {
            loadNotifications();
            showToast('Todas las notificaciones marcadas como leídas', 'success');
        }
    } catch (error) {
        console.error('Error marking all as read:', error);
    }
}

// ==============================================
// ESTADÍSTICAS
// ==============================================

async function loadStats() {
    try {
        const response = await fetch('/api/stats.php', {
            headers: {
                'X-Requested-With': 'XMLHttpRequest'
            },
            credentials: 'include'
        });
        const data = await response.json();
        
        if (data.success) {
            updateStatsUI(data.data);
        }
    } catch (error) {
        console.error('Error loading stats:', error);
    }
}

function updateStatsUI(stats) {
    const elements = {
        'totalUsers': stats.total_users,
        'activeTokens': stats.active_tokens,
        'expiredTokens': stats.expired_tokens,
        'onlineUsers': stats.online_users,
        'serverLoad': stats.load,
        'diskUsage': stats.disk_usage + '%',
        'memoryUsage': stats.memory_usage + '%',
        'totalLogs': stats.total_logs,
        'logsToday': stats.logs_today,
        'activeSessions': stats.active_sessions
    };
    
    for (const [id, value] of Object.entries(elements)) {
        const element = document.getElementById(id);
        if (element) {
            element.innerHTML = value;
        }
    }
}

// ==============================================
// USUARIO ACTUAL
// ==============================================

async function loadCurrentUser() {
    try {
        const response = await fetch('/api/auth.php?action=user', {
            credentials: 'include'
        });
        const data = await response.json();
        
        if (data.success) {
            currentUser = data.data;
            updateUserUI();
        }
    } catch (error) {
        console.error('Error loading current user:', error);
    }
}

function updateUserUI() {
    if (!currentUser) return;
    
    // Actualizar nombre de usuario en la UI
    const userElements = document.querySelectorAll('.user-name, .user-name-small');
    userElements.forEach(el => {
        if (el) el.textContent = currentUser.username;
    });
    
    // Actualizar avatar
    const avatarElements = document.querySelectorAll('.user-avatar, .user-avatar-small');
    avatarElements.forEach(el => {
        if (el) el.textContent = currentUser.username.charAt(0).toUpperCase();
    });
}

// ==============================================
// TOOLTIPS
// ==============================================

function initTooltips() {
    const tooltips = document.querySelectorAll('[data-tooltip]');
    tooltips.forEach(el => {
        el.addEventListener('mouseenter', showTooltip);
        el.addEventListener('mouseleave', hideTooltip);
    });
}

let activeTooltip = null;

function showTooltip(e) {
    const text = e.target.getAttribute('data-tooltip');
    if (!text) return;
    
    hideTooltip();
    
    const tooltip = document.createElement('div');
    tooltip.className = 'tooltip';
    tooltip.textContent = text;
    document.body.appendChild(tooltip);
    
    const rect = e.target.getBoundingClientRect();
    tooltip.style.left = rect.left + (rect.width / 2) - (tooltip.offsetWidth / 2) + 'px';
    tooltip.style.top = rect.top - tooltip.offsetHeight - 10 + 'px';
    
    activeTooltip = tooltip;
}

function hideTooltip() {
    if (activeTooltip) {
        activeTooltip.remove();
        activeTooltip = null;
    }
}

// ==============================================
// TOAST NOTIFICATIONS
// ==============================================

let toastContainer = null;

function initToastContainer() {
    if (!toastContainer) {
        toastContainer = document.createElement('div');
        toastContainer.className = 'toast-container';
        document.body.appendChild(toastContainer);
    }
}

function showToast(message, type = 'info', duration = 3000) {
    initToastContainer();
    
    const toast = document.createElement('div');
    toast.className = `toast toast-${type}`;
    toast.innerHTML = `
        <div class="toast-icon">
            <i class="fas ${getToastIcon(type)}"></i>
        </div>
        <div class="toast-content">
            <div class="toast-message">${escapeHtml(message)}</div>
        </div>
        <button class="toast-close" onclick="this.parentElement.remove()">
            <i class="fas fa-times"></i>
        </button>
    `;
    
    toastContainer.appendChild(toast);
    
    // Animación de entrada
    setTimeout(() => toast.classList.add('show'), 10);
    
    // Auto-cerrar
    setTimeout(() => {
        toast.classList.remove('show');
        setTimeout(() => toast.remove(), 300);
    }, duration);
}

function getToastIcon(type) {
    switch (type) {
        case 'success': return 'fa-check-circle';
        case 'error': return 'fa-exclamation-circle';
        case 'warning': return 'fa-exclamation-triangle';
        default: return 'fa-info-circle';
    }
}

// ==============================================
// LOADING STATES
// ==============================================

function showLoading(elementId, text = 'Cargando...') {
    const element = document.getElementById(elementId);
    if (element) {
        element.disabled = true;
        element.dataset.originalText = element.innerHTML;
        element.innerHTML = `<i class="fas fa-spinner fa-spin"></i> ${text}`;
    }
}

function hideLoading(elementId) {
    const element = document.getElementById(elementId);
    if (element && element.dataset.originalText) {
        element.disabled = false;
        element.innerHTML = element.dataset.originalText;
        delete element.dataset.originalText;
    }
}

function showPageLoader() {
    const loader = document.createElement('div');
    loader.id = 'pageLoader';
    loader.className = 'page-loader';
    loader.innerHTML = '<div class="spinner"></div>';
    document.body.appendChild(loader);
}

function hidePageLoader() {
    const loader = document.getElementById('pageLoader');
    if (loader) loader.remove();
}

// ==============================================
// CONFIRM DIALOGS
// ==============================================

function confirmDialog(message, onConfirm, onCancel) {
    const modal = document.createElement('div');
    modal.className = 'modal confirm-modal show';
    modal.innerHTML = `
        <div class="modal-content" style="max-width: 400px;">
            <div class="modal-header">
                <h3>Confirmar</h3>
                <button class="modal-close" onclick="this.closest('.modal').remove()">&times;</button>
            </div>
            <div class="modal-body">
                <p>${escapeHtml(message)}</p>
            </div>
            <div class="modal-footer">
                <button class="btn btn-secondary" onclick="this.closest('.modal').remove(); if(window.onCancel) window.onCancel()">Cancelar</button>
                <button class="btn btn-primary" onclick="this.closest('.modal').remove(); if(window.onConfirm) window.onConfirm()">Aceptar</button>
            </div>
        </div>
    `;
    
    window.onConfirm = onConfirm;
    window.onCancel = onCancel;
    
    document.body.appendChild(modal);
}

// ==============================================
// FORM VALIDATION
// ==============================================

function validateForm(formId, rules) {
    const form = document.getElementById(formId);
    if (!form) return false;
    
    let isValid = true;
    const errors = [];
    
    for (const [fieldName, fieldRules] of Object.entries(rules)) {
        const input = form.querySelector(`[name="${fieldName}"]`);
        if (!input) continue;
        
        const value = input.value.trim();
        
        if (fieldRules.required && !value) {
            isValid = false;
            errors.push(`${fieldRules.label || fieldName} es requerido`);
            input.classList.add('error');
        }
        
        if (fieldRules.minLength && value.length < fieldRules.minLength) {
            isValid = false;
            errors.push(`${fieldRules.label || fieldName} debe tener al menos ${fieldRules.minLength} caracteres`);
            input.classList.add('error');
        }
        
        if (fieldRules.pattern && !fieldRules.pattern.test(value)) {
            isValid = false;
            errors.push(`${fieldRules.label || fieldName} tiene un formato inválido`);
            input.classList.add('error');
        }
    }
    
    if (!isValid && errors.length > 0) {
        showToast(errors[0], 'error');
    }
    
    return isValid;
}

// ==============================================
// EVENTOS GLOBALES
// ==============================================

function setupGlobalEvents() {
    // Enter key para submit de formularios
    document.addEventListener('keypress', (e) => {
        if (e.key === 'Enter' && e.target.form) {
            const submitBtn = e.target.form.querySelector('button[type="submit"]');
            if (submitBtn) submitBtn.click();
        }
    });
    
    // Prevenir submit duplicado
    document.addEventListener('submit', (e) => {
        const form = e.target;
        const submitBtn = form.querySelector('button[type="submit"]');
        if (submitBtn && submitBtn.disabled) {
            e.preventDefault();
        }
    });
}

// ==============================================
// UTILIDADES EXPORTADAS
// ==============================================

// Hacer funciones globales disponibles
window.toggleTheme = toggleTheme;
window.toggleSidebar = toggleSidebar;
window.openModal = openModal;
window.closeModal = closeModal;
window.toggleDropdown = toggleDropdown;
window.showToast = showToast;
window.confirmDialog = confirmDialog;
window.copyToClipboard = copyToClipboard;
window.formatBytes = formatBytes;
window.formatDate = formatDate;
window.formatRelativeTime = formatRelativeTime;
window.escapeHtml = escapeHtml;