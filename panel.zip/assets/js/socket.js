// ==============================================
// CEO SSH PANEL - WEBSOCKET CLIENT
// Conexión en tiempo real con el servidor
// ==============================================

// ==============================================
// CONFIGURACIÓN DEL SOCKET
// ==============================================

let socket = null;
let reconnectAttempts = 0;
let maxReconnectAttempts = 10;
let reconnectDelay = 3000;
let heartbeatInterval = null;
let isConnecting = false;

// Eventos del socket
const socketEvents = {
    onConnect: [],
    onDisconnect: [],
    onStats: [],
    onLog: [],
    onNotification: [],
    onCommandResult: []
};

// ==============================================
// CONEXIÓN DEL SOCKET
// ==============================================

function connectWebSocket() {
    if (isConnecting || (socket && socket.readyState === WebSocket.OPEN)) {
        return;
    }
    
    isConnecting = true;
    
    const token = getAuthToken();
    if (!token) {
        console.log('No auth token, skipping WebSocket connection');
        isConnecting = false;
        return;
    }
    
    const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
    const wsUrl = `${protocol}//${window.location.hostname}:3002?token=${token}`;
    
    try {
        socket = new WebSocket(wsUrl);
        
        socket.onopen = handleSocketOpen;
        socket.onmessage = handleSocketMessage;
        socket.onerror = handleSocketError;
        socket.onclose = handleSocketClose;
        
    } catch (error) {
        console.error('Error creating WebSocket:', error);
        isConnecting = false;
        scheduleReconnect();
    }
}

function handleSocketOpen() {
    console.log('WebSocket connected');
    isConnecting = false;
    reconnectAttempts = 0;
    
    // Iniciar heartbeat
    if (heartbeatInterval) clearInterval(heartbeatInterval);
    heartbeatInterval = setInterval(() => {
        sendSocketMessage({ type: 'ping' });
    }, 30000);
    
    // Disparar eventos de conexión
    socketEvents.onConnect.forEach(callback => callback());
}

function handleSocketMessage(event) {
    try {
        const data = JSON.parse(event.data);
        
        switch (data.type) {
            case 'stats':
                socketEvents.onStats.forEach(callback => callback(data.data));
                break;
            case 'log':
                socketEvents.onLog.forEach(callback => callback(data.data));
                break;
            case 'notification':
                socketEvents.onNotification.forEach(callback => callback(data.data));
                break;
            case 'command_result':
                socketEvents.onCommandResult.forEach(callback => callback(data.data));
                break;
            case 'pong':
                // Heartbeat response, ignore
                break;
            default:
                console.log('Unknown message type:', data.type);
        }
    } catch (error) {
        console.error('Error parsing WebSocket message:', error);
    }
}

function handleSocketError(error) {
    console.error('WebSocket error:', error);
}

function handleSocketClose(event) {
    console.log('WebSocket disconnected:', event.code, event.reason);
    isConnecting = false;
    
    if (heartbeatInterval) {
        clearInterval(heartbeatInterval);
        heartbeatInterval = null;
    }
    
    // Disparar eventos de desconexión
    socketEvents.onDisconnect.forEach(callback => callback());
    
    // Intentar reconectar si no fue un cierre limpio
    if (event.code !== 1000) {
        scheduleReconnect();
    }
}

function scheduleReconnect() {
    if (reconnectAttempts >= maxReconnectAttempts) {
        console.log('Max reconnection attempts reached');
        return;
    }
    
    reconnectAttempts++;
    const delay = reconnectDelay * Math.pow(1.5, reconnectAttempts - 1);
    console.log(`Reconnecting in ${delay}ms (attempt ${reconnectAttempts}/${maxReconnectAttempts})`);
    
    setTimeout(() => {
        connectWebSocket();
    }, delay);
}

// ==============================================
// ENVÍO DE MENSAJES
// ==============================================

function sendSocketMessage(message) {
    if (socket && socket.readyState === WebSocket.OPEN) {
        socket.send(JSON.stringify(message));
        return true;
    }
    return false;
}

function requestRealtimeStats() {
    sendSocketMessage({ type: 'get_stats' });
}

function executeCommand(command) {
    return sendSocketMessage({ type: 'execute_command', command: command });
}

// ==============================================
// REGISTRO DE EVENTOS
// ==============================================

function onSocketConnect(callback) {
    socketEvents.onConnect.push(callback);
}

function onSocketDisconnect(callback) {
    socketEvents.onDisconnect.push(callback);
}

function onRealtimeStats(callback) {
    socketEvents.onStats.push(callback);
}

function onRealtimeLog(callback) {
    socketEvents.onLog.push(callback);
}

function onRealtimeNotification(callback) {
    socketEvents.onNotification.push(callback);
}

function onCommandResult(callback) {
    socketEvents.onCommandResult.push(callback);
}

// ==============================================
// UTILIDADES
// ==============================================

function getAuthToken() {
    return localStorage.getItem('token');
}

function isSocketConnected() {
    return socket && socket.readyState === WebSocket.OPEN;
}

function disconnectSocket() {
    if (socket) {
        socket.close(1000, 'User disconnected');
        socket = null;
    }
}

// ==============================================
// MONITOREO EN TIEMPO REAL
// ==============================================

let realtimeDataBuffer = [];
let flushInterval = null;

function startRealtimeMonitoring() {
    if (flushInterval) clearInterval(flushInterval);
    
    flushInterval = setInterval(() => {
        if (realtimeDataBuffer.length > 0) {
            const data = [...realtimeDataBuffer];
            realtimeDataBuffer = [];
            processRealtimeData(data);
        }
    }, 1000);
}

function addRealtimeData(data) {
    realtimeDataBuffer.push(data);
}

function processRealtimeData(data) {
    // Procesar datos en lote
    data.forEach(item => {
        switch (item.type) {
            case 'connection':
                updateConnectionStats(item);
                break;
            case 'traffic':
                updateTrafficStats(item);
                break;
            case 'user_activity':
                updateUserActivity(item);
                break;
        }
    });
}

function updateConnectionStats(stats) {
    const onlineUsersElement = document.getElementById('onlineUsers');
    if (onlineUsersElement) {
        onlineUsersElement.innerHTML = stats.online_users;
    }
    
    const activeConnectionsElement = document.getElementById('activeConnections');
    if (activeConnectionsElement) {
        activeConnectionsElement.innerHTML = stats.active_connections;
    }
}

function updateTrafficStats(traffic) {
    const trafficElement = document.getElementById('realtimeTraffic');
    if (trafficElement) {
        const download = (traffic.download / 1024 / 1024).toFixed(2);
        const upload = (traffic.upload / 1024 / 1024).toFixed(2);
        trafficElement.innerHTML = `↓ ${download} MB/s | ↑ ${upload} MB/s`;
    }
}

function updateUserActivity(activity) {
    const activityElement = document.getElementById('realtimeActivity');
    if (activityElement) {
        const activityHtml = `
            <div class="activity-item">
                <span class="activity-user">${escapeHtml(activity.username)}</span>
                <span class="activity-action">${escapeHtml(activity.action)}</span>
                <span class="activity-ip">${activity.ip}</span>
            </div>
        `;
        activityElement.insertAdjacentHTML('afterbegin', activityHtml);
        
        // Limitar número de elementos
        while (activityElement.children.length > 20) {
            activityElement.removeChild(activityElement.lastChild);
        }
    }
}

// ==============================================
// INICIALIZACIÓN
// ==============================================

document.addEventListener('DOMContentLoaded', () => {
    // Conectar WebSocket automáticamente
    setTimeout(connectWebSocket, 1000);
    
    // Iniciar monitoreo
    startRealtimeMonitoring();
});

// Reconectar cuando la página se vuelve visible
document.addEventListener('visibilitychange', () => {
    if (!document.hidden && (!socket || socket.readyState !== WebSocket.OPEN)) {
        connectWebSocket();
    }
});

// ==============================================
// EXPORTAR FUNCIONES
// ==============================================

window.connectWebSocket = connectWebSocket;
window.disconnectSocket = disconnectSocket;
window.isSocketConnected = isSocketConnected;
window.sendSocketMessage = sendSocketMessage;
window.requestRealtimeStats = requestRealtimeStats;
window.executeCommand = executeCommand;
window.onSocketConnect = onSocketConnect;
window.onSocketDisconnect = onSocketDisconnect;
window.onRealtimeStats = onRealtimeStats;
window.onRealtimeLog = onRealtimeLog;
window.onRealtimeNotification = onRealtimeNotification;