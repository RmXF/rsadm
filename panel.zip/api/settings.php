<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PUT, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With');

require_once '../includes/config.php';
require_once '../includes/auth.php';
require_once '../includes/functions.php';

// Manejar OPTIONS para CORS
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

// Solo administradores
if (!isAdmin()) {
    errorResponse('No autorizado. Se requieren permisos de administrador', 403);
}

$method = $_SERVER['REQUEST_METHOD'];

// ==============================================
// GET - Obtener configuración
// ==============================================
if ($method === 'GET') {
    $settings = [];
    $result = db_select("SELECT `key`, `value`, description FROM settings");
    
    foreach ($result as $row) {
        $settings[$row['key']] = [
            'value' => $row['value'],
            'description' => $row['description']
        ];
    }
    
    // Agregar información del sistema
    $settings['system'] = [
        'php_version' => PHP_VERSION,
        'mysql_version' => getDB()->server_info,
        'panel_version' => PANEL_VERSION,
        'panel_name' => PANEL_NAME,
        'server_software' => $_SERVER['SERVER_SOFTWARE'] ?? 'Unknown',
        'server_time' => date('Y-m-d H:i:s'),
        'timezone' => date_default_timezone_get()
    ];
    
    successResponse($settings);
}

// ==============================================
// POST - Actualizar configuración
// ==============================================
if ($method === 'POST' || $method === 'PUT') {
    $data = json_decode(file_get_contents('php://input'), true);
    
    if (!$data) {
        errorResponse('Datos no válidos');
    }
    
    $updated = 0;
    
    foreach ($data as $key => $value) {
        if (setSetting($key, $value)) {
            $updated++;
        }
    }
    
    addLog($_SESSION['user_id'], 'update_settings', "Actualizó $updated configuraciones", getClientIP(), getUserAgent());
    
    successResponse(['updated' => $updated], 'Configuración actualizada');
}

// ==============================================
// POST específico para cada sección
// ==============================================
if ($method === 'POST' && isset($_POST['section'])) {
    $section = $_POST['section'];
    
    if ($section === 'general') {
        setSetting('panel_name', $_POST['panel_name']);
        setSetting('maintenance_mode', $_POST['maintenance_mode']);
        setSetting('session_timeout', $_POST['session_timeout']);
        setSetting('default_expiration_days', $_POST['default_expiration_days']);
        setSetting('max_login_attempts', $_POST['max_login_attempts']);
        setSetting('login_lockout_time', $_POST['login_lockout_time']);
        
        addLog($_SESSION['user_id'], 'update_general_settings', 'Actualizó configuración general', getClientIP(), getUserAgent());
        successResponse(null, 'Configuración general guardada');
    }
    
    if ($section === 'notifications') {
        setSetting('notifications_enabled', $_POST['notifications_enabled']);
        setSetting('telegram_bot_token', $_POST['telegram_bot_token']);
        setSetting('telegram_chat_id', $_POST['telegram_chat_id']);
        setSetting('smtp_host', $_POST['smtp_host']);
        setSetting('smtp_port', $_POST['smtp_port']);
        setSetting('smtp_user', $_POST['smtp_user']);
        setSetting('smtp_pass', $_POST['smtp_pass']);
        setSetting('smtp_from', $_POST['smtp_from']);
        
        addLog($_SESSION['user_id'], 'update_notification_settings', 'Actualizó configuración de notificaciones', getClientIP(), getUserAgent());
        successResponse(null, 'Configuración de notificaciones guardada');
    }
    
    if ($section === 'security') {
        setSetting('recaptcha_site_key', $_POST['recaptcha_site_key']);
        setSetting('recaptcha_secret_key', $_POST['recaptcha_secret_key']);
        
        addLog($_SESSION['user_id'], 'update_security_settings', 'Actualizó configuración de seguridad', getClientIP(), getUserAgent());
        successResponse(null, 'Configuración de seguridad guardada');
    }
    
    errorResponse('Sección no válida');
}

errorResponse('Método no permitido', 405);
?>