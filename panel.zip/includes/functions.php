<?php
// ==============================================
// CEO SSH PANEL - FUNCIONES DEL SISTEMA
// Versión: 2.0.0
// ==============================================

require_once __DIR__ . '/config.php';
require_once __DIR__ . '/database.php';

// ==============================================
// FUNCIONES DE USUARIOS DEL PANEL
// ==============================================

function getUserById($id) {
    return db_select_one("SELECT id, username, email, role, status, created_at, last_login, last_ip, api_key FROM users WHERE id = ?", [$id]);
}

function getUserByUsername($username) {
    return db_select_one("SELECT * FROM users WHERE username = ?", [$username]);
}

function getUserByApiKey($apiKey) {
    return db_select_one("SELECT id, username, email, role, status FROM users WHERE api_key = ? AND status = 'active'", [$apiKey]);
}

function getAllUsers($limit = 100, $offset = 0, $search = '') {
    $sql = "SELECT id, username, email, role, status, created_at, last_login FROM users WHERE 1=1";
    $params = [];
    
    if (!empty($search)) {
        $sql .= " AND (username LIKE ? OR email LIKE ?)";
        $params[] = "%$search%";
        $params[] = "%$search%";
    }
    
    $sql .= " ORDER BY created_at DESC LIMIT ? OFFSET ?";
    $params[] = $limit;
    $params[] = $offset;
    
    return db_select($sql, $params);
}

function createUser($data) {
    return db_insert('users', $data);
}

function updateUser($id, $data) {
    return db_update('users', $data, 'id = ?', [$id]);
}

function deleteUser($id) {
    // Verificar que no sea el último admin
    $adminCount = db_count('users', 'role = "admin" AND id != ?', [$id]);
    $user = getUserById($id);
    
    if ($user['role'] === 'admin' && $adminCount == 0) {
        return false; // No se puede eliminar el último admin
    }
    
    return db_delete('users', 'id = ?', [$id]);
}

function generateAPIKey($userId) {
    $apiKey = bin2hex(random_bytes(32));
    updateUser($userId, ['api_key' => $apiKey]);
    return $apiKey;
}

// ==============================================
// FUNCIONES DE TOKENS SSH
// ==============================================

function getSSHTokens($filters = []) {
    $sql = "SELECT t.*, u.username as creator FROM ssh_tokens t 
            LEFT JOIN users u ON t.created_by = u.id WHERE 1=1";
    $params = [];
    
    if (isset($filters['status'])) {
        $sql .= " AND t.status = ?";
        $params[] = $filters['status'];
    }
    
    if (isset($filters['username'])) {
        $sql .= " AND t.username LIKE ?";
        $params[] = "%{$filters['username']}%";
    }
    
    if (isset($filters['created_by'])) {
        $sql .= " AND t.created_by = ?";
        $params[] = $filters['created_by'];
    }
    
    $sql .= " ORDER BY t.created_at DESC";
    
    if (isset($filters['limit'])) {
        $sql .= " LIMIT " . intval($filters['limit']);
        if (isset($filters['offset'])) {
            $sql .= " OFFSET " . intval($filters['offset']);
        }
    }
    
    return db_select($sql, $params);
}

function getSSHTokenById($id) {
    return db_select_one("SELECT * FROM ssh_tokens WHERE id = ?", [$id]);
}

function getSSHTokenByUsername($username) {
    return db_select_one("SELECT * FROM ssh_tokens WHERE username = ?", [$username]);
}

function createSSHToken($data) {
    return db_insert('ssh_tokens', $data);
}

function updateSSHToken($id, $data) {
    return db_update('ssh_tokens', $data, 'id = ?', [$id]);
}

function deleteSSHToken($id) {
    $token = getSSHTokenById($id);
    if ($token) {
        deleteSystemUser($token['username']);
        return db_delete('ssh_tokens', 'id = ?', [$id]);
    }
    return false;
}

function getExpiredTokens() {
    return db_select("SELECT * FROM ssh_tokens WHERE expires_at < NOW() AND status = 'active'");
}

function expireOldTokens() {
    $expired = getExpiredTokens();
    $count = 0;
    foreach ($expired as $token) {
        updateSSHToken($token['id'], ['status' => 'expired']);
        blockSystemUser($token['username']);
        $count++;
    }
    return $count;
}

function getActiveTokensCount() {
    return db_count('ssh_tokens', "status = 'active' AND expires_at > NOW()");
}

function getTotalTokensCount() {
    return db_count('ssh_tokens');
}

// ==============================================
// FUNCIONES DE LOGS
// ==============================================

function addLog($userId, $action, $details, $ip = null, $userAgent = null) {
    $ip = $ip ?: getClientIP();
    $userAgent = $userAgent ?: getUserAgent();
    
    $username = '';
    if ($userId > 0) {
        $user = getUserById($userId);
        $username = $user['username'] ?? '';
    }
    
    return db_insert('logs', [
        'user_id' => $userId,
        'username' => $username,
        'action' => $action,
        'details' => $details,
        'ip_address' => $ip,
        'user_agent' => $userAgent
    ]);
}

function getLogs($limit = 100, $offset = 0, $filters = []) {
    $sql = "SELECT l.* FROM logs l WHERE 1=1";
    $params = [];
    
    if (isset($filters['action'])) {
        $sql .= " AND l.action = ?";
        $params[] = $filters['action'];
    }
    
    if (isset($filters['user_id'])) {
        $sql .= " AND l.user_id = ?";
        $params[] = $filters['user_id'];
    }
    
    if (isset($filters['search'])) {
        $sql .= " AND (l.details LIKE ? OR l.username LIKE ?)";
        $params[] = "%{$filters['search']}%";
        $params[] = "%{$filters['search']}%";
    }
    
    $sql .= " ORDER BY l.created_at DESC LIMIT ? OFFSET ?";
    $params[] = $limit;
    $params[] = $offset;
    
    return db_select($sql, $params);
}

function getLogsCount($filters = []) {
    $sql = "SELECT COUNT(*) as count FROM logs WHERE 1=1";
    $params = [];
    
    if (isset($filters['action'])) {
        $sql .= " AND action = ?";
        $params[] = $filters['action'];
    }
    
    if (isset($filters['user_id'])) {
        $sql .= " AND user_id = ?";
        $params[] = $filters['user_id'];
    }
    
    $result = db_select_one($sql, $params);
    return intval($result['count'] ?? 0);
}

function getLogsByDate($date) {
    return db_select("SELECT * FROM logs WHERE DATE(created_at) = ? ORDER BY created_at DESC", [$date]);
}

// ==============================================
// FUNCIONES DE NOTIFICACIONES
// ==============================================

function addNotification($userId, $title, $message, $type = 'info') {
    return db_insert('notifications', [
        'user_id' => $userId,
        'title' => $title,
        'message' => $message,
        'type' => $type
    ]);
}

function getNotifications($userId, $limit = 20) {
    return db_select(
        "SELECT * FROM notifications WHERE user_id = ? ORDER BY created_at DESC LIMIT ?",
        [$userId, $limit]
    );
}

function getUnreadCount($userId) {
    return db_count('notifications', 'user_id = ? AND is_read = 0', [$userId]);
}

function markNotificationAsRead($id, $userId) {
    return db_update('notifications', ['is_read' => 1], 'id = ? AND user_id = ?', [$id, $userId]);
}

function markAllNotificationsAsRead($userId) {
    return db_update('notifications', ['is_read' => 1], 'user_id = ?', [$userId]);
}

function deleteNotification($id, $userId) {
    return db_delete('notifications', 'id = ? AND user_id = ?', [$id, $userId]);
}

function deleteOldNotifications($days = 30) {
    return db_delete('notifications', 'created_at < DATE_SUB(NOW(), INTERVAL ? DAY)', [$days]);
}

// ==============================================
// FUNCIONES DE CONFIGURACIÓN
// ==============================================

function getSetting($key, $default = null) {
    $result = db_select_one("SELECT value FROM settings WHERE `key` = ?", [$key]);
    return $result ? $result['value'] : $default;
}

function setSetting($key, $value, $description = '') {
    $exists = db_count('settings', '`key` = ?', [$key]);
    
    if ($exists) {
        return db_update('settings', ['value' => $value, 'description' => $description], '`key` = ?', [$key]);
    } else {
        return db_insert('settings', ['key' => $key, 'value' => $value, 'description' => $description]);
    }
}

function getAllSettings() {
    $settings = [];
    $result = db_select("SELECT `key`, `value`, description FROM settings");
    foreach ($result as $row) {
        $settings[$row['key']] = [
            'value' => $row['value'],
            'description' => $row['description']
        ];
    }
    return $settings;
}

// ==============================================
// FUNCIONES DE RESPONSE JSON
// ==============================================

function jsonResponse($data, $status = 200) {
    http_response_code($status);
    header('Content-Type: application/json');
    echo json_encode($data, JSON_PRETTY_PRINT);
    exit;
}

function successResponse($data = null, $message = 'Success', $code = 200) {
    $response = ['success' => true, 'message' => $message];
    if ($data !== null) {
        $response['data'] = $data;
    }
    jsonResponse($response, $code);
}

function errorResponse($message, $code = 400, $details = null) {
    $response = ['success' => false, 'error' => $message];
    if ($details !== null) {
        $response['details'] = $details;
    }
    jsonResponse($response, $code);
}

// ==============================================
// FUNCIONES DE SISTEMA
// ==============================================

function getSystemStats() {
    $load = sys_getloadavg();
    
    // Estadísticas de usuarios
    $totalUsers = db_count('users');
    $totalAdmins = db_count('users', "role = 'admin'");
    $activeTokens = getActiveTokensCount();
    $totalTokens = getTotalTokensCount();
    $expiredTokens = $totalTokens - $activeTokens;
    
    // Estadísticas del sistema
    $onlineUsers = intval(shell_exec("ps aux | grep -E 'sshd|dropbear' | grep -v grep | wc -l") ?: 0);
    $diskUsage = intval(shell_exec("df -h / | awk 'NR==2 {print $5}' | sed 's/%//'") ?: 0);
    $memoryUsage = floatval(shell_exec("free | grep Mem | awk '{print ($3/$2) * 100}'") ?: 0);
    
    // Estadísticas de logs
    $logsToday = db_count('logs', 'DATE(created_at) = CURDATE()');
    $totalLogs = db_count('logs');
    
    return [
        'load' => round($load[0], 2),
        'total_users' => $totalUsers,
        'total_admins' => $totalAdmins,
        'active_tokens' => $activeTokens,
        'total_tokens' => $totalTokens,
        'expired_tokens' => $expiredTokens,
        'online_users' => $onlineUsers,
        'disk_usage' => $diskUsage,
        'memory_usage' => round($memoryUsage, 1),
        'logs_today' => $logsToday,
        'total_logs' => $totalLogs,
        'timestamp' => date('Y-m-d H:i:s')
    ];
}

function getServerInfo() {
    return [
        'hostname' => gethostname(),
        'os' => php_uname('s') . ' ' . php_uname('r'),
        'php_version' => PHP_VERSION,
        'mysql_version' => getDB()->server_info,
        'nginx_version' => trim(shell_exec("nginx -v 2>&1 | cut -d'/' -f2") ?: 'Unknown'),
        'uptime' => trim(shell_exec("uptime -p") ?: 'Unknown'),
        'timezone' => date_default_timezone_get(),
        'server_time' => date('Y-m-d H:i:s'),
        'server_software' => $_SERVER['SERVER_SOFTWARE'] ?? 'Unknown'
    ];
}

function createBackup() {
    $backupDir = BACKUP_PATH;
    if (!is_dir($backupDir)) {
        mkdir($backupDir, 0755, true);
    }
    
    $filename = 'backup_' . date('Ymd_His') . '.sql';
    $filepath = $backupDir . '/' . $filename;
    
    $command = sprintf(
        'mysqldump -u %s -p%s %s > %s 2>/dev/null',
        escapeshellarg(DB_USER),
        escapeshellarg(DB_PASS),
        escapeshellarg(DB_NAME),
        escapeshellarg($filepath)
    );
    
    shell_exec($command);
    
    if (file_exists($filepath) && filesize($filepath) > 0) {
        db_insert('backups', [
            'filename' => $filename,
            'size' => filesize($filepath),
            'type' => 'database',
            'created_by' => $_SESSION['user_id'] ?? 0
        ]);
        
        // Limpiar backups antiguos
        cleanOldBackups();
        
        return $filename;
    }
    
    return false;
}

function cleanOldBackups() {
    $backupDir = BACKUP_PATH;
    $files = glob($backupDir . '/backup_*.sql');
    $keepDays = BACKUP_KEEP_DAYS;
    
    foreach ($files as $file) {
        if (filemtime($file) < time() - ($keepDays * 86400)) {
            unlink($file);
            $filename = basename($file);
            db_delete('backups', 'filename = ?', [$filename]);
        }
    }
}

function getBackups() {
    $backups = [];
    $files = glob(BACKUP_PATH . '/backup_*.sql');
    rsort($files);
    
    foreach ($files as $file) {
        $backups[] = [
            'filename' => basename($file),
            'size' => filesize($file),
            'size_human' => formatBytes(filesize($file)),
            'date' => date('Y-m-d H:i:s', filemtime($file)),
            'date_human' => date('d/m/Y H:i:s', filemtime($file))
        ];
    }
    
    return $backups;
}

// ==============================================
// FUNCIONES DE SISTEMA (SSH)
// ==============================================

function createSystemUser($username, $password, $expireDate) {
    $check = shell_exec("id " . escapeshellarg($username) . " 2>/dev/null");
    if ($check) {
        return false;
    }
    
    $cmd = sprintf(
        'useradd -m -s /bin/false -e %s %s 2>/dev/null && echo "%s:%s" | chpasswd 2>/dev/null',
        escapeshellarg($expireDate),
        escapeshellarg($username),
        escapeshellarg($username),
        escapeshellarg($password)
    );
    
    shell_exec($cmd);
    
    // Verificar que se creó
    $check = shell_exec("id " . escapeshellarg($username) . " 2>/dev/null");
    return !empty($check);
}

function deleteSystemUser($username) {
    shell_exec("userdel -r -f " . escapeshellarg($username) . " 2>/dev/null");
    return true;
}

function blockSystemUser($username) {
    shell_exec("usermod -L " . escapeshellarg($username) . " 2>/dev/null");
    return true;
}

function unblockSystemUser($username) {
    shell_exec("usermod -U " . escapeshellarg($username) . " 2>/dev/null");
    return true;
}

function extendSystemUser($username, $days) {
    $currentExp = shell_exec("chage -l " . escapeshellarg($username) . " 2>/dev/null | grep 'Account expires' | cut -d: -f2");
    $currentExp = trim($currentExp);
    
    if (empty($currentExp) || $currentExp == 'never') {
        $newExp = date('Y-m-d', strtotime("+$days days"));
    } else {
        $newExp = date('Y-m-d', strtotime($currentExp . " + $days days"));
    }
    
    shell_exec("usermod -e " . escapeshellarg($newExp) . " " . escapeshellarg($username) . " 2>/dev/null");
    return $newExp;
}

function getUserConnections($username) {
    $connections = shell_exec("ps aux | grep -E 'sshd|dropbear' | grep " . escapeshellarg($username) . " | grep -v grep | wc -l");
    return intval(trim($connections));
}

function killUserConnections($username) {
    shell_exec("pkill -u " . escapeshellarg($username) . " 2>/dev/null");
    return true;
}

function changeUserPassword($username, $newPassword) {
    shell_exec("echo '" . escapeshellarg($username) . ":" . escapeshellarg($newPassword) . "' | chpasswd 2>/dev/null");
    return true;
}

function getUserExpiration($username) {
    $exp = shell_exec("chage -l " . escapeshellarg($username) . " 2>/dev/null | grep 'Account expires' | cut -d: -f2");
    return trim($exp);
}

// ==============================================
// FUNCIONES DE VALIDACIÓN
// ==============================================

function validateEmail($email) {
    return filter_var($email, FILTER_VALIDATE_EMAIL) !== false;
}

function validateUsername($username) {
    return preg_match('/^[a-zA-Z0-9_]{3,20}$/', $username);
}

function validatePassword($password) {
    return strlen($password) >= 6;
}

function validateDomain($domain) {
    return preg_match('/^([a-z0-9]+(-[a-z0-9]+)*\.)+[a-z]{2,}$/i', $domain);
}

function validateIP($ip) {
    return filter_var($ip, FILTER_VALIDATE_IP) !== false;
}

// ==============================================
// FUNCIONES DE ENCRIPTACIÓN
// ==============================================

function encryptData($data) {
    $iv = random_bytes(16);
    $encrypted = openssl_encrypt($data, 'AES-256-CBC', ENCRYPTION_KEY, 0, $iv);
    return base64_encode($iv . $encrypted);
}

function decryptData($data) {
    $data = base64_decode($data);
    $iv = substr($data, 0, 16);
    $encrypted = substr($data, 16);
    return openssl_decrypt($encrypted, 'AES-256-CBC', ENCRYPTION_KEY, 0, $iv);
}
?>