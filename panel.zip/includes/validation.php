<?php
// ==============================================
// CEO SSH PANEL - VALIDACIÓN DE DATOS
// Versión: 2.0.0
// ==============================================

class Validator {
    private $errors = [];
    private $data = [];
    
    public function __construct($data = []) {
        $this->data = $data;
    }
    
    public function required($field, $message = null) {
        $value = $this->data[$field] ?? '';
        if (empty(trim($value))) {
            $this->addError($field, $message ?? "El campo $field es requerido");
        }
        return $this;
    }
    
    public function email($field, $message = null) {
        $value = $this->data[$field] ?? '';
        if (!empty($value) && !filter_var($value, FILTER_VALIDATE_EMAIL)) {
            $this->addError($field, $message ?? "El campo $field debe ser un email válido");
        }
        return $this;
    }
    
    public function minLength($field, $length, $message = null) {
        $value = $this->data[$field] ?? '';
        if (strlen($value) < $length) {
            $this->addError($field, $message ?? "El campo $field debe tener al menos $length caracteres");
        }
        return $this;
    }
    
    public function maxLength($field, $length, $message = null) {
        $value = $this->data[$field] ?? '';
        if (strlen($value) > $length) {
            $this->addError($field, $message ?? "El campo $field no puede tener más de $length caracteres");
        }
        return $this;
    }
    
    public function numeric($field, $message = null) {
        $value = $this->data[$field] ?? '';
        if (!empty($value) && !is_numeric($value)) {
            $this->addError($field, $message ?? "El campo $field debe ser numérico");
        }
        return $this;
    }
    
    public function integer($field, $message = null) {
        $value = $this->data[$field] ?? '';
        if (!empty($value) && !filter_var($value, FILTER_VALIDATE_INT)) {
            $this->addError($field, $message ?? "El campo $field debe ser un número entero");
        }
        return $this;
    }
    
    public function between($field, $min, $max, $message = null) {
        $value = $this->data[$field] ?? '';
        if (!empty($value) && ($value < $min || $value > $max)) {
            $this->addError($field, $message ?? "El campo $field debe estar entre $min y $max");
        }
        return $this;
    }
    
    public function in($field, $allowed, $message = null) {
        $value = $this->data[$field] ?? '';
        if (!empty($value) && !in_array($value, $allowed)) {
            $allowedStr = implode(', ', $allowed);
            $this->addError($field, $message ?? "El campo $field debe ser uno de: $allowedStr");
        }
        return $this;
    }
    
    public function matches($field, $otherField, $message = null) {
        $value = $this->data[$field] ?? '';
        $otherValue = $this->data[$otherField] ?? '';
        if ($value !== $otherValue) {
            $this->addError($field, $message ?? "El campo $field no coincide con $otherField");
        }
        return $this;
    }
    
    public function unique($field, $table, $column, $excludeId = null, $message = null) {
        $value = $this->data[$field] ?? '';
        if (empty($value)) return $this;
        
        $sql = "SELECT COUNT(*) as count FROM $table WHERE $column = ?";
        $params = [$value];
        
        if ($excludeId) {
            $sql .= " AND id != ?";
            $params[] = $excludeId;
        }
        
        $result = db_select_one($sql, $params);
        
        if ($result && $result['count'] > 0) {
            $this->addError($field, $message ?? "El valor del campo $field ya existe");
        }
        return $this;
    }
    
    public function exists($field, $table, $column, $message = null) {
        $value = $this->data[$field] ?? '';
        if (empty($value)) return $this;
        
        $result = db_select_one("SELECT COUNT(*) as count FROM $table WHERE $column = ?", [$value]);
        
        if (!$result || $result['count'] == 0) {
            $this->addError($field, $message ?? "El valor del campo $field no existe");
        }
        return $this;
    }
    
    public function date($field, $format = 'Y-m-d', $message = null) {
        $value = $this->data[$field] ?? '';
        if (empty($value)) return $this;
        
        $d = DateTime::createFromFormat($format, $value);
        if (!$d || $d->format($format) !== $value) {
            $this->addError($field, $message ?? "El campo $field debe ser una fecha válida ($format)");
        }
        return $this;
    }
    
    public function after($field, $date, $message = null) {
        $value = $this->data[$field] ?? '';
        if (empty($value)) return $this;
        
        $valueTime = strtotime($value);
        $compareTime = is_string($date) ? strtotime($date) : $date;
        
        if ($valueTime <= $compareTime) {
            $this->addError($field, $message ?? "El campo $field debe ser posterior a $date");
        }
        return $this;
    }
    
    public function before($field, $date, $message = null) {
        $value = $this->data[$field] ?? '';
        if (empty($value)) return $this;
        
        $valueTime = strtotime($value);
        $compareTime = is_string($date) ? strtotime($date) : $date;
        
        if ($valueTime >= $compareTime) {
            $this->addError($field, $message ?? "El campo $field debe ser anterior a $date");
        }
        return $this;
    }
    
    public function regex($field, $pattern, $message = null) {
        $value = $this->data[$field] ?? '';
        if (!empty($value) && !preg_match($pattern, $value)) {
            $this->addError($field, $message ?? "El campo $field tiene un formato inválido");
        }
        return $this;
    }
    
    public function username($field, $message = null) {
        return $this->regex($field, '/^[a-zA-Z0-9_]{3,20}$/', $message ?? "El usuario debe tener 3-20 caracteres (letras, números, guión bajo)");
    }
    
    public function password($field, $message = null) {
        return $this->minLength($field, 6, $message ?? "La contraseña debe tener al menos 6 caracteres");
    }
    
    public function domain($field, $message = null) {
        return $this->regex($field, '/^([a-z0-9]+(-[a-z0-9]+)*\.)+[a-z]{2,}$/i', $message ?? "El dominio no es válido");
    }
    
    public function ip($field, $message = null) {
        $value = $this->data[$field] ?? '';
        if (!empty($value) && !filter_var($value, FILTER_VALIDATE_IP)) {
            $this->addError($field, $message ?? "El campo $field debe ser una IP válida");
        }
        return $this;
    }
    
    public function url($field, $message = null) {
        $value = $this->data[$field] ?? '';
        if (!empty($value) && !filter_var($value, FILTER_VALIDATE_URL)) {
            $this->addError($field, $message ?? "El campo $field debe ser una URL válida");
        }
        return $this;
    }
    
    public function boolean($field, $message = null) {
        $value = $this->data[$field] ?? '';
        if (!empty($value) && !filter_var($value, FILTER_VALIDATE_BOOLEAN, FILTER_NULL_ON_FAILURE) === null) {
            $this->addError($field, $message ?? "El campo $field debe ser verdadero o falso");
        }
        return $this;
    }
    
    private function addError($field, $message) {
        if (!isset($this->errors[$field])) {
            $this->errors[$field] = [];
        }
        $this->errors[$field][] = $message;
    }
    
    public function getErrors() {
        return $this->errors;
    }
    
    public function getFirstError() {
        foreach ($this->errors as $field => $messages) {
            return $messages[0] ?? null;
        }
        return null;
    }
    
    public function isValid() {
        return empty($this->errors);
    }
    
    public function fails() {
        return !$this->isValid();
    }
}

// Funciones helper para validación
function validate($data, $rules) {
    $validator = new Validator($data);
    
    foreach ($rules as $field => $ruleString) {
        $rules = explode('|', $ruleString);
        
        foreach ($rules as $rule) {
            if (strpos($rule, ':') !== false) {
                list($ruleName, $ruleValue) = explode(':', $rule, 2);
                $validator->$ruleName($field, $ruleValue);
            } else {
                $validator->$rule($field);
            }
        }
    }
    
    return $validator;
}
?>