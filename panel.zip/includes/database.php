<?php
// ==============================================
// CEO SSH PANEL - BASE DE DATOS
// Versión: 2.0.0
// ==============================================

require_once __DIR__ . '/config.php';

// Clase para manejar la base de datos
class Database {
    private static $instance = null;
    private $connection;
    
    private function __construct() {
        try {
            $this->connection = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
            
            if ($this->connection->connect_error) {
                throw new Exception("Connection failed: " . $this->connection->connect_error);
            }
            
            $this->connection->set_charset("utf8mb4");
            $this->connection->query("SET time_zone = '+00:00'");
        } catch (Exception $e) {
            error_log("Database connection error: " . $e->getMessage());
            die("Error de conexión a la base de datos");
        }
    }
    
    public static function getInstance() {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    public function getConnection() {
        return $this->connection;
    }
    
    public function query($sql, $params = []) {
        $stmt = $this->connection->prepare($sql);
        
        if ($stmt === false) {
            error_log("Prepare error: " . $this->connection->error);
            return false;
        }
        
        if (!empty($params)) {
            $types = '';
            $bindParams = [];
            
            foreach ($params as $param) {
                if (is_int($param)) {
                    $types .= 'i';
                } elseif (is_float($param)) {
                    $types .= 'd';
                } elseif (is_string($param)) {
                    $types .= 's';
                } else {
                    $types .= 'b';
                }
                $bindParams[] = $param;
            }
            
            array_unshift($bindParams, $types);
            call_user_func_array([$stmt, 'bind_param'], $bindParams);
        }
        
        $stmt->execute();
        
        if ($stmt->error) {
            error_log("Execute error: " . $stmt->error);
            return false;
        }
        
        return $stmt;
    }
    
    public function select($sql, $params = []) {
        $stmt = $this->query($sql, $params);
        
        if ($stmt && $stmt->result) {
            $result = $stmt->get_result();
            return $result->fetch_all(MYSQLI_ASSOC);
        }
        
        return [];
    }
    
    public function selectOne($sql, $params = []) {
        $results = $this->select($sql, $params);
        return $results[0] ?? null;
    }
    
    public function insert($table, $data) {
        $fields = array_keys($data);
        $placeholders = array_fill(0, count($fields), '?');
        
        $sql = "INSERT INTO $table (" . implode(',', $fields) . ") VALUES (" . implode(',', $placeholders) . ")";
        $stmt = $this->query($sql, array_values($data));
        
        if ($stmt) {
            return $this->connection->insert_id;
        }
        
        return false;
    }
    
    public function update($table, $data, $where, $whereParams = []) {
        $sets = [];
        $values = [];
        
        foreach ($data as $field => $value) {
            $sets[] = "$field = ?";
            $values[] = $value;
        }
        
        $values = array_merge($values, $whereParams);
        $sql = "UPDATE $table SET " . implode(',', $sets) . " WHERE $where";
        $stmt = $this->query($sql, $values);
        
        return $stmt !== false;
    }
    
    public function delete($table, $where, $params = []) {
        $sql = "DELETE FROM $table WHERE $where";
        $stmt = $this->query($sql, $params);
        return $stmt !== false;
    }
    
    public function count($table, $where = '', $params = []) {
        $sql = "SELECT COUNT(*) as count FROM $table";
        if ($where) {
            $sql .= " WHERE $where";
        }
        $result = $this->selectOne($sql, $params);
        return intval($result['count'] ?? 0);
    }
    
    public function beginTransaction() {
        $this->connection->begin_transaction();
    }
    
    public function commit() {
        $this->connection->commit();
    }
    
    public function rollback() {
        $this->connection->rollback();
    }
    
    public function lastInsertId() {
        return $this->connection->insert_id;
    }
    
    public function escape($string) {
        return $this->connection->real_escape_string($string);
    }
}

// Funciones helper para acceso rápido a la base de datos
function getDB() {
    return Database::getInstance()->getConnection();
}

function db_query($sql, $params = []) {
    return Database::getInstance()->query($sql, $params);
}

function db_select($sql, $params = []) {
    return Database::getInstance()->select($sql, $params);
}

function db_select_one($sql, $params = []) {
    return Database::getInstance()->selectOne($sql, $params);
}

function db_insert($table, $data) {
    return Database::getInstance()->insert($table, $data);
}

function db_update($table, $data, $where, $whereParams = []) {
    return Database::getInstance()->update($table, $data, $where, $whereParams);
}

function db_delete($table, $where, $params = []) {
    return Database::getInstance()->delete($table, $where, $params);
}

function db_count($table, $where = '', $params = []) {
    return Database::getInstance()->count($table, $where, $params);
}

function db_begin_transaction() {
    Database::getInstance()->beginTransaction();
}

function db_commit() {
    Database::getInstance()->commit();
}

function db_rollback() {
    Database::getInstance()->rollback();
}
?>