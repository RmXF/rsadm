<?php
// Dummy login for v2
$u=$_POST['u']??''; $p=$_POST['p']??'';
if($u=='admin' && $p=='admin'){
  header('Location: /dashboard.html');
}else{
  echo "Login incorrecto";
}
?>