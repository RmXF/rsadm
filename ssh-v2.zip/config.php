<?php
define('DB_HOST', 'localhost');
define('DB_NAME', 'panelssh');
define('DB_USER', 'paneluser');
define('DB_PASS', 'TU_PASSWORD_DB');
session_start();
?>