<?php
require_once 'includes/auth.php';
require_once 'includes/db.php';

$total_vps = $pdo->query("SELECT COUNT(*) FROM servers")->fetchColumn();
$total_users = $pdo->query("SELECT COUNT(*) FROM ssh_users")->fetchColumn();
$expired = $pdo->query("SELECT COUNT(*) FROM ssh_users WHERE expire_date < CURDATE()")->fetchColumn();
?>

<h1>Dashboard</h1>
<p>VPS Registradas: <?= $total_vps ?></p>
<p>Usuarios Totales: <?= $total_users ?></p>
<p>Usuarios Expirados: <?= $expired ?></p>

<a href="vps/add.php">Agregar VPS</a>
<a href="vps/list.php">Lista VPS</a>
<a href="users/add.php">Agregar Usuario</a>
<a href="users/list.php">Lista Usuarios</a>
<a href="logout.php">Cerrar sesión</a>