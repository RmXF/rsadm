<?php
require_once 'includes/db.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $user = $_POST['username'];
    $pass = $_POST['password'];

    $stmt = $pdo->prepare("SELECT * FROM admins WHERE username=?");
    $stmt->execute([$user]);
    $admin = $stmt->fetch();

    if ($admin && password_verify($pass, $admin['password'])) {
        $_SESSION['admin'] = $admin['username'];
        header("Location: dashboard.php");
        exit;
    } else {
        $error = "Credenciales inválidas";
    }
}
?>

<form method="POST">
<h2>Login</h2>
<input name="username" placeholder="Usuario"><br>
<input name="password" type="password" placeholder="Password"><br>
<button>Entrar</button>
<?php if(isset($error)) echo $error; ?>
</form>