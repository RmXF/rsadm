<?php
require_once 'db.php';

function ssh_execute($server_id, $command) {
    global $pdo;

    $stmt = $pdo->prepare("SELECT * FROM servers WHERE id=?");
    $stmt->execute([$server_id]);
    $server = $stmt->fetch();

    if (!$server) return false;

    $ip = $server['ip'];
    $port = $server['port'];
    $user = $server['username'];

    if ($server['auth_type'] == "key") {
        $cmd = "ssh -o StrictHostKeyChecking=no -i /root/.ssh/panel_key -p $port $user@$ip \"$command\"";
    } else {
        $pass = $server['password'];
        $cmd = "sshpass -p '$pass' ssh -o StrictHostKeyChecking=no -p $port $user@$ip \"$command\"";
    }

    return shell_exec($cmd);
}
?>